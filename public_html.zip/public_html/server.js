// MEDITHINK — servidor Node.js sin dependencias (no requiere npm install).
// Variables de entorno: ADMIN_PASSWORD (obligatoria), SECRET (opcional), PORT.
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto'),zlib=require('zlib');
const PORT=process.env.PORT||3000,ROOT=path.join(__dirname,'public'),DATA=path.join(__dirname,'data'),BK=path.join(DATA,'backups');
const ADMIN=process.env.ADMIN_PASSWORD||'';
const SECRET=process.env.SECRET||crypto.createHash('sha256').update('mt'+ADMIN).digest('hex');
fs.mkdirSync(BK,{recursive:true});
const PUBLIC=['subjects','about','hero','sub','perm','cur','fx','season','qr','bank','paypalEmail','paypalLink','wa','mode','paywall','timerUrl','logo'];
const SRV=['paid','paidUntil','payMethod','paidAt','revokedAt','promo','mod','role','isMod','_ts'];
const MIME={'.html':'text/html;charset=utf-8','.css':'text/css','.js':'text/javascript','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon'};

/* ---------- Almacenes con escritura diferida, atómica y copia .prev ---------- */
const stores=[];
function store(file,init){
  const f=path.join(DATA,file);let v=init,dirty=false;
  for(const p of[f,f+'.prev']){try{v=Object.assign(init,JSON.parse(fs.readFileSync(p,'utf8')));if(p!==f)console.warn('Recuperado '+file+' desde .prev');break}catch(e){}}
  const s={get v(){return v},set v(x){v=x},mark(){dirty=true},
    flush(){if(!dirty)return;dirty=false;try{if(fs.existsSync(f))fs.copyFileSync(f,f+'.prev');fs.writeFileSync(f+'.tmp',JSON.stringify(v));fs.renameSync(f+'.tmp',f)}catch(e){console.error('Error guardando '+file,e);dirty=true}}};
  stores.push(s);return s;
}
const CT=store('content.json',{rev:0,content:{}});
const MB=store('members.json',{members:[],subReq:[],adminNotifs:[]});
const CM=store('community.json',{feed:[],posts:{gen:[],qa:[],sup:[]},notes:[],dm:{},reads:{}});
setInterval(()=>stores.forEach(s=>s.flush()),2000);

/* ---------- Copias de seguridad ---------- */
const bundle=()=>({v:1,at:new Date().toISOString(),content:CT.v,members:MB.v,community:CM.v});
const digest=b=>crypto.createHash('sha256').update(JSON.stringify([b.content,b.members,b.community])).digest('hex');
let lastDigest='';
function snapshot(tag,force){
  stores.forEach(s=>s.flush());const b=bundle(),d=digest(b);
  if(!force&&d===lastDigest)return null;lastDigest=d;
  const n=new Date().toISOString().replace(/[-:]/g,'').replace('T','-').slice(0,15)+(tag?'-'+tag:'')+'.json.gz';
  fs.writeFileSync(path.join(BK,n),zlib.gzipSync(JSON.stringify(b)));prune();return n;
}
function prune(){ // conserva las 16 más recientes + la última de cada día durante 30 días
  const fl=fs.readdirSync(BK).filter(x=>x.endsWith('.json.gz')).sort().reverse(),keep=new Set(fl.slice(0,16)),days=new Set();
  for(const x of fl){const d=x.slice(0,8);if(!days.has(d)&&days.size<30){days.add(d);keep.add(x)}}
  fl.forEach(x=>{if(!keep.has(x)&&!x.includes('pre-restore'))try{fs.unlinkSync(path.join(BK,x))}catch(e){}});
}
const okBundle=b=>b&&b.v===1&&b.content&&b.members&&Array.isArray(b.members.members)&&b.community&&Array.isArray(b.community.feed)&&b.community.posts&&typeof b.community.dm==='object';
function restore(b){
  if(!okBundle(b))throw new Error('Archivo de respaldo inválido');
  snapshot('pre-restore',true);
  CT.v=Object.assign({rev:0,content:{}},b.content);MB.v=Object.assign({members:[],subReq:[],adminNotifs:[]},b.members);
  CM.v=Object.assign({feed:[],posts:{gen:[],qa:[],sup:[]},notes:[],dm:{},reads:{}},b.community);
  stores.forEach(s=>{s.mark();s.flush()});
}
snapshot('inicio');setInterval(()=>snapshot(''),3*36e5);
const bye=()=>{stores.forEach(s=>s.flush());try{snapshot('cierre')}catch(e){}process.exit(0)};
process.on('SIGTERM',bye);process.on('SIGINT',bye);

/* ---------- Utilidades ---------- */
const sign=t=>crypto.createHmac('sha256',SECRET).update(t).digest('hex');
const mkToken=()=>{const e=Date.now()+12*36e5;return e+'.'+sign(''+e)};
function okToken(t){if(!t)return false;const[e,s]=String(t).split('.');if(!e||!s||+e<Date.now())return false;const a=Buffer.from(sign(e)),b=Buffer.from(s);return a.length===b.length&&crypto.timingSafeEqual(a,b)}
const isAdm=req=>okToken((req.headers.authorization||'').replace('Bearer ',''));
const em=x=>String(x||'').trim().toLowerCase();
const noPw=m=>{const c=Object.assign({},m);delete c.pw;delete c.resetToken;delete c.resetExp;return c};
const tries=new Map();
function limited(ip){const n=Date.now(),a=(tries.get(ip)||[]).filter(t=>n-t<9e5);tries.set(ip,a);return a.length>=8}
function body(req,max=5e6){return new Promise((res,rej)=>{let b='',n=0;req.on('data',c=>{n+=c.length;if(n>max){rej(new Error('big'));req.destroy()}else b+=c});req.on('end',()=>res(b));req.on('error',rej)})}
const send=(r,c,o,h)=>{r.writeHead(c,Object.assign({'Content-Type':'application/json','Cache-Control':'no-store'},h));r.end(JSON.stringify(o))};

/* ---------- Comunidad: propiedad, "me gusta" por usuario, comentarios, borrados ---------- */
const per=(o,n,w)=>{o=Array.isArray(o)?o:[];n=Array.isArray(n)?n:[];return o.filter(x=>x!==w).concat(n.includes(w)?[w]:[])};
function perRx(o,n,w){o=o&&typeof o==='object'?o:{};n=n&&typeof n==='object'?n:{};const out={};
  for(const k of new Set([...Object.keys(o),...Object.keys(n)])){const a=per(o[k],n[k],w);if(a.length)out[k]=a}return out}
function mergeCm(oldC,incC,w,adm,owner,since,now){
  const inc=new Map((Array.isArray(incC)?incC:[]).map(c=>[c&&c.id,c])),out=[];
  for(const o of(Array.isArray(oldC)?oldC:[])){const n=inc.get(o.id);
    if(!n){if(!((adm||o.aid===w||owner===w)&&(o._t||0)<=since))out.push(o);continue}
    inc.delete(o.id);out.push((adm||o.aid===w)?Object.assign({},n,{_t:o._t,likes:per(o.likes,n.likes,w)}):Object.assign({},o,{likes:per(o.likes,n.likes,w)}))}
  for(const n of inc.values())if(n&&n.id&&(adm||n.aid===w))out.push(Object.assign({},n,{_t:now}));
  return out}
const rid=x=>x._id||(x.id?String(x.id):crypto.createHash('sha1').update(JSON.stringify(x)).digest('hex').slice(0,12));
// kind: 'feed' | 'post' | 'dm' | 'note'.  Devuelve la lista nueva.
function merge(old,inc,{who,adm,since,kind,cap,front}){
  const now=Date.now(),inM=new Map(),out=[];
  for(const x of(Array.isArray(inc)?inc:[]))if(x&&typeof x==='object'&&JSON.stringify(x).length<1.5e6)inM.set(rid(x),x);
  const seen=new Set();
  for(const o of old){const id=o._id,n=inM.get(id);seen.add(id);
    if(!n){const mayDel=kind!=='dm'&&(adm||o._o===who)&&(o._t||0)<=since;if(!mayDel)out.push(o);continue}
    const own=adm||o._o===who;let r=o;
    if(kind==='feed'){
      r=Object.assign({},own?n:o,{_id:id,_o:o._o,_t:o._t});
      r.likes=per(o.likes,n.likes,who);r.rx=perRx(o.rx,n.rx,who);r.cm=mergeCm(o.cm,n.cm,who,adm,o._o,since,now);
    }else if(own&&kind!=='dm')r=Object.assign({},n,{_id:id,_o:o._o,_t:o._t});
    out.push(r)}
  const fresh=[];
  for(const[id,n]of inM){if(seen.has(id))continue;
    if(kind==='dm'&&!adm&&n.f!==who)continue;if(kind==='note'&&!adm)continue;
    const r=Object.assign({},n,{_id:id,_o:who,_t:now});
    if(kind==='feed'){r.likes=per([],n.likes,who);r.rx=perRx({},n.rx,who);r.cm=mergeCm([],n.cm,who,adm,who,since,now)}
    fresh.push(r)}
  const all=front?fresh.concat(out):out.concat(fresh);
  return front?all.slice(0,cap):all.slice(-cap)}

http.createServer(async(req,res)=>{
  try{
    const u=new URL(req.url,'http://x'),ip=req.socket.remoteAddress,P=u.pathname;
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','SAMEORIGIN');
    if(P==='/api/content'&&req.method==='GET')return send(res,200,{rev:CT.v.rev,content:CT.v.content});
    if(P==='/api/login'&&req.method==='POST'){
      if(!ADMIN)return send(res,500,{error:'Falta ADMIN_PASSWORD en el servidor'});
      if(limited(ip))return send(res,429,{error:'Demasiados intentos. Espera 15 minutos.'});
      const{password=''}=JSON.parse(await body(req,1e4)||'{}');
      const a=crypto.createHash('sha256').update(password).digest(),b=crypto.createHash('sha256').update(ADMIN).digest();
      if(!crypto.timingSafeEqual(a,b)){tries.set(ip,(tries.get(ip)||[]).concat(Date.now()));return send(res,401,{error:'Contraseña incorrecta'})}
      return send(res,200,{token:mkToken()});
    }
    if(P==='/api/content'&&req.method==='PUT'){
      if(!isAdm(req))return send(res,401,{error:'No autorizado'});
      const inc=JSON.parse(await body(req)),next={};
      for(const k of PUBLIC)if(k in inc)next[k]=inc[k];
      CT.v.content=next;CT.v.rev++;CT.mark();return send(res,200,{rev:CT.v.rev});
    }
    if(P==='/api/member/sync'&&req.method==='POST'){
      if(limited(ip+'m'))return send(res,429,{error:'Demasiadas solicitudes'});
      const b=JSON.parse(await body(req,2e6)),m=b.member;
      if(!m||!em(m.e)||!m.id)return send(res,400,{error:'Miembro inválido'});
      if(!/^[0-9a-f]{64}$/.test(m.pw||''))return send(res,400,{error:'Debes crear una contraseña para tu cuenta.',needPw:true});
      const M=MB.v;let cur=M.members.find(x=>em(x.e)===em(m.e));
      if(cur&&cur.pw&&cur.pw!==m.pw){tries.set(ip+'m',(tries.get(ip+'m')||[]).concat(Date.now()));return send(res,403,{error:'Contraseña incorrecta'})}
      if(!cur){cur={id:m.id,_ts:Date.now()};M.members.push(cur)}
      for(const k of Object.keys(m))if(!SRV.includes(k)&&k!=='id'&&k!=='pub')cur[k]=m[k];
      for(const k of['subReq','adminNotifs'])for(const x of(b[k]||[])){
        const mine=(k==='subReq'?x.uid:x.memberId)!==undefined&&x.id&&!M[k].some(y=>y.id===x.id);
        if(mine)M[k].push(Object.assign({},x,k==='subReq'?{uid:cur.id}:{memberId:cur.id},{_ts:Date.now()}))}
      MB.mark();
      return send(res,200,{member:Object.assign({},cur),subReq:M.subReq.filter(x=>x.uid===cur.id)});
    }
    if(P==='/api/community/sync'&&req.method==='POST'){
      const b=JSON.parse(await body(req,3e6)),st=b.state||{},adm=isAdm(req),M=MB.v,C=CM.v;let me=null;
      if(!adm){const m=b.member||{};me=M.members.find(x=>em(x.e)===em(m.e)&&x.pw&&x.pw===m.pw);if(!me)return send(res,401,{error:'Inicia sesión'})}
      const who=adm?'admin':me.id,since=+b.since||0,o={who,adm,since};
      C.feed=merge(C.feed,st.feed,{...o,kind:'feed',cap:500,front:true});
      for(const k of['gen','qa','sup'])C.posts[k]=merge(C.posts[k]||[],(st.posts||{})[k],{...o,kind:'post',cap:500,front:true});
      C.notes=merge(C.notes,adm?st.notes:[],{...o,kind:'note',cap:200});
      for(const k of Object.keys(st.dm||{})){if(!/^[\w|-]{1,80}$/.test(k)||!k.split('|').includes(who))continue;C.dm[k]=merge(C.dm[k]||[],st.dm[k],{...o,kind:'dm',cap:500})}
      C.reads=C.reads||{};
      for(const k of Object.keys(b.reads||{}))if(k.split('|').includes(who)){(C.reads[who]=C.reads[who]||{})[k]=Date.now()}
      CM.mark();
      const mine=k=>adm||k.split('|').includes(who),dm={},reads={};
      for(const k of Object.keys(C.dm))if(mine(k))dm[k]=C.dm[k];
      for(const u2 of Object.keys(C.reads))for(const k of Object.keys(C.reads[u2]))if(mine(k)&&(adm||k.split('|').includes(u2))){(reads[k]=reads[k]||{})[u2]=C.reads[u2][k]}
      const dir=adm?[]:M.members.filter(x=>x.pw&&x.id!==who).map(x=>({id:x.id,n:x.n,photo:(x.photo&&x.photo.length<2e4)?x.photo:''}));
      return send(res,200,{now:Date.now(),feed:C.feed,posts:C.posts,notes:C.notes,dm,reads,dir});
    }
    if(P.startsWith('/api/admin/')){
      if(!isAdm(req))return send(res,401,{error:'No autorizado'});
      const M=MB.v;
      if(P==='/api/admin/data'&&req.method==='GET')return send(res,200,{now:Date.now(),members:M.members.map(noPw),subReq:M.subReq,adminNotifs:M.adminNotifs});
      if(P==='/api/admin/data'&&req.method==='PUT'){
        const b=JSON.parse(await body(req)),since=+b.since||0;
        const keep=(old,inc)=>inc.concat(old.filter(o=>(o._ts||0)>since&&!inc.some(i=>i.id===o.id)));
        const pw=Object.fromEntries(M.members.map(m=>[m.id,m.pw]));
        M.members=keep(M.members,(b.members||[]).filter(m=>!m.pub).map(m=>Object.assign({},m,pw[m.id]?{pw:pw[m.id]}:{})));
        M.subReq=keep(M.subReq,b.subReq||[]);M.adminNotifs=keep(M.adminNotifs,b.adminNotifs||[]);
        MB.mark();return send(res,200,{now:Date.now()});
      }
      if(P==='/api/admin/backup'&&req.method==='GET'){
        snapshot('manual',true);const d=new Date().toISOString().slice(0,16).replace(/[:T]/g,'-');
        return send(res,200,bundle(),{'Content-Disposition':'attachment; filename="medithink-respaldo-'+d+'.json"'});
      }
      if(P==='/api/admin/backups'&&req.method==='GET')return send(res,200,{files:fs.readdirSync(BK).filter(x=>x.endsWith('.json.gz')).sort().reverse()});
      if(P==='/api/admin/restore'&&req.method==='POST'){
        try{restore(JSON.parse(await body(req,5e7)))}catch(e){return send(res,400,{error:e.message})}
        return send(res,200,{ok:true});
      }
    }
    if(P.startsWith('/api/'))return send(res,404,{error:'No existe'});
    let p=decodeURIComponent(P);if(p.endsWith('/'))p+='index.html';
    const f=path.normalize(path.join(ROOT,p));
    if(!f.startsWith(ROOT))return send(res,403,{error:'Prohibido'});
    fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end('No encontrado')}
      res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream','Cache-Control':path.extname(f)==='.html'?'no-cache':'public,max-age=3600'});res.end(d)});
  }catch(e){send(res,400,{error:'Solicitud inválida'})}
}).listen(PORT,()=>console.log('MEDITHINK en puerto '+PORT+(ADMIN?'':' ⚠ define ADMIN_PASSWORD')));
