/* ============================================================
   MEDITHINK — access.js  (<script id="mt-access">)
   Control de acceso + login con correo y contraseña.
   Se carga DESPUÉS de core.js y ui.js. No modifica el núcleo:
   sobreescribe views.join, joinNow, go, search, views.home,
   views.grid, views.plans, views.admin, rail y togPf.
   Admin separado: contraseña SHA-256 en localStorage 'mt_adm'.
   ============================================================ */
(function(){
  'use strict';
  const q = s => document.querySelector(s);
  const PROMO_CODE = 'test-medithink-2024';
  const PROMO_DAYS = 30;
  const PUBLIC_VIEWS = ['home', 'wa', 'about', 'join', 'admin'];
  const DAYMS = 864e5;

  window.joinMode = 'login';
  window.showAccessMsg = false;
  window.resetMember = null;
  let resetMember = null, resetErr = '', recoverResult = '';
  let promoMsg = false;

  const isGuest = () => !S.me && !admin;
  const isPaid = m => {
    if (S.paid) return true;
    if (!m) return false;
    if (m.paidUntil) return m.paidUntil > Date.now();
    return m.paid === true;
  };
  window.mtIsPaid = () => isPaid(myM());

  /* ---------- SHA-256 (SubtleCrypto + respaldo en JS puro) ---------- */
  function sha256js(str){
    const K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
    const bytes = Array.from(new TextEncoder().encode(str));
    const bitLen = bytes.length * 8;
    bytes.push(0x80);
    while (bytes.length % 64 !== 56) bytes.push(0);
    for (let i = 7; i >= 0; i--) bytes.push(Math.floor(bitLen / Math.pow(2, i * 8)) & 0xff);
    let H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    const r = (x, n) => (x >>> n) | (x << (32 - n));
    for (let o = 0; o < bytes.length; o += 64){
      const w = new Array(64);
      for (let i = 0; i < 16; i++) w[i] = (bytes[o+4*i] << 24) | (bytes[o+4*i+1] << 16) | (bytes[o+4*i+2] << 8) | bytes[o+4*i+3];
      for (let i = 16; i < 64; i++){
        const s0 = r(w[i-15],7) ^ r(w[i-15],18) ^ (w[i-15] >>> 3), s1 = r(w[i-2],17) ^ r(w[i-2],19) ^ (w[i-2] >>> 10);
        w[i] = (w[i-16] + s0 + w[i-7] + s1) | 0;
      }
      let [a,b,c,d,e,f,g,h] = H;
      for (let i = 0; i < 64; i++){
        const t1 = (h + (r(e,6) ^ r(e,11) ^ r(e,25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0;
        const t2 = ((r(a,2) ^ r(a,13) ^ r(a,22)) + ((a & b) ^ (a & c) ^ (b & c))) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      H = H.map((v, i) => (v + [a,b,c,d,e,f,g,h][i]) | 0);
    }
    return H.map(v => (v >>> 0).toString(16).padStart(8, '0')).join('');
  }
  async function hexHash(str){
    try{
      if (window.crypto && crypto.subtle){
        const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
        return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
      }
    }catch(e){}
    return sha256js(str);
  }
  window.hexHash = hexHash;

  /* ---------- Aviso flotante ---------- */
  function toast(msg, kind){
    let t = q('#mt-acc-toast');
    if (!t){ t = document.createElement('div'); t.id = 'mt-acc-toast'; t.setAttribute('role', 'status'); t.setAttribute('aria-live', 'polite'); document.body.appendChild(t); }
    t.className = 'mt-acc-toast ' + (kind || '');
    t.textContent = msg;
    void t.offsetWidth; t.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), 4200);
  }
  window.mtAccessToast = toast;
  function joinErr(msg){ const e = q('#jerr'); if (e){ e.textContent = msg; e.style.display = 'block'; } toast(msg, 'err'); }

  /* ---------- Enlace / código de prueba ---------- */
  function readPromoParam(){
    const grab = href => { try{ const u = new URL(href); return u.searchParams.get('promo') || new URLSearchParams(u.hash.replace(/^#/, '')).get('promo'); }catch(e){ return null; } };
    let p = grab(location.href);
    if (!p){ try{ if (window.top !== window) p = grab(window.top.location.href); }catch(e){} }
    if (!p && document.referrer) p = grab(document.referrer);
    return p;
  }
  function activatePromo(m){
    if (!m) return false;
    m.paid = true;
    m.paidUntil = Math.max(m.paidUntil || 0, Date.now()) + PROMO_DAYS * DAYMS;
    m.promo = PROMO_CODE;
    m.promoTs = Date.now();
    try{ sessionStorage.removeItem('mt_promo'); }catch(e){}
    save();
    toast('✅ Acceso de prueba activado (' + PROMO_DAYS + ' días)', 'ok');
    return true;
  }
  const pendingPromo = () => { try{ return sessionStorage.getItem('mt_promo') === PROMO_CODE; }catch(e){ return false; } };
  window.mtRedeemCode = function(inputId){
    const v = ((q('#' + inputId) || {}).value || '').trim();
    if (v !== PROMO_CODE) return toast('Código no válido.', 'err');
    if (activatePromo(myM())) render();
  };
  function promoBase(){
    if (S.promoBase) return S.promoBase;
    return /^https?:/.test(location.protocol) ? location.origin + location.pathname : '';
  }
  function promoLink(){ const b = promoBase(); return b ? b + (b.includes('?') ? '&' : '?') + 'promo=' + PROMO_CODE : ''; }
  window.mtSetPromoBase = function(v){ S.promoBase = String(v || '').trim().replace(/[?#].*$/, ''); save(); render(); };
  window.mtCopyPromo = async function(){
    const link = promoLink();
    if (!link) return toast('Escribí primero la URL pública de la web.', 'err');
    let ok = false;
    try{ await navigator.clipboard.writeText(link); ok = true; }catch(e){
      try{ const ta = document.createElement('textarea'); ta.value = link; document.body.appendChild(ta); ta.select(); ok = document.execCommand('copy'); ta.remove(); }catch(x){}
    }
    const out = q('#promo-out'); if (out) out.value = link;
    toast(ok ? '📋 Enlace de prueba copiado' : 'Copiá el enlace manualmente', ok ? 'ok' : '');
  };


  /* ---------- Ver / ocultar contraseña ---------- */
  function pwInput(id, ac, onkey, ph){
    return `<div class="pw-wrap"><input id="${id}" type="password" autocomplete="${ac || 'off'}"${ph ? ` placeholder="${ph}"` : ''}${onkey ? ` onkeydown="${onkey}"` : ''}><button type="button" class="pw-eye" onclick="togglePw('${id}')" aria-label="Ver contraseña" aria-pressed="false" tabindex="-1">👁️</button></div>`;
  }
  window.togglePw = function(id){
    const inp = document.getElementById(id); if (!inp) return;
    const btn = inp.parentElement.querySelector('.pw-eye');
    const show = inp.type === 'password';
    inp.type = show ? 'text' : 'password';
    if (btn){ btn.textContent = show ? '🙈' : '👁️'; btn.setAttribute('aria-label', show ? 'Ocultar contraseña' : 'Ver contraseña'); btn.setAttribute('aria-pressed', String(show)); }
    inp.focus();
  };

  /* ---------- Soporte ---------- */
  function supportUrl(){
    const w = S.wa || {};
    if (w.link) return w.link;
    if (w.num) return 'https://wa.me/' + w.num.replace(/\D/g, '') + '?text=' + encodeURIComponent('Hola, necesito ayuda para ingresar a MEDITHINK');
    if (S.adminEmail) return 'mailto:' + S.adminEmail + '?subject=' + encodeURIComponent('Ayuda para ingresar a MEDITHINK');
    return '';
  }
  function supportHint(){
    const u = supportUrl();
    const link = u ? `<a href="${esc(u)}" target="_blank" rel="noopener">💬 Escribí al soporte</a>` : `<span>💬 Soporte: el administrador aún no configuró un contacto</span>`;
    return `<div class="support-hint"><span>¿Problemas para ingresar?</span>${link}<span aria-hidden="true">·</span><a href="#" onclick="setJoinMode('recover');return false">¿Olvidaste tu contraseña?</a><small class="support-txt">Escribí al chat de soporte y pedí acceso: indicá tu nombre y el correo con el que te registraste.</small></div>`;
  }

  /* ---------- Recuperar contraseña ---------- */
  const newToken = () => Math.random().toString(36).slice(2) + Date.now().toString(36);
  function resetBase(){ return S.promoBase || location.href.split('?')[0].split('#')[0]; }
  function resetUrlFor(m){ return resetBase() + '?reset=' + m.resetToken + '&e=' + encodeURIComponent(m.e); }
  function gmailUrl(to, subject, body){ return `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(to)}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`; }
  window.mtResetUrlFor = m => resetUrlFor(m);

  function recoverView(){
    return `<h1>Recuperar contraseña</h1><div class="box acc-box"><p><small>Escribí el correo con el que te registraste. Se abrirá Gmail con un enlace para crear una nueva contraseña (válido por 24 horas).</small></p>
<label for="jr-email">Correo electrónico</label><input id="jr-email" type="email" autocomplete="email" onkeydown="if(event.key==='Enter')sendRecovery()">
<p id="jerr" class="acc-err" role="alert" style="display:none"></p>
<button class="btn" onclick="sendRecovery()">Enviar solicitud de recuperación</button>
<div id="jr-result" aria-live="polite">${recoverResult}</div>
<p class="acc-switch"><a href="#" onclick="setJoinMode('login');return false">← Volver al inicio de sesión</a></p></div>`;
  }
  window.sendRecovery = function(){
    const email = ((q('#jr-email') || {}).value || '').trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(email)) return joinErr('Escribí un correo válido.');
    const m = S.members.find(x => String(x.e || '').toLowerCase() === email);
    if (!m) return joinErr('No encontramos una cuenta con ese correo.');
    const e = q('#jerr'); if (e) e.style.display = 'none';
    const tt = q('#mt-acc-toast'); if (tt) tt.classList.remove('show');
    m.resetToken = newToken(); m.resetExp = Date.now() + 24 * 3600 * 1000; save();
    const resetUrl = resetUrlFor(m);
    const body = `Hola ${m.n},\n\nRecibimos una solicitud para recuperar tu contraseña de MEDITHINK.\n\nHacé clic en el siguiente enlace para crear una nueva contraseña (válido por 24 horas):\n\n${resetUrl}\n\nSi no solicitaste esto, ignorá este mensaje.\n\nMEDITHINK`;
    const gUrl = gmailUrl(m.e, 'Recuperar contraseña - MEDITHINK', body);
    try{ window.open(gUrl, '_blank', 'noopener'); }catch(x){}
    const waNum = (S.wa && S.wa.num) ? S.wa.num.replace(/\D/g, '') : '';
    const waTxt = `Hola, solicito recuperar la contraseña de mi cuenta MEDITHINK.\nCorreo: ${m.e}\nNombre: ${m.n}`;
    const waUrl = waNum ? `https://wa.me/${waNum}?text=${encodeURIComponent(waTxt)}` : '';
    recoverResult = `<div class="box ok-box"><b>✅ Se abrió Gmail para enviar el enlace de recuperación</b><p>Revisá que el correo haya sido enviado a <b>${esc(m.e)}</b>.</p><p>Si no se abrió Gmail, <a href="${esc(gUrl)}" target="_blank" rel="noopener">hacé clic aquí</a>.</p>${waUrl ? `<p>También podés <a href="${esc(waUrl)}" target="_blank" rel="noopener">escribir al soporte por WhatsApp</a>.</p>` : ''}<small>El enlace vence en 24 horas.</small></div>`;
    const r = q('#jr-result'); if (r) r.innerHTML = recoverResult;
    recoverResult = '';
  };

  function resetView(){
    const m = resetMember;
    return `<h1>Crear nueva contraseña</h1><div class="box acc-box"><p>Hola <b>${esc(m.n)}</b>, creá tu nueva contraseña:</p>
<label for="jp-new">Nueva contraseña</label>${pwInput('jp-new', 'new-password', '', 'Nueva contraseña (mín. 6 caracteres)')}
<label for="jp-new2">Confirmar nueva contraseña</label>${pwInput('jp-new2', 'new-password', "if(event.key==='Enter')saveNewPw()", 'Confirmar nueva contraseña')}
<p id="jerr" class="acc-err" role="alert" style="display:none"></p>
<button class="btn" style="margin-top:6px" onclick="saveNewPw()">Guardar contraseña</button>
<p class="acc-switch"><a href="#" onclick="setJoinMode('login');return false">← Volver al inicio de sesión</a></p></div>`;
  }
  window.saveNewPw = async function(){
    const m = resetMember; if (!m) return setJoinMode('login');
    const pw = (q('#jp-new') || {}).value || '', pw2 = (q('#jp-new2') || {}).value || '';
    if (pw.length < 6) return joinErr('La contraseña debe tener al menos 6 caracteres.');
    if (pw !== pw2) return joinErr('Las contraseñas no coinciden.');
    if (!m.resetExp || Date.now() > m.resetExp){ delete m.resetToken; delete m.resetExp; save(); resetMember = null; resetErr = 'El enlace ya venció. Solicitá uno nuevo.'; window.joinMode = 'login'; return render(); }
    m.pw = await hexHash(pw);
    delete m.resetToken; delete m.resetExp;
    S.me = m.id; setCk(m.id);
    resetMember = null; window.resetMember = null; resetErr = ''; window.joinMode = 'login'; window.showAccessMsg = false;
    save(); go('home');
    toast('✅ Contraseña actualizada. Ya estás dentro.', 'ok');
  };

  function handleReset(){
    const grab = href => { try{ const u = new URL(href); return u.searchParams.get('reset') ? u.searchParams : null; }catch(e){ return null; } };
    let params = grab(location.href);
    if (!params){ try{ if (window.top !== window) params = grab(window.top.location.href); }catch(e){} }
    if (!params) return false;
    const token = params.get('reset'), email = (params.get('e') || '').toLowerCase();
    try{ history.replaceState(null, '', location.pathname + location.hash); }catch(e){}
    const m = S.members.find(x => x.resetToken && x.resetToken === token && String(x.e || '').toLowerCase() === email);
    window.joinMode = 'login';
    const fail = msg => { resetErr = msg; view = S.me ? 'home' : 'join'; setTimeout(() => toast('⚠️ ' + msg, 'err'), 50); return true; };
    if (!m) return fail('El enlace de recuperación no es válido o ya fue usado. Solicitá uno nuevo.');
    if (Date.now() > (m.resetExp || 0)){ delete m.resetToken; delete m.resetExp; save(); return fail('El enlace ya venció (24 horas). Solicitá uno nuevo.'); }
    view = 'join';
    if (S.me && S.me !== m.id){ S.me = null; save(); }
    resetMember = m; window.resetMember = m; window.joinMode = 'reset';
    return true;
  }

  /* ---------- Admin: enlaces de recuperación por miembro ---------- */
  async function copyText(t){
    try{ await navigator.clipboard.writeText(t); return true; }catch(e){
      try{ const ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select(); const ok = document.execCommand('copy'); ta.remove(); return ok; }catch(x){ return false; }
    }
  }
  window.adminResetLink = async function(idx){
    if (!admin) return;
    const m = S.members[idx]; if (!m) return;
    m.resetToken = newToken(); m.resetExp = Date.now() + 48 * 3600 * 1000; save();
    const url = resetUrlFor(m);
    const out = q('#rst-' + idx); if (out){ out.value = url; out.hidden = false; }
    if (await copyText(url)) toast('🔑 Enlace copiado. Enviáselo al miembro por WhatsApp o correo.', 'ok');
    else { toast('Copiá el enlace manualmente.'); out && out.select(); }
  };
  window.adminResetGmail = function(idx){
    if (!admin) return;
    const m = S.members[idx]; if (!m) return;
    if (!m.resetToken || Date.now() > (m.resetExp || 0)){ m.resetToken = newToken(); m.resetExp = Date.now() + 48 * 3600 * 1000; save(); }
    const url = resetUrlFor(m);
    const out = q('#rst-' + idx); if (out){ out.value = url; out.hidden = false; }
    const body = `Hola ${m.n},\n\nEl administrador de MEDITHINK generó este enlace para que recuperes tu contraseña (válido 48 horas):\n\n${url}\n\nMEDITHINK`;
    try{ window.open(gmailUrl(m.e, 'Recuperar contraseña - MEDITHINK', body), '_blank', 'noopener'); }catch(x){}
  };
  const _members = views.members;
  views.members = function(){
    const t = document.createElement('template');
    t.innerHTML = _members.apply(this, arguments);
    t.content.querySelectorAll('button[onclick^="S.members.splice("]').forEach(btn => {
      const i = +(/splice\((\d+)/.exec(btn.getAttribute('onclick')) || [])[1];
      const m = S.members[i]; if (!m) return;
      const st = m.pw ? '🔐 Con contraseña' : '⚠️ Sin contraseña';
      const exp = m.resetToken && m.resetExp > Date.now() ? ` · enlace activo hasta ${new Date(m.resetExp).toLocaleString('es', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}` : '';
      const wrap = document.createElement('span');
      wrap.className = 'rst-tools';
      wrap.innerHTML = `<button class="btn o s" onclick="adminResetLink(${i})">🔑 Enlace de recuperación</button> <button class="btn o s" onclick="adminResetGmail(${i})">📧 Enviar por Gmail</button> <small class="rst-st">${st} · ${esc(estado(m))}${exp}</small><input id="rst-${i}" class="rst-out" readonly hidden onclick="this.select()" aria-label="Enlace de recuperación de ${esc(m.n)}"> `;
      btn.parentNode.insertBefore(wrap, btn);
      const acc = document.createElement('div'); acc.className = 'acc-ctl';
      acc.innerHTML = accessCtl(m) + accessForm(m) + memberSubjects(m);
      if (acc.innerHTML) btn.parentNode.appendChild(acc);
    });
    return t.innerHTML;
  };

  /* ---------- Login / registro ---------- */
  window.openJoin = function(m){ window.joinMode = m; window.showAccessMsg = false; go('join'); };
  window.setJoinMode = function(m){ if (m !== 'reset') resetMember = null; resetErr = ''; if (m !== 'admin-firstpw') admFirstOk = false; window.joinMode = m; render(); const f = q('#je'); f && f.focus(); };

  const _join = views.join;
  views.join = function(){
    if (window.joinMode === 'reset' && resetMember) return resetView();
    if (window.joinMode === 'admin-firstpw' && admFirstOk) return adminFirstPwView();
    if (window.joinMode === 'admin-login' || window.joinMode === 'admin-firstpw') return adminLoginView();
    if (myM()) return _join.apply(this, arguments);
    const reg = window.joinMode === 'register';
    const banner = (resetErr ? `<div class="acc-banner err">⚠️ ${esc(resetErr)}</div>` : '') + (window.showAccessMsg ? `<div class="acc-banner">🔒 Iniciá sesión para acceder al contenido</div>` : '')
      + ((promoMsg || pendingPromo()) ? `<div class="acc-banner ok">🎁 Estás activando una cuenta de prueba de ${PROMO_DAYS} días</div>` : '');
    const pwField = (id, label, ac) => `<div><label for="${id}">${label}</label>${pwInput(id, ac, "if(event.key==='Enter')joinNow()")}</div>`;
    if (window.joinMode === 'recover') return recoverView();
    if (window.joinMode === 'reset' && resetMember) return resetView();
    const head = `<h1>${reg ? 'Crear cuenta' : 'Iniciar sesión'}</h1>${banner}<div class="box acc-box">`;
    const errBox = `<p id="jerr" class="acc-err" role="alert" style="display:none"></p>`;
    if (!reg){
      return head + `<div class="row"><div><label for="je">Correo electrónico</label><input id="je" type="email" autocomplete="email" onkeydown="if(event.key==='Enter')joinNow()"></div></div>
<div class="row">${pwField('jpw', 'Contraseña', 'current-password')}</div>${errBox}
<button class="btn" onclick="joinNow()">Entrar</button>
${supportHint()}
<p class="acc-switch"><a href="#" onclick="setJoinMode('register');return false">¿No tenés cuenta? Crear cuenta</a></p>
<a href="#" id="admin-link" onclick="joinMode='admin-login';render();return false" style="font-size:11px;color:var(--mu);opacity:0.5;display:block;text-align:center;margin-top:18px">Acceso administrador</a></div>`;
    }
    return head + `<p class="acc-trial">🎉 Al registrarte obtenés 7 días de prueba gratis</p>
<div class="row"><div><label for="je">Correo electrónico</label><input id="je" type="email" autocomplete="email"></div></div>
<div class="row">${pwField('jpw', 'Contraseña (mínimo 6 caracteres)', 'new-password')}${pwField('jpw2', 'Confirmar contraseña', 'new-password')}</div>
<div class="row"><div><label for="jn">Nombre completo</label><input id="jn" autocomplete="name"></div><div><label for="jw">WhatsApp (con código de país)</label><input id="jw" inputmode="tel" placeholder="+591 7XXXXXXX"></div></div>
<div class="row"><div><label for="jc">Carrera</label><select id="jc" onchange="$('#jo').style.display=this.value==='Otra'?'block':'none'"><option value="">Selecciona</option><option>Medicina</option><option>Enfermería</option><option>Fisioterapia</option><option>Nutrición</option><option>Otra</option></select></div><div><label for="jy">Año de estudio</label><select id="jy">${[1,2,3,4,5,6,7].map(y => `<option>${y}</option>`).join('')}</select></div></div>
<div id="jo" style="display:none"><label for="jcx">¿Cuál es tu carrera?</label><input id="jcx"></div>
<div class="row"><div><label for="ju">Universidad (opcional)</label><input id="ju"></div><div><label for="jpa">País (opcional)</label><input id="jpa"></div></div>
<div class="row"><div><label for="jp">Foto de perfil (opcional)</label><input type="file" accept="image/*" id="jp"></div><div><label for="jpromo">Código de prueba (opcional)</label><input id="jpromo" autocomplete="off" value="${pendingPromo() ? PROMO_CODE : ''}"></div></div>${errBox}
<button class="btn" onclick="joinNow()">Crear cuenta</button>
<p class="acc-switch"><a href="#" onclick="setJoinMode('login');return false">¿Ya tenés cuenta? Iniciar sesión</a></p></div>`;
  };

  function startSession(m){
    S.me = m.id; setCk(m.id);
    window.showAccessMsg = false; promoMsg = false; resetErr = '';
    if (pendingPromo()) activatePromo(m); else save();
    go('home');
  }

  let busy = false;
  window.joinNow = async function(){
    if (busy) return;
    const e = ((q('#je') || {}).value || '').trim().toLowerCase();
    const pw = (q('#jpw') || {}).value || '';
    if (!/^\S+@\S+\.\S+$/.test(e)) return joinErr('Escribí un correo válido.');
    if (!pw) return joinErr('Escribí tu contraseña.');
    const old = S.members.find(x => String(x.e || '').toLowerCase() === e);
    busy = true;
    try{
      if (window.joinMode !== 'register'){
        if (!old) return joinErr('No encontramos una cuenta con ese correo. Tocá "Crear cuenta".');
        const h = await hexHash(pw);
        if (old.pw){
          if (old.pw !== h) return joinErr('Contraseña incorrecta.');
        } else {
          // Cuenta antigua sin contraseña: se crea con la que escribió.
          if (pw.length < 6) return joinErr('Tu cuenta no tenía contraseña. Elegí una de al menos 6 caracteres.');
          if (!confirm('Tu cuenta no tenía contraseña. ¿Querés usar la que escribiste de ahora en adelante?')) return;
          old.pw = h;
          toast('🔐 Contraseña creada para tu cuenta', 'ok');
        }
        return startSession(old);
      }
      if (old) return joinErr('Ya tenés una cuenta, iniciá sesión.');
      const pw2 = (q('#jpw2') || {}).value || '';
      if (pw.length < 6) return joinErr('La contraseña debe tener al menos 6 caracteres.');
      if (pw !== pw2) return joinErr('Las contraseñas no coinciden.');
      const n = q('#jn').value.trim(), w = q('#jw').value.trim(), car = q('#jc').value, oth = (q('#jcx').value || '').trim();
      if (!n) return joinErr('Escribí tu nombre completo.');
      if (w.replace(/\D/g, '').length < 8) return joinErr('Escribí un WhatsApp válido con código de país.');
      if (!car) return joinErr('Seleccioná tu carrera.');
      if (car === 'Otra' && !oth) return joinErr('Escribí tu carrera.');
      const code = ((q('#jpromo') || {}).value || '').trim();
      if (code && code !== PROMO_CODE) return joinErr('El código de prueba no es válido.');
      if (code === PROMO_CODE){ try{ sessionStorage.setItem('mt_promo', PROMO_CODE); }catch(x){} }
      const f = q('#jp').files[0], photo = f ? await imgData(f) : '', id = 'm' + Date.now();
      const m = { id, n, e, w, pw: await hexHash(pw), d: new Date().toLocaleDateString('es'), photo, car: car === 'Otra' ? oth : car, yr: q('#jy').value, uni: q('#ju').value.trim(), pais: q('#jpa').value.trim(), trialEnd: Date.now() + 7 * DAYMS, joinTs: Date.now(), sec: 0, adv: 0 };
      S.members.push(m);
      window.joinMode = 'login';
      toast('✅ Cuenta creada. ¡Bienvenido/a, ' + n.split(' ')[0] + '!', 'ok');
      startSession(m);
    } finally { busy = false; }
  };

  /* ---------- Gate de navegación ---------- */
  const _go = window.go;
  window.go = function(v, a){
    if ((v === 'admin' || v === 'crm') && !(window.adminLoggedIn && admin)){
      window.joinMode = 'admin-login'; window.showAccessMsg = false;
      return _go('join');
    }
    if (isGuest() && !PUBLIC_VIEWS.includes(v)){
      window.showAccessMsg = true;
      return _go('join');
    }
    if (v !== 'join') window.showAccessMsg = false;
    return _go(v, a);
  };
  window.mtNeedLogin = function(){ window.showAccessMsg = true; window.joinMode = 'login'; _go('join'); };
  const _search = window.search;
  window.search = function(t){
    if (isGuest() && String(t || '').trim()){ window.showAccessMsg = true; return _go('join'); }
    return _search.apply(this, arguments);
  };

  /* ---------- Grilla de materias ---------- */
  const _grid = views.grid;
  views.grid = function(){
    if (!isGuest()) return _grid.apply(this, arguments);
    const cards = S.subjects.map(s => s.pub === false ? '' :
      `<div class="card card-locked" tabindex="0" role="button" aria-label="${esc(s.n)}: solo para miembros, iniciá sesión" onclick="mtNeedLogin()" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();mtNeedLogin()}">${cover(s)}<div class="cb"><b>${esc(s.n)}</b><br><small>${lessons(s).length} temas</small><br><span class="pill acc-pill">🔒 Solo para miembros</span></div></div>`).join('');
    return `<div class="grid">${cards}</div>`;
  };

  /* ---------- Inicio ---------- */
  const _home = views.home;
  function waUrl(){ const w = S.wa || {}; return w.link || (w.num ? 'https://wa.me/' + w.num.replace(/\D/g, '') + '?text=' + encodeURIComponent('Hola, quiero unirme al grupo de MEDITHINK') : ''); }
  views.home = function(){
    const t = document.createElement('template');
    t.innerHTML = _home.apply(this, arguments);
    const plans = t.content.querySelector('.plans');
    if (isGuest()){
      const h1 = t.content.querySelector('h1'), hero = t.content.querySelector('.home2');
      if (hero){ const b = hero.querySelector('button.btn'); if (b){ b.setAttribute('onclick', "document.getElementById('acc-grid').scrollIntoView({behavior:'smooth'})"); } }
      const u = waUrl();
      const wa = u ? `<a class="btn acc-wa" target="_blank" rel="noopener" href="${esc(u)}">📲 Únete al grupo de WhatsApp</a>` : `<button class="btn acc-wa" onclick="go('wa')">📲 Únete al grupo de WhatsApp</button>`;
      return (h1 ? h1.outerHTML : '') + (hero ? hero.outerHTML : '')
        + `<div class="acc-cta">${wa}<button class="btn o" onclick="openJoin('login')">Iniciar sesión</button><button class="btn o" onclick="openJoin('register')">Crear cuenta · 7 días gratis</button></div>`
        + `<h2 id="acc-grid" style="margin-top:28px">Materias</h2><p class="mu"><small>🔒 El contenido es solo para miembros. Iniciá sesión o creá tu cuenta para estudiar.</small></p>${views.grid()}`;
    }
    if (plans && (admin || isPaid(myM()))) plans.remove();
    return t.innerHTML;
  };

  /* ---------- Planes ---------- */
  const _plans = views.plans;
  views.plans = function(){
    const m = myM();
    if (m && isPaid(m)){
      const until = m.paidUntil ? new Date(m.paidUntil).toLocaleDateString('es', { day: 'numeric', month: 'long', year: 'numeric' }) : '';
      return `<h1>Planes de acceso</h1><div class="box acc-active"><h2 style="margin-top:0">✅ Ya tenés acceso activo</h2><p>Cuenta: <b>${esc(m.e)}</b><br>Estado: ${esc(estado(m))}${until ? `<br>Acceso válido hasta: <b>${until}</b>` : ''}${m.promo ? `<br><small>Activado con el enlace de prueba (${PROMO_DAYS} días).</small>` : ''}</p><button class="btn" onclick="go('subjects')">Ir a materias</button></div>`;
    }
    const code = m ? `<div class="box"><label for="pcode">¿Tenés un código de prueba?</label><div class="row" style="align-items:flex-end"><div><input id="pcode" autocomplete="off"></div><div style="flex:none"><button class="btn o" onclick="mtRedeemCode('pcode')">Activar</button></div></div></div>` : '';
    return _plans.apply(this, arguments) + code;
  };

  /* ======================================================================
     ADMINISTRADOR SEPARADO (mt_adm) — reemplaza el login del núcleo (S.pw)
     ====================================================================== */
  const ADM_KEY = 'mt_adm';
  const ADM_INITIAL = 'Medi@Admin2024';
  window.adminLoggedIn = false;
  let admFirstOk = false, admBusy = false;
  function loadAdmCfg(){ try{ return JSON.parse(localStorage.getItem(ADM_KEY)) || {}; }catch(e){ return {}; } }
  function saveAdmCfg(cfg){ try{ localStorage.setItem(ADM_KEY, JSON.stringify(cfg)); }catch(e){} }
  window.loadAdmCfg = loadAdmCfg; window.saveAdmCfg = saveAdmCfg;
  // Inicialización: si no existe mt_adm se crea con la contraseña inicial hasheada.
  const admReady = (async () => {
    const c = loadAdmCfg();
    if (!c.pw) saveAdmCfg({ pw: await hexHash(ADM_INITIAL), firstLogin: true });
  })();
  // La contraseña antigua del núcleo deja de servir: se vacía S.pw.
  if (S.pw){ S.pw = ''; save(); }

  function admErr(msg){ const e = q('#adm-err'); if (e){ e.textContent = msg; e.style.display = 'block'; } toast(msg, 'err'); }
  function enterAdmin(){
    window.adminLoggedIn = true; admin = true; admFirstOk = false;
    S.me = null; try{ document.cookie = 'mt_member=; max-age=0; path=/'; }catch(e){}
    window.joinMode = 'login'; save(); go('admin');
  }
  function adminLoginView(){
    return `<h1>Administrador</h1><div class="box acc-box adm-box">
<label for="adm-pw">Contraseña</label>${pwInput('adm-pw', 'current-password', "if(event.key==='Enter')adminLogin()")}
<p id="adm-err" class="acc-err" role="alert" style="display:none"></p>
<button class="btn" onclick="adminLogin()">Entrar como administrador</button>
<p class="acc-switch"><a href="#" onclick="setJoinMode('login');return false">← Volver</a></p>
<p class="adm-reset"><a href="#" onclick="adminResetInitial();return false">¿Olvidaste la contraseña? Reiniciar a la contraseña inicial</a></p></div>`;
  }
  function adminFirstPwView(){
    return `<h1>Crear contraseña de administrador</h1><div class="box acc-box adm-box"><p>Es tu primer ingreso. Creá una contraseña segura que solo vos conozcas.</p>
<label for="adm-new">Nueva contraseña (mínimo 8 caracteres)</label>${pwInput('adm-new', 'new-password')}
<label for="adm-new2">Confirmar contraseña</label>${pwInput('adm-new2', 'new-password', "if(event.key==='Enter')saveAdminPw()")}
<p id="adm-err" class="acc-err" role="alert" style="display:none"></p>
<button class="btn" onclick="saveAdminPw()">Guardar contraseña y entrar</button>
<p class="acc-switch"><a href="#" onclick="setJoinMode('login');return false">← Volver</a></p></div>`;
  }
  window.adminLogin = async function(){
    if (admBusy) return; admBusy = true;
    try{
      await admReady;
      const pw = (q('#adm-pw') || {}).value || '';
      if (!pw) return admErr('Escribí la contraseña.');
      const cfg = loadAdmCfg();
      if (!cfg.pw || (await hexHash(pw)) !== cfg.pw) return admErr('Contraseña incorrecta.');
      const tt = q('#mt-acc-toast'); if (tt) tt.classList.remove('show');
      if (cfg.firstLogin === true){
        admFirstOk = true; window.joinMode = 'admin-firstpw'; render();
        const f = q('#adm-new'); f && f.focus();
        return;
      }
      enterAdmin();
    } finally { admBusy = false; }
  };
  window.saveAdminPw = async function(){
    if (!admFirstOk) return setJoinMode('admin-login');
    const a = (q('#adm-new') || {}).value || '', b = (q('#adm-new2') || {}).value || '';
    if (a.length < 8) return admErr('La contraseña debe tener al menos 8 caracteres.');
    if (a !== b) return admErr('Las contraseñas no coinciden.');
    if (a === ADM_INITIAL) return admErr('Elegí una contraseña distinta a la inicial.');
    saveAdmCfg({ pw: await hexHash(a), firstLogin: false });
    enterAdmin();
    toast('✅ Contraseña guardada. Bienvenido, administrador.', 'ok');
  };
  window.adminResetInitial = async function(){
    if (!confirm('¿Reiniciar al acceso inicial ' + ADM_INITIAL + '? Deberás crear una nueva contraseña al entrar.')) return;
    saveAdmCfg({ pw: await hexHash(ADM_INITIAL), firstLogin: true });
    toast('Contraseña reiniciada', 'ok');
  };
  window.changeAdminPw = async function(){
    if (!(window.adminLoggedIn && admin)) return;
    const cur = (q('#adm-cur') || {}).value || '', a = (q('#adm-np') || {}).value || '', b = (q('#adm-np2') || {}).value || '';
    const cfg = loadAdmCfg();
    if (!cur || (await hexHash(cur)) !== cfg.pw) return toast('La contraseña actual no es correcta.', 'err');
    if (a.length < 8) return toast('La nueva contraseña debe tener al menos 8 caracteres.', 'err');
    if (a !== b) return toast('Las contraseñas nuevas no coinciden.', 'err');
    if (a === ADM_INITIAL) return toast('Elegí una contraseña distinta a la inicial.', 'err');
    saveAdmCfg({ pw: await hexHash(a), firstLogin: false });
    ['#adm-cur', '#adm-np', '#adm-np2'].forEach(id => { const i = q(id); if (i) i.value = ''; });
    toast('✅ Contraseña actualizada', 'ok');
  };
  window.adminLogout = function(){
    window.adminLoggedIn = false; admin = false; admFirstOk = false;
    document.body.classList.remove('admin-mode');
    window.joinMode = 'login';
    go('home');
  };

  const adminPwSection = () => `<div class="box" id="adm-pw-section" style="border:1px solid var(--ac-ring)">
<b>🔐 Contraseña de administrador</b>
<p><small>Solo vos podés ver esta sección. Cambiá tu contraseña aquí en cualquier momento.</small></p>
<div class="row"><div><label for="adm-cur">Contraseña actual</label>${pwInput('adm-cur', 'current-password', '', 'Contraseña actual')}</div></div>
<div class="row"><div><label for="adm-np">Nueva contraseña (mín. 8 caracteres)</label>${pwInput('adm-np', 'new-password', '', 'Nueva contraseña')}</div><div><label for="adm-np2">Confirmar nueva contraseña</label>${pwInput('adm-np2', 'new-password', "if(event.key==='Enter')changeAdminPw()", 'Confirmar')}</div></div>
<button class="btn" onclick="changeAdminPw()">Cambiar contraseña</button> <button class="btn d s" onclick="adminLogout()">Salir del modo administrador</button></div>`;

  const CRM_BTN = `<div id="crm-btn-wrap"><button class="btn" id="crm-btn" onclick="go('crm')">📊 Panel CRM — Analítica y seguimiento</button></div>`;
  const _admin = views.admin;
  views.admin = function(){
    if (!(window.adminLoggedIn && admin)){ admin = false; return adminLoginView(); }
    const t = document.createElement('template');
    t.innerHTML = _admin.apply(this, arguments);
    // Quitar la sección "Seguridad" del núcleo (mostraba S.pw en texto plano).
    t.content.querySelectorAll('.box').forEach(bx => { const b = bx.querySelector(':scope > b'); if (b && b.textContent.trim() === 'Seguridad') bx.remove(); });
    t.content.querySelectorAll('[onclick*="admin=false"]').forEach(b => b.setAttribute('onclick', 'adminLogout()'));
    const h1 = t.content.querySelector('h1');
    const sec = document.createElement('template'); sec.innerHTML = adminPwSection();
    if (h1) h1.after(sec.content); else t.content.prepend(sec.content);
    const cb = document.createElement('template'); cb.innerHTML = CRM_BTN;
    if (h1) h1.after(cb.content); else t.content.prepend(cb.content);
    const pwBox = t.content.querySelector('#adm-pw-section');
    const nt = document.createElement('template'); nt.innerHTML = payNotifsSection();
    if (pwBox) pwBox.after(nt.content); else t.content.prepend(nt.content);
    t.content.querySelectorAll('.box').forEach(bx => {
      const bb = bx.querySelector(':scope > b');
      if (bb && bb.textContent.trim() === 'QR de pago'){
        const inp = bx.querySelector('input[type=file]'); if (inp) inp.setAttribute('onchange', 'mtSaveQr(this)');
        bb.textContent = 'QR de pago general (suscripciones)';
        if (S.qr) bx.insertAdjacentHTML('beforeend', `<div class="sb-qr-prev sm"><img src="${esc(S.qr)}" alt="QR general actual"></div>`);
        const sq = document.createElement('template'); sq.innerHTML = window.subQrSection() + paypalSection(); bx.after(sq.content);
      }
    });
    const link = promoLink();
    return t.innerHTML + `<div class="box" id="promo-box"><b>🎁 Enlace de prueba de suscripción</b><p><small>Quien abra este enlace y cree (o inicie) su cuenta recibe ${PROMO_DAYS} días de acceso. También puede escribir el código <b>${PROMO_CODE}</b> al registrarse o en Planes.</small></p>
<label for="promo-base">URL pública de la web</label><input id="promo-base" placeholder="https://tu-dominio/medithink.html" value="${esc(promoBase())}" onchange="mtSetPromoBase(this.value)">
<label for="promo-out">Enlace generado</label><input id="promo-out" readonly value="${esc(link)}" onclick="this.select()">
<button class="btn" onclick="mtCopyPromo()">Generar enlace de prueba</button></div>`;
  };
  // Respaldo (cambio 4): si algo re-renderiza el panel sin la sección, se reinyecta.
  new MutationObserver(() => {
    if (admin && window.adminLoggedIn && view === 'admin' && !q('#adm-pw-section')){
      const v = q('#v'); if (v) v.insertAdjacentHTML('afterbegin', adminPwSection());
    }
    if (admin && window.adminLoggedIn && view === 'admin' && !q('#crm-btn')){
      const v = q('#v'); if (v) v.insertAdjacentHTML('afterbegin', CRM_BTN);
    }
  }).observe(q('#v') || document.body, { childList: true });

  /* ---------- Menú de perfil: panel de admin solo en modo admin ---------- */
  const _togPf = window.togPf;
  window.togPf = function(){
    const r = _togPf.apply(this, arguments);
    const p = q('#pf');
    if (p && p.style.display === 'block'){
      p.querySelectorAll('button[onclick*="go(\'admin\')"]').forEach(b => { if (!(window.adminLoggedIn && admin)) b.remove(); });
      if (window.adminLoggedIn && admin && !p.querySelector('.pf-admout')){
        p.insertAdjacentHTML('beforeend', `<button class="ib pf-admout" onclick="togPf();adminLogout()">🚪 Salir del modo administrador</button>`);
      }
    }
    return r;
  };

  /* ======================================================================
     CUADERNO PERSONAL (m.notebook) EN LA BARRA LATERAL
     ====================================================================== */
  let nbTimer = null;
  function setupNbSave(ta){
    if (!ta || ta._nbWired) return;
    ta._nbWired = true;
    ta.oninput = () => {
      const me = myM(); if (!me) return;
      me.notebook = ta.value;
      clearTimeout(nbTimer); nbTimer = setTimeout(() => { save(); const st = q('#nb-state'); if (st) st.textContent = 'Guardado ✓'; }, 800);
      const st = q('#nb-state'); if (st) st.textContent = 'Guardando…';
    };
    ta.onkeydown = e => { if (e.key === 'Escape'){ e.stopPropagation(); toggleNotebook(); } };
  }
  window.setupNbSave = setupNbSave;
  // El panel vive fuera de #rail: aside usa backdrop-filter y eso rompería position:fixed.
  function nbHost(){ let h = q('#nb-host'); if (!h){ h = document.createElement('div'); h.id = 'nb-host'; document.body.appendChild(h); } return h; }
  function notebookHtml(me){
    const open = !!me._nbOpen;
    return `<div class="nb-toggle"><button class="tb nb-btn ${open ? 'on' : ''}" data-tip="Mi cuaderno" aria-label="Cuaderno personal" aria-expanded="${open}" onclick="toggleNotebook()">📓</button></div>`
      + (open ? `<div class="nb-panel" id="nb-panel" role="dialog" aria-label="Mi cuaderno"><div class="nb-head"><span>📓 Mi cuaderno</span><button class="ib icon-only s" onclick="toggleNotebook()" aria-label="Cerrar cuaderno">✕</button></div><textarea id="nb-text" placeholder="Escribí tus anotaciones aquí. Solo vos podés verlas." aria-label="Cuaderno personal">${esc(me.notebook || '')}</textarea><div class="nb-foot"><small>Solo visible para vos. Se guarda automáticamente.</small> <small id="nb-state" aria-live="polite"></small></div></div>` : '');
  }
  const _rail = window.rail;
  window.rail = function(){
    // Sin pestañas de "apuntes de tema" (S.tabs) ni botón ＋: el rail queda solo con el cuaderno 📓.
    const r = undefined, me = myM(), el = q('#rail'), host = nbHost();
    if (el) el.innerHTML = '';
    const show = !!(me && el && !admin);
    const prev = q('#nb-text');
    const keepFocus = show && me._nbOpen && prev && document.activeElement === prev;
    if (show){
      const t = document.createElement('template'); t.innerHTML = notebookHtml(me);
      const panel = t.content.querySelector('#nb-panel');
      if (panel) panel.remove();
      el.appendChild(t.content);
      if (panel && keepFocus){ /* conservar el textarea en uso (cursor y foco) */ }
      else { host.innerHTML = ''; if (panel){ host.appendChild(panel); setupNbSave(q('#nb-text')); } }
      if (!panel) host.innerHTML = '';
    } else host.innerHTML = '';
    return r;
  };
  window.toggleNotebook = function(){
    const me = myM(); if (!me) return;
    const ta = q('#nb-text'); if (ta) me.notebook = ta.value;
    clearTimeout(nbTimer);
    me._nbOpen = !me._nbOpen;
    save();
    rail();
    if (me._nbOpen) setTimeout(() => { const t = q('#nb-text'); if (t){ t.focus(); t.setSelectionRange(t.value.length, t.value.length); } }, 50);
    else { const b = q('#rail .nb-btn'); b && b.focus(); }
  };

  /* ======================================================================
     CRM DEL ADMINISTRADOR (vista 'crm') — solo con adminLoggedIn && admin
     ====================================================================== */
  let crmTab = 'resumen';
  let crmFilter = { q: '', estado: '', carrera: '', orden: 'reciente' };
  const CRM_TABS = [['resumen', '📈 Resumen'], ['miembros', '👥 Miembros'], ['contenido', '📚 Contenido'], ['retencion', '🔁 Retención'], ['comunicaciones', '✉️ Comunicaciones'], ['moderacion', '🛡️ Moderación']];
  const isAdm = () => !!(window.adminLoggedIn && admin);
  const fmtDate = ts => ts ? new Date(ts).toLocaleDateString('es', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
  const pct = (a, b) => b ? Math.round(a / b * 100) : 0;
  const joinedAt = m => m.joinTs || (typeof joinTs === 'function' ? joinTs(m) : 0) || 0;
  const waLink = (num, txt) => { const d = String(num || '').replace(/\D/g, ''); return d ? 'https://wa.me/' + d + (txt ? '?text=' + encodeURIComponent(txt) : '') : ''; };

  /* --- Seguimiento adicional (sin tocar el núcleo) --- */
  // m.done: copia de los temas completados del miembro con sesión; m.lastSeen: última actividad.
  const _updProg = window.updProg;
  window.updProg = function(){ const r = _updProg.apply(this, arguments); const m = myM(); if (m){ m.done = Object.assign({}, S.done); m.lastSeen = Date.now(); save(); } return r; };
  let seenSaved = 0;
  function touchSeen(){ const m = myM(); if (!m || admin) return; m.lastSeen = Date.now(); if (Date.now() - seenSaved > 60000){ seenSaved = Date.now(); save(); } }

  function crmFormatSec(sec){
    sec = Math.max(0, +sec || 0);
    const h = Math.floor(sec / 3600), mi = Math.floor((sec % 3600) / 60);
    return `${h} h ${String(mi).padStart(2, '0')} min`;
  }
  function crmDaysAgo(ts){
    if (!ts) return '—';
    const d = Math.floor((Date.now() - ts) / DAYMS);
    return d <= 0 ? 'hoy' : d === 1 ? 'ayer' : `hace ${d} días`;
  }
  function crmMemberStatus(m){
    const now = Date.now();
    if (isPaid(m)) return { key: 'paid', label: '🟢 Pagado', pillClass: 'pill-paid' };
    if (m.trialEnd && m.trialEnd > now){ const d = Math.ceil((m.trialEnd - now) / DAYMS); return { key: 'trial', label: `🟡 Trial (${d} ${d === 1 ? 'día' : 'días'})`, pillClass: 'pill-trial' }; }
    if (m.trialEnd) return { key: 'exp', label: '🔴 Expirado', pillClass: 'pill-exp' };
    return { key: 'free', label: '⚪ Sin suscripción', pillClass: 'pill-free' };
  }
  const memberDone = m => (m.done && typeof m.done === 'object') ? m.done : {};
  const doneCount = m => Math.max(Object.keys(memberDone(m)).length, +m.adv || 0);
  // Conjuntos de temas completados: uno por miembro con m.done; si ninguno lo tiene, el global S.done.
  function doneSets(){
    const sets = (S.members || []).map(memberDone).filter(d => Object.keys(d).length);
    if (!sets.length && Object.keys(S.done || {}).length) sets.push(S.done);
    return sets;
  }

  function crmMetrics(){
    const now = Date.now(), DAY = DAYMS, members = S.members || [], total = members.length;
    const st = members.map(crmMemberStatus);
    const paid = st.filter(s => s.key === 'paid').length;
    const trial = st.filter(s => s.key === 'trial').length;
    const expired = total - paid - trial;
    const convRate = pct(paid, total);
    const newLast7 = members.filter(m => joinedAt(m) > now - 7 * DAY).length;
    const newLast30 = members.filter(m => joinedAt(m) > now - 30 * DAY).length;
    const activeLast7 = members.filter(m => (m.lastSeen || joinedAt(m)) > now - 7 * DAY).length;
    const trialExpiring2d = members.filter(m => !isPaid(m) && m.trialEnd && m.trialEnd > now && m.trialEnd - now <= 2 * DAY).length;
    const avgStudyMin = total ? Math.round(members.reduce((a, m) => a + (+m.sec || 0), 0) / total / 60) : 0;
    const totalAdvanced = members.reduce((a, m) => a + (+m.adv || 0), 0);
    return { total, paid, trial, expired, convRate, newLast7, newLast30, activeLast7, trialExpiring2d, avgStudyMin, totalAdvanced };
  }
  function crmWeeklyNew(n){
    const now = Date.now(), W = 7 * DAYMS, out = [];
    for (let i = n - 1; i >= 0; i--){
      const to = now - i * W, from = to - W;
      out.push({ label: i === 0 ? 'Esta sem.' : `Hace ${i} sem.`, from, to, count: (S.members || []).filter(m => { const j = joinedAt(m); return j > from && j <= to; }).length });
    }
    return out;
  }
  function crmSubjectStats(){
    const sets = doneSets(), perMember = (S.members || []).some(m => Object.keys(memberDone(m)).length);
    return (S.subjects || []).map(s => {
      const L = lessons(s), ids = new Set(L.map(l => s.id + ':' + l.id)), pre = s.id + ':';
      const counts = sets.map(d => Object.keys(d).filter(k => k.startsWith(pre) && (ids.size ? ids.has(k) : true)).length);
      const withProg = counts.filter(c => c > 0).length;
      const completed = counts.reduce((a, c) => a + c, 0);
      const avg = L.length && sets.length ? Math.round(counts.reduce((a, c) => a + Math.min(1, c / L.length), 0) / (perMember ? (S.members || []).length || 1 : sets.length) * 100) : 0;
      return { s, lessons: L.length, withProg: perMember ? withProg : (withProg ? '—' : 0), completed, avg, pub: s.pub !== false };
    });
  }
  function crmTopLessons(){
    const tally = {};
    doneSets().forEach(d => Object.keys(d).forEach(k => { tally[k] = (tally[k] || 0) + 1; }));
    return Object.entries(tally).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([k, c]) => {
      const [sid, lid] = k.split(':'), s = (S.subjects || []).find(x => String(x.id) === sid);
      const l = s ? lessons(s).find(x => String(x.id) === lid) : null;
      return { key: k, subject: s ? s.n : 'Materia eliminada', lesson: l ? l.t : 'Tema eliminado', count: c };
    });
  }
  function crmFilterMembers(){
    const f = crmFilter, qq = f.q.trim().toLowerCase(), now = Date.now();
    let list = (S.members || []).filter(m => {
      if (qq && ![m.n, m.e, m.uni, m.pais].some(x => String(x || '').toLowerCase().includes(qq))) return false;
      const k = crmMemberStatus(m).key;
      if (f.estado === 'paid' && k !== 'paid') return false;
      if (f.estado === 'trial' && k !== 'trial') return false;
      if (f.estado === 'none' && (k === 'paid' || k === 'trial')) return false;
      if (f.carrera && (m.car || '') !== f.carrera) return false;
      return true;
    });
    const cmp = {
      nombre: (a, b) => String(a.n || '').localeCompare(String(b.n || ''), 'es'),
      reciente: (a, b) => joinedAt(b) - joinedAt(a),
      activo: (a, b) => (+b.sec || 0) - (+a.sec || 0),
      trial: (a, b) => { const x = a.trialEnd && a.trialEnd > now && !isPaid(a) ? a.trialEnd : Infinity, y = b.trialEnd && b.trialEnd > now && !isPaid(b) ? b.trialEnd : Infinity; return x - y; }
    }[f.orden] || (() => 0);
    return list.slice().sort(cmp);
  }
  function segmentMembers(seg){
    const all = S.members || [];
    switch (seg){
      case 'paid': return all.filter(m => crmMemberStatus(m).key === 'paid');
      case 'trial': return all.filter(m => crmMemberStatus(m).key === 'trial');
      case 'exp': return all.filter(m => ['exp', 'free'].includes(crmMemberStatus(m).key));
      case 'inactive': return all.filter(isInactive);
      default: return all.slice();
    }
  }
  const isInactive = m => !(+m.sec > 0) || !(+m.adv > 0);
  const SEGMENTS = [['all', 'Todos'], ['paid', 'Solo pagados'], ['trial', 'Solo en trial'], ['exp', 'Solo expirados / sin acceso'], ['inactive', 'Solo inactivos']];

  /* --- Acciones --- */
  window.setMemberPaid = function(id, paid){
    if (!isAdm()) return;
    const m = (S.members || []).find(x => x.id === id); if (!m) return;
    m.paid = !!paid; m.paidUntil = 0;
    if (!paid){ delete m.promo; }
    save(); toast(paid ? `✅ ${m.n} marcado como pagado` : `Pago quitado a ${m.n}`, paid ? 'ok' : '');
    crmRefresh();
  };
  window.crmRemoveMember = function(id){
    if (!isAdm()) return;
    const i = (S.members || []).findIndex(x => x.id === id); if (i < 0) return;
    if (!confirm(`¿Quitar a ${S.members[i].n} (${S.members[i].e})? Esta acción no se puede deshacer.`)) return;
    S.members.splice(i, 1); save(); toast('Miembro quitado'); crmRefresh();
  };
  window.crmResetLink = id => { const i = S.members.findIndex(x => x.id === id); if (i >= 0) adminResetLink(i); };
  window.crmResetGmail = id => { const i = S.members.findIndex(x => x.id === id); if (i >= 0) adminResetGmail(i); };
  window.crmGmailTo = function(id){
    const m = S.members.find(x => x.id === id); if (!m) return;
    try{ window.open(gmailUrl(m.e, 'MEDITHINK', `Hola ${m.n},\n\n`), '_blank', 'noopener'); }catch(e){}
  };
  function csvCell(v){ v = String(v ?? ''); return /[",;\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }
  window.crmExportCSV = function(){
    if (!isAdm()) return;
    const head = ['Nombre', 'Email', 'WhatsApp', 'Carrera', 'Año', 'Universidad', 'País', 'Estado', 'Tiempo estudio (min)', 'Temas completados', 'Fecha ingreso', 'Trial hasta'];
    const rows = crmFilterMembers().map(m => [m.n, m.e, m.w, m.car, m.yr, m.uni, m.pais, crmMemberStatus(m).label.replace(/^\S+\s/, ''), Math.round((+m.sec || 0) / 60), doneCount(m), joinedAt(m) ? new Date(joinedAt(m)).toISOString().slice(0, 10) : '', m.trialEnd ? new Date(m.trialEnd).toISOString().slice(0, 10) : '']);
    const csv = [head, ...rows].map(r => r.map(csvCell).join(',')).join('\r\n');
    window.crmLastCSV = csv;
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    const dt = new Date(), p2 = n => String(n).padStart(2, '0');
    a.download = `medithink_miembros_${dt.getFullYear()}-${p2(dt.getMonth() + 1)}-${p2(dt.getDate())}.csv`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    toast(`⬇️ CSV generado (${rows.length} miembros)`, 'ok');
  };
  window.crmBulkGmail = function(segment){
    if (!isAdm()) return;
    const seg = segment || (q('#cm-seg') || {}).value || 'all';
    const subject = ((q('#cm-subj') || {}).value || '').trim(), body = ((q('#cm-msg') || {}).value || '').trim();
    if (!subject || !body) return toast('Escribí el asunto y el mensaje.', 'err');
    const emails = segmentMembers(seg).map(m => m.e).filter(Boolean);
    if (!emails.length) return toast('No hay destinatarios en ese segmento.', 'err');
    const batches = [];
    for (let i = 0; i < emails.length; i += 50) batches.push(emails.slice(i, i + 50));
    const url = b => `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(S.adminEmail || '')}&bcc=${encodeURIComponent(b.join(','))}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    try{ window.open(url(batches[0]), '_blank', 'noopener'); }catch(e){}
    const out = q('#cm-batches');
    if (out) out.innerHTML = `<div class="box ok-box"><b>✅ Se abrió Gmail con ${batches[0].length} destinatario(s) en BCC.</b>${batches.length > 1 ? `<p>Hay ${emails.length} destinatarios: abrí los lotes restantes uno por uno.</p>` + batches.map((b, i) => `<a class="btn o s" target="_blank" rel="noopener" href="${esc(url(b))}">Lote ${i + 1} (${i * 50 + 1}–${i * 50 + b.length})</a>`).join(' ') : ''}</div>`;
    window.crmLastBatches = batches.length;
  };
  window.crmCopyWA = async function(segment){
    if (!isAdm()) return;
    const seg = segment || (q('#wa-seg') || {}).value || 'all';
    const msg = ((q('#wa-msg') || {}).value || '').trim();
    if (!msg) return toast('Escribí el mensaje.', 'err');
    const list = segmentMembers(seg);
    const nums = list.map(m => m.w).filter(Boolean);
    const txt = msg;
    window.crmLastWA = txt;
    const ok = await copyText(txt);
    toast(ok ? 'Texto copiado. Pegalo en tu grupo o broadcast de WhatsApp.' : 'Copiá el texto manualmente.', ok ? 'ok' : '');
    const out = q('#wa-out');
    if (out) out.innerHTML = `<p><small>Segmento: ${list.length} miembro(s), ${nums.length} con WhatsApp. Números: ${esc(nums.join(', ') || '—')}</small></p>`;
  };
  window.crmPublishNote = function(){
    if (!isAdm()) return;
    const t = ((q('#cm-subj') || {}).value || '').trim(), x = ((q('#cm-msg') || {}).value || '').trim();
    if (!t || !x) return toast('Escribí el asunto y el mensaje.', 'err');
    S.notes = S.notes || []; S.notes.push({ t, x, d: new Date().toLocaleDateString('es') }); save();
    toast('🔔 Comunicado publicado en la app', 'ok'); crmRefresh();
  };
  window.crmDelNote = function(i){
    if (!isAdm() || !S.notes || !S.notes[i]) return;
    if (!confirm('¿Eliminar este comunicado?')) return;
    S.notes.splice(i, 1); S.seen = Math.min(S.seen || 0, S.notes.length); save(); crmRefresh();
  };
  const TEMPLATES = {
    bienvenida: ['¡Bienvenido/a a MEDITHINK!', 'Hola 👋\n\n¡Bienvenido/a a MEDITHINK! Ya podés explorar las materias, marcar tus temas avanzados y sumar puntos en el Score. Si tenés dudas, escribinos por el chat de soporte.\n\n¡Éxitos en tu estudio!'],
    trial: ['Tu prueba gratuita está por vencer', 'Hola 👋\n\nTe recordamos que tu prueba gratuita de MEDITHINK vence en los próximos días. Activá tu plan para seguir estudiando sin interrupciones.\n\nCualquier consulta, respondé este mensaje.'],
    contenido: ['Nuevo contenido disponible 🎓', 'Hola 👋\n\nSubimos nuevo contenido a MEDITHINK: nuevos temas, videos y resúmenes ya están disponibles en la sección Materias.\n\n¡Te esperamos!'],
    pago: ['Recordatorio de pago', 'Hola 👋\n\nTe recordamos que tu suscripción de MEDITHINK está pendiente de pago. Podés renovarla desde la sección Planes.\n\nGracias por estudiar con nosotros.']
  };
  window.crmTemplate = function(k){
    const t = TEMPLATES[k]; if (!t) return;
    const s = q('#cm-subj'), m = q('#cm-msg'), w = q('#wa-msg');
    if (s) s.value = t[0]; if (m) m.value = t[1]; if (w) w.value = t[1];
    toast('Plantilla cargada', 'ok');
  };
  window.crmRemindAll = function(){
    if (!isAdm()) return;
    const list = riskMembers().filter(m => m.w);
    if (!list.length) return toast('Ningún miembro en riesgo tiene WhatsApp.', 'err');
    const m = list[0];
    try{ window.open(waLink(m.w, `Hola ${m.n} 👋 Tu prueba gratuita de MEDITHINK vence el ${fmtDate(m.trialEnd)}. ¡Activá tu plan para seguir estudiando!`), '_blank', 'noopener'); }catch(e){}
    toast(list.length > 1 ? `Se abrió WhatsApp de ${m.n}. Usá los botones 💬 para los otros ${list.length - 1}.` : `Se abrió WhatsApp de ${m.n}.`, 'ok');
  };

  /* --- Navegación interna --- */
  window.crmSetTab = function(t){ crmTab = t; const v = q('#v'); if (v){ v.innerHTML = renderCRM(); v.scrollTop = 0; } scrollTo(0, 0); };
  window.crmSetFilter = function(k, val){ crmFilter[k] = val; const box = q('#crm-mtable'); if (box) box.innerHTML = crmMembersTable(); };
  window.crmGoMembers = function(estado, orden){ crmFilter = Object.assign(crmFilter, { estado: estado || '', orden: orden || crmFilter.orden, q: '', carrera: '' }); crmSetTab('miembros'); };
  function crmRefresh(){ if (view === 'crm'){ const v = q('#v'); if (v) v.innerHTML = renderCRM(); } else render(); }

  /* --- Vistas --- */
  function renderCRM(){
    if (!isAdm()) return adminLoginView();
    const body = { resumen: crmResumen, miembros: crmMiembros, contenido: crmContenido, retencion: crmRetencion, comunicaciones: crmComunicaciones, moderacion: crmModeracion }[crmTab] || crmResumen;
    return `<div class="crm-wrap"><div class="crm-head"><button class="btn o s" onclick="go('admin')">← Volver al panel</button><h1>📊 CRM — Analítica y seguimiento</h1></div>
<div class="crm-tabs" role="tablist">${CRM_TABS.map(([k, l]) => `<button role="tab" aria-selected="${crmTab === k}" class="${crmTab === k ? 'on' : ''}" data-tab="${k}" onclick="crmSetTab('${k}')">${l}</button>`).join('')}</div>
<div class="crm-body" role="tabpanel">${body()}</div></div>`;
  }
  window.renderCRM = renderCRM;

  function crmResumen(){
    const k = crmMetrics(), w = crmWeeklyNew(4), maxW = Math.max(1, ...w.map(x => x.count));
    const kpis = [['👥', k.total, 'Total miembros'], ['✅', k.paid, 'Pagados'], ['🕐', k.trial, 'En prueba'], ['❌', k.expired, 'Expirados / sin acceso'], ['📈', k.convRate + '%', 'Tasa de conversión'], ['🆕', k.newLast7, 'Nuevos esta semana'], ['⚡', k.activeLast7, 'Activos esta semana'], ['⏱️', crmFormatSec(k.avgStudyMin * 60), 'Estudio promedio']];
    const top = crmSubjectStats().filter(x => x.completed > 0).sort((a, b) => b.completed - a.completed).slice(0, 3);
    const seg = (n, cls, lbl) => n ? `<div class="${cls}" style="width:${pct(n, k.total)}%" title="${lbl}: ${n}"></div>` : '';
    return (k.trialExpiring2d ? `<div class="crm-alert" role="alert">⚠️ <span><b>${k.trialExpiring2d} miembro(s)</b> con la prueba por vencer en 2 días o menos.</span> <button class="btn s" onclick="crmGoMembers('trial','trial')">Ver en Miembros</button></div>` : '')
      + `<div class="kpi-grid">${kpis.map(([i, n, l]) => `<div class="kpi-card"><div class="kpi-ic" aria-hidden="true">${i}</div><div class="kpi-num">${esc(n)}</div><div class="kpi-lbl">${l}</div></div>`).join('')}</div>
<div class="crm-cols"><div class="box"><b>Estado de miembros</b>${k.total ? `<div class="seg-bar" role="img" aria-label="Pagados ${k.paid}, en prueba ${k.trial}, sin acceso ${k.expired}">${seg(k.paid, 'seg-bar-paid', 'Pagados')}${seg(k.trial, 'seg-bar-trial', 'En prueba')}${seg(k.expired, 'seg-bar-exp', 'Sin acceso')}</div>` : '<div class="seg-bar empty"></div>'}
<div class="seg-legend"><span><i class="seg-bar-paid"></i>Pagados ${k.paid} (${pct(k.paid, k.total)}%)</span><span><i class="seg-bar-trial"></i>Prueba ${k.trial} (${pct(k.trial, k.total)}%)</span><span><i class="seg-bar-exp"></i>Sin acceso ${k.expired} (${pct(k.expired, k.total)}%)</span></div>
<p><small>Nuevos en 30 días: <b>${k.newLast30}</b> · Temas avanzados (suma): <b>${k.totalAdvanced}</b></small></p></div>
<div class="box"><b>Nuevos por semana</b><div class="mini-bars" role="img" aria-label="Registros de las últimas 4 semanas">${w.map(x => `<div class="mini-bar-col" title="${x.label}: ${x.count}"><span class="bar-val">${x.count}</span><div class="bar-body" style="height:${Math.round(x.count / maxW * 56)}px"></div><span class="bar-lbl">${x.label}</span></div>`).join('')}</div></div></div>
<div class="box"><b>🏆 Top 3 materias con más avances</b>${top.length ? `<ol class="crm-top">${top.map(x => `<li><b>${esc(x.s.icon || '')} ${esc(x.s.n)}</b> <small>${x.completed} tema(s) completado(s)</small></li>`).join('')}</ol>` : '<p><small>Todavía no hay temas completados.</small></p>'}</div>`;
  }

  function crmMembersTable(){
    const list = crmFilterMembers(), total = (S.members || []).length;
    const rows = list.map((m, i) => {
      const st = crmMemberStatus(m), wa = waLink(m.w), paid = st.key === 'paid';
      return `<tr><td>${i + 1}</td><td>${avHtml(m.photo, m.n, 30)}</td><td><b>${esc(m.n)}</b></td><td class="crm-mail">${esc(m.e)}</td><td>${esc(m.car || '—')}${m.yr ? ' · ' + esc(m.yr) + '°' : ''}</td><td><span class="${st.pillClass}">${st.label}</span></td><td>${crmFormatSec(m.sec)}</td><td>${doneCount(m)}</td><td title="${fmtDate(joinedAt(m))}">${crmDaysAgo(joinedAt(m))}</td>
<td><div class="crm-acts"><button class="btn o s" title="Escribir por Gmail" aria-label="Gmail a ${esc(m.n)}" onclick="crmGmailTo('${m.id}')">✉️</button>${wa ? `<a class="btn o s" title="WhatsApp" aria-label="WhatsApp a ${esc(m.n)}" target="_blank" rel="noopener" href="${esc(wa)}">💬</a>` : ''}<button class="btn o s" title="Copiar enlace de recuperación" aria-label="Enlace de recuperación de ${esc(m.n)}" onclick="crmResetLink('${m.id}')">🔑</button><button class="btn o s" title="Enviar enlace de recuperación por Gmail" aria-label="Enviar recuperación por Gmail a ${esc(m.n)}" onclick="crmResetGmail('${m.id}')">📧</button>${accessCtl(m)}<button class="btn d s" title="Quitar miembro" aria-label="Quitar a ${esc(m.n)}" onclick="crmRemoveMember('${m.id}')">🗑️</button></div></td></tr>${accessForm(m) ? `<tr class="acc-row"><td colspan="10">${accessForm(m)}</td></tr>` : ''}${memberSubjects(m) ? `<tr class="sb-row"><td colspan="10">${memberSubjects(m)}</td></tr>` : ''}`;
    }).join('');
    return `<p class="crm-count">Mostrando <b>${list.length}</b> de <b>${total}</b> miembros</p>
<div class="crm-table-wrap"><table class="crm-table"><thead><tr><th>#</th><th>Avatar</th><th>Nombre</th><th>Correo</th><th>Carrera/Año</th><th>Estado</th><th>Tiempo estudio</th><th>Temas</th><th>Ingresó</th><th>Acciones</th></tr></thead><tbody>${rows || '<tr><td colspan="10"><small>No hay miembros que coincidan con los filtros.</small></td></tr>'}</tbody></table></div>`;
  }
  function crmMiembros(){
    const f = crmFilter, cars = [...new Set((S.members || []).map(m => m.car).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es'));
    const opt = (v, l, cur) => `<option value="${esc(v)}" ${cur === v ? 'selected' : ''}>${esc(l)}</option>`;
    return `<div class="crm-filters">
<input id="crm-q" type="search" placeholder="Buscar por nombre, correo, universidad o país" aria-label="Buscar miembros" value="${esc(f.q)}" oninput="crmSetFilter('q',this.value)">
<select id="crm-estado" aria-label="Estado" onchange="crmSetFilter('estado',this.value)">${opt('', 'Todos los estados', f.estado)}${opt('paid', 'Pagado', f.estado)}${opt('trial', 'En prueba', f.estado)}${opt('none', 'Sin acceso', f.estado)}</select>
<select id="crm-carrera" aria-label="Carrera" onchange="crmSetFilter('carrera',this.value)">${opt('', 'Todas las carreras', f.carrera)}${cars.map(c => opt(c, c, f.carrera)).join('')}</select>
<select id="crm-orden" aria-label="Ordenar por" onchange="crmSetFilter('orden',this.value)">${opt('nombre', 'Nombre A-Z', f.orden)}${opt('reciente', 'Más recientes', f.orden)}${opt('activo', 'Más activos', f.orden)}${opt('trial', 'Trial por vencer', f.orden)}</select>
<button class="btn" onclick="crmExportCSV()">⬇️ Exportar CSV</button></div>
<div id="crm-mtable">${crmMembersTable()}</div>`;
  }

  function crmContenido(){
    const stats = crmSubjectStats(), top = crmTopLessons(), perMember = (S.members || []).some(m => Object.keys(memberDone(m)).length);
    const idle = stats.filter(x => x.pub && x.completed === 0);
    return `<div class="box"><b>Materias</b>${perMember ? '' : '<p><small>ℹ️ Aún no hay avances registrados por miembro: se muestran los temas completados guardados en este navegador.</small></p>'}
<div class="crm-table-wrap"><table class="crm-table"><thead><tr><th>Materia</th><th>Tipo</th><th>Temas</th><th>Miembros con avance</th><th>Temas completados (total)</th><th>Progreso promedio</th><th>Tiempo dedicado</th><th>Publicada</th></tr></thead><tbody>
${stats.map(x => `<tr><td><b>${esc(x.s.icon || '')} ${esc(x.s.n)}</b></td><td>${esc(x.s.kind || '—')}</td><td>${x.lessons}</td><td>${x.withProg}</td><td>${x.completed}</td><td><div class="prog-cell"><div class="prog-bar"><i style="width:${x.avg}%"></i></div><small>${x.avg}%</small></div></td><td>—</td><td>${x.pub ? '✅ Sí' : '📝 Borrador'}</td></tr>`).join('') || '<tr><td colspan="8"><small>No hay materias.</small></td></tr>'}
</tbody></table></div></div>
<div class="box"><b>🔝 Temas más completados</b>${top.length ? `<div class="crm-table-wrap"><table class="crm-table"><thead><tr><th>#</th><th>Materia</th><th>Tema</th><th>Veces completado</th></tr></thead><tbody>${top.map((t, i) => `<tr><td>${i + 1}</td><td>${esc(t.subject)}</td><td>${esc(t.lesson)}</td><td>${t.count}</td></tr>`).join('')}</tbody></table></div>` : '<p><small>Todavía no hay temas completados.</small></p>'}</div>
<div class="box"><b>💤 Materias sin actividad</b>${idle.length ? `<ul class="crm-list">${idle.map(x => `<li><b>${esc(x.s.icon || '')} ${esc(x.s.n)}</b> <small>— Considerá revisar el contenido o la comunicación de esta materia.</small></li>`).join('')}</ul>` : '<p><small>Todas las materias publicadas tienen actividad.</small></p>'}</div>`;
  }

  function riskMembers(){ const now = Date.now(); return (S.members || []).filter(m => !isPaid(m) && m.trialEnd && m.trialEnd > now && m.trialEnd - now <= 3 * DAYMS).sort((a, b) => a.trialEnd - b.trialEnd); }
  function contactBtns(m, txt){
    const wa = waLink(m.w, txt);
    return `<div class="crm-acts">${wa ? `<a class="btn o s" target="_blank" rel="noopener" href="${esc(wa)}" aria-label="WhatsApp a ${esc(m.n)}">💬 WhatsApp</a>` : ''}<button class="btn o s" onclick="crmGmailTo('${m.id}')" aria-label="Gmail a ${esc(m.n)}">✉️ Gmail</button></div>`;
  }
  function crmRetencion(){
    const k = crmMetrics(), risk = riskMembers(), now = Date.now();
    const inactive = (S.members || []).filter(isInactive).sort((a, b) => joinedAt(a) - joinedAt(b));
    const top = (S.members || []).slice().sort((a, b) => (+b.sec || 0) - (+a.sec || 0)).slice(0, 10);
    const recent = (S.members || []).filter(m => joinedAt(m) > now - 7 * DAYMS).sort((a, b) => joinedAt(b) - joinedAt(a));
    const withAdv = (S.members || []).filter(m => +m.adv > 0 || Object.keys(memberDone(m)).length).length;
    const funnel = [['Registrados', k.total, 'var(--ac)'], ['Con al menos 1 tema', withAdv, 'var(--ac2)'], ['Con prueba activa', k.trial, 'var(--warn)'], ['Pagados', k.paid, 'var(--ok)']];
    return `<div class="box"><b>⚠️ Miembros en riesgo (prueba vence en ≤ 3 días): ${risk.length}</b>
${risk.length ? `<div class="crm-table-wrap"><table class="crm-table"><thead><tr><th>Nombre</th><th>Email</th><th>Fin de prueba</th><th>Acciones</th></tr></thead><tbody>${risk.map(m => `<tr><td><b>${esc(m.n)}</b></td><td class="crm-mail">${esc(m.e)}</td><td>${fmtDate(m.trialEnd)}</td><td>${contactBtns(m, `Hola ${m.n} 👋 Tu prueba gratuita de MEDITHINK vence el ${fmtDate(m.trialEnd)}. ¡Activá tu plan para seguir estudiando!`)}</td></tr>`).join('')}</tbody></table></div>
<button class="btn" onclick="crmRemindAll()">📲 Enviar recordatorio a todos por WhatsApp</button><p><small>Sin servidor, WhatsApp solo permite abrir un chat a la vez: se abre el primero de la lista y los demás se contactan con su botón 💬.</small></p>` : '<p><small>No hay miembros en riesgo.</small></p>'}</div>
<div class="box"><b>📉 Embudo de conversión</b>${funnel.map(([l, n, c]) => `<div class="funnel-row"><span class="funnel-label">${l}</span><div class="funnel-bar-wrap"><div class="funnel-bar" style="width:${k.total ? Math.max(pct(n, k.total), n ? 6 : 0) : 0}%;background:${c}">${pct(n, k.total)}%</div></div><span class="funnel-count">${n}</span></div>`).join('')}</div>
<div class="box"><b>😴 Miembros inactivos (sin tiempo de estudio o sin temas completados): ${inactive.length}</b>${inactive.length ? `<ul class="crm-list">${inactive.map(m => `<li><div><b>${esc(m.n)}</b> <small>${esc(m.e)} · ingresó el ${fmtDate(joinedAt(m))} (${crmDaysAgo(joinedAt(m))})</small></div>${contactBtns(m, `Hola ${m.n} 👋 ¿Cómo va tu estudio? Entrá a MEDITHINK y empezá con tu primer tema.`)}</li>`).join('')}</ul>` : '<p><small>Todos los miembros tienen actividad.</small></p>'}</div>
<div class="box"><b>🔥 Miembros más activos</b>${top.length ? `<div class="crm-table-wrap"><table class="crm-table"><thead><tr><th>#</th><th>Nombre</th><th>Tiempo total</th><th>Temas completados</th><th>Estado</th></tr></thead><tbody>${top.map((m, i) => { const st = crmMemberStatus(m); return `<tr><td>${i + 1}</td><td><b>${esc(m.n)}</b></td><td>${crmFormatSec(m.sec)}</td><td>${doneCount(m)}</td><td><span class="${st.pillClass}">${st.label}</span></td></tr>`; }).join('')}</tbody></table></div>` : '<p><small>Aún no hay miembros.</small></p>'}</div>
<div class="box"><b>🆕 Nuevos en los últimos 7 días: ${recent.length}</b>${recent.length ? `<ul class="crm-list">${recent.map(m => `<li><div><b>${esc(m.n)}</b> <small>${esc(m.car || '—')} · ${esc(m.pais || '—')} · ${crmDaysAgo(joinedAt(m))}</small></div></li>`).join('')}</ul>` : '<p><small>No hubo registros esta semana.</small></p>'}</div>`;
  }

  function crmComunicaciones(){
    const segSel = id => `<select id="${id}" aria-label="Destinatarios">${SEGMENTS.map(([v, l]) => `<option value="${v}">${l} (${segmentMembers(v).length})</option>`).join('')}</select>`;
    const notes = (S.notes || []).map((n, i) => ({ n, i })).reverse();
    return `<div class="box"><b>⚡ Plantillas rápidas</b><div class="tpl-chips"><button class="tpl-chip" onclick="crmTemplate('bienvenida')">🎉 Bienvenida a nuevo miembro</button><button class="tpl-chip" onclick="crmTemplate('trial')">⏰ Recordatorio de trial por vencer</button><button class="tpl-chip" onclick="crmTemplate('contenido')">🎓 Nuevo contenido disponible</button><button class="tpl-chip" onclick="crmTemplate('pago')">💳 Recordatorio de pago</button></div><small>Cargan el asunto y el mensaje en los formularios de correo y WhatsApp.</small></div>
<div class="box"><b>✉️ Enviar comunicado por correo</b>
<label for="cm-seg">Destinatarios</label>${segSel('cm-seg')}
<label for="cm-subj">Asunto</label><input id="cm-subj" placeholder="Asunto del correo">
<label for="cm-msg">Mensaje</label><textarea id="cm-msg" rows="6" placeholder="Escribí tu mensaje"></textarea>
<div class="crm-acts"><button class="btn" onclick="crmBulkGmail()">✉️ Abrir Gmail para enviar a todos</button><button class="btn o" onclick="crmPublishNote()">🔔 Publicar también como comunicado en la app</button></div>
<p><small>Se abrirá Gmail con los correos en BCC. Para más de 50 destinatarios, se envían en lotes.</small></p><div id="cm-batches" aria-live="polite"></div></div>
<div class="box"><b>📲 Mensaje para WhatsApp</b>
<label for="wa-seg">Destinatarios</label>${segSel('wa-seg')}
<label for="wa-msg">Mensaje</label><textarea id="wa-msg" rows="5" placeholder="Escribí tu mensaje"></textarea>
<button class="btn" onclick="crmCopyWA()">📲 Preparar mensaje para WhatsApp</button><div id="wa-out" aria-live="polite"></div></div>
<div class="box"><b>🗂️ Historial de comunicados (${notes.length})</b>${notes.length ? `<div class="crm-table-wrap"><table class="crm-table"><thead><tr><th>Fecha</th><th>Título</th><th>Vista previa</th><th></th></tr></thead><tbody>${notes.map(({ n, i }) => `<tr><td>${esc(n.d || '—')}</td><td><b>${esc(n.t)}</b></td><td class="crm-prev">${esc(String(n.x || '').slice(0, 90))}${String(n.x || '').length > 90 ? '…' : ''}</td><td><button class="btn d s" aria-label="Eliminar comunicado ${esc(n.t)}" onclick="crmDelNote(${i})">🗑️ Eliminar</button></td></tr>`).join('')}</tbody></table></div>` : '<p><small>Aún no hay comunicados.</small></p>'}</div>`;
  }

  views.crm = renderCRM;
  Object.assign(window, { crmMetrics, crmFilterMembers, crmSubjectStats, crmTopLessons, crmWeeklyNew, crmMemberStatus, crmFormatSec, crmDaysAgo, crmResumen, crmMiembros, crmContenido, crmRetencion, crmComunicaciones });

  /* ======================================================================
     COMUNIDAD: FOTOS, MENCIONES @, NOTIFICACIONES DE CHATS PRIVADOS,
     MODERACIÓN Y ACCESO MANUAL POR EL ADMINISTRADOR
     ====================================================================== */
  const MAX_IMG_BYTES = 2 * 1024 * 1024, MAX_IMG_W = 800;
  const IMG_EXT = /\.(jpe?g|jfif|png|gif|webp|heic|heif|bmp|avif|tiff?)$/i;
  const pend = { feed: [], chat: [], dm: [], cm: {} };   // fotos pendientes por formulario
  const upErr = {};                                      // errores inline por formulario
  const isMod = () => !!(admin && window.adminLoggedIn);
  const nowStr = () => new Date().toLocaleString('es', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  const isImgData = d => typeof d === 'string' && /^data:image\//.test(d);

  /* ---------- Subida y redimensionado de fotos ---------- */
  function fileToImg(file){
    return new Promise((res, rej) => {
      const url = URL.createObjectURL(file), im = new Image();
      im.onload = () => {
        try{
          const w0 = im.naturalWidth || im.width, h0 = im.naturalHeight || im.height;
          if (!w0 || !h0) throw new Error('size');
          const k = Math.min(1, MAX_IMG_W / w0), w = Math.max(1, Math.round(w0 * k)), h = Math.max(1, Math.round(h0 * k));
          const c = document.createElement('canvas'); c.width = w; c.height = h;
          const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, w, h); g.drawImage(im, 0, 0, w, h);
          URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', 0.82));
        }catch(e){ URL.revokeObjectURL(url); rej(e); }
      };
      im.onerror = () => { URL.revokeObjectURL(url); rej(new Error('decode')); };
      im.src = url;
    });
  }
  function pendList(ctx){
    if (ctx.startsWith('cm:')){ const k = ctx.slice(3); return (pend.cm[k] = pend.cm[k] || []); }
    return pend[ctx];
  }
  const ctxId = ctx => 'up-' + ctx.replace(/[^\w-]/g, '_');
  function pendHtml(ctx){
    const list = pendList(ctx), e = upErr[ctx];
    return (list.length ? `<div class="up-prev">${list.map((d, i) => `<div class="up-th"><img src="${d}" alt="Foto ${i + 1} seleccionada"><button type="button" class="up-x" aria-label="Quitar foto ${i + 1}" title="Quitar foto" onclick="mtRmPhoto('${ctx}',${i})">✕</button></div>`).join('')}</div>` : '')
      + (e ? `<div class="up-err" role="alert">${esc(e)}</div>` : '');
  }
  function drawPend(ctx){ const el = document.getElementById(ctxId(ctx)); if (el) el.innerHTML = pendHtml(ctx); }
  function setErr(ctx, msg){ upErr[ctx] = msg; drawPend(ctx); }
  const upBox = ctx => `<div class="up-box" id="${ctxId(ctx)}" aria-live="polite">${pendHtml(ctx)}</div>`;
  const upBtn = (ctx, max, label) => `<label class="up-btn" title="${max > 1 ? `Agregar hasta ${max} fotos (máx. 2 MB c/u)` : 'Adjuntar 1 foto (máx. 2 MB)'}">📷<span>${label || 'Foto'}</span><input type="file" accept="image/*" ${max > 1 ? 'multiple' : ''} hidden onchange="mtAddPhotos('${ctx}',this,${max})"></label>`;

  window.mtAddPhotos = async function(ctx, input, max){
    const files = [...(input.files || [])]; input.value = '';
    const list = pendList(ctx), errs = [];
    for (const f of files){
      if (list.length >= max){ errs.push(max === 1 ? 'Solo podés adjuntar 1 foto.' : `Podés adjuntar hasta ${max} fotos.`); break; }
      if (!((f.type || '').startsWith('image/') || IMG_EXT.test(f.name || ''))){ errs.push(`«${f.name}» no es una imagen.`); continue; }
      if (f.size > MAX_IMG_BYTES){ errs.push(`«${f.name}» pesa ${(f.size / 1048576).toFixed(1)} MB; el máximo es 2 MB por foto.`); continue; }
      try{ list.push(await fileToImg(f)); }
      catch(e){ errs.push(`No pudimos leer «${f.name}». Si es una foto HEIC, exportala como JPG o subí una captura de pantalla.`); }
    }
    setErr(ctx, errs.join(' '));
  };
  window.mtRmPhoto = function(ctx, i){ pendList(ctx).splice(i, 1); setErr(ctx, ''); };

  // Guarda S; si no hay espacio en el navegador deshace el cambio y avisa en el formulario.
  function trySave(revert, ctx){
    try{ localStorage.setItem('mt', JSON.stringify(S)); return true; }
    catch(e){
      revert(); try{ localStorage.setItem('mt', JSON.stringify(S)); }catch(x){}
      const msg = 'No hay espacio suficiente en este navegador para guardar las fotos. Probá con menos fotos o pedí al administrador que borre publicaciones antiguas.';
      if (ctx) setErr(ctx, msg); toast(msg, 'err');
      return false;
    }
  }

  /* ---------- Cuadrícula de fotos + visor ampliado ---------- */
  function imgGrid(imgs, delFn){
    const list = (imgs || []).map((d, i) => ({ d, i })).filter(x => isImgData(x.d));
    if (!list.length) return '';
    return `<div class="img-grid n${Math.min(list.length, 4)}">${list.map(({ d, i }) => `<figure class="img-cell"><img class="mt-img" src="${d}" alt="Foto ${i + 1}" loading="lazy" tabindex="0" role="button" aria-label="Ampliar foto ${i + 1}">${delFn ? `<button class="mod-del" onclick="${delFn(i)}">🗑️ Borrar foto ${i + 1}</button>` : ''}</figure>`).join('')}</div>`;
  }
  function openLb(src){
    let lb = q('#mt-lb');
    if (!lb){
      lb = document.createElement('div'); lb.id = 'mt-lb';
      lb.setAttribute('role', 'dialog'); lb.setAttribute('aria-modal', 'true'); lb.setAttribute('aria-label', 'Foto ampliada');
      lb.innerHTML = '<button class="lb-x" aria-label="Cerrar foto">✕</button><img alt="Foto ampliada">';
      lb.addEventListener('click', e => { if (e.target.tagName !== 'IMG') closeLb(); });
      document.body.appendChild(lb);
    }
    lb.querySelector('img').src = src; lb.classList.add('on'); lb.querySelector('.lb-x').focus();
  }
  function closeLb(){ const lb = q('#mt-lb'); if (lb) lb.classList.remove('on'); }
  window.mtOpenLb = openLb; window.mtCloseLb = closeLb;
  document.addEventListener('click', e => { const im = e.target.closest && e.target.closest('img.mt-img'); if (im){ e.preventDefault(); openLb(im.src); } });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeLb();
    else if (e.key === 'Enter' && e.target.matches && e.target.matches('img.mt-img')) openLb(e.target.src);
  });

  /* ---------- Menciones @ ---------- */
  const reEsc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  let menRe = null, menReKey = '';
  function mentionRe(){
    const names = [...new Set([...(S.members || []).map(m => m.n), S.about && S.about.company].filter(Boolean))].sort((a, b) => b.length - a.length);
    const key = names.join('\u0001');
    if (key !== menReKey){
      menReKey = key;
      const alt = names.map(n => reEsc(esc(n))).join('|');
      menRe = new RegExp('(^|[\\s(\\[>])@(' + (alt ? '(?:' + alt + ')(?![A-Za-z0-9_\\u00C0-\\u017F])|' : '') + '[A-Za-z0-9_\\u00C0-\\u017F][A-Za-z0-9_.\\-\\u00C0-\\u017F]*)', 'g');
    }
    return menRe;
  }
  // Escapa el texto y resalta @Nombre como <span class="mention">.
  function fmtText(s){
    const h = esc(s == null ? '' : String(s));
    return h.replace(mentionRe(), (m, pre, name) => `${pre}<span class="mention">@${name}</span>`);
  }
  window.mtFmt = fmtText;

  let menEl = null, menState = null;
  function menBox(){
    if (!menEl){
      menEl = document.createElement('div'); menEl.id = 'mt-men'; menEl.className = 'men-dd'; menEl.setAttribute('role', 'listbox');
      menEl.addEventListener('mousedown', e => { const it = e.target.closest('[data-i]'); if (!it) return; e.preventDefault(); pickMention(+it.dataset.i); });
      document.body.appendChild(menEl);
    }
    return menEl;
  }
  function closeMentions(){ if (menEl) menEl.style.display = 'none'; menState = null; }
  function mentionCandidates(qs){
    const me = dmSelf(), nq = norm(qs);
    const list = (S.members || []).filter(m => m.n && m.id !== me).map(m => ({ n: m.n, photo: m.photo || '' }));
    if (me !== 'admin' && S.about && S.about.company) list.push({ n: S.about.company, photo: '' });
    return list.filter(x => norm(x.n).startsWith(nq)).sort((a, b) => a.n.localeCompare(b.n, 'es')).slice(0, 6);
  }
  function drawMentions(){
    const b = menBox(), s = menState;
    b.innerHTML = s.items.map((x, i) => `<div class="men-it ${i === s.sel ? 'on' : ''}" role="option" aria-selected="${i === s.sel}" data-i="${i}">${avHtml(x.photo, x.n, 24)}<span>${esc(x.n)}</span></div>`).join('');
    b.style.display = 'block';
    const r = s.input.getBoundingClientRect(), h = b.offsetHeight;
    b.style.left = Math.max(8, Math.min(r.left, innerWidth - b.offsetWidth - 8)) + 'px';
    b.style.top = (r.bottom + 4 + h < innerHeight ? r.bottom + 4 : Math.max(8, r.top - h - 4)) + 'px';
  }
  function onMentionInput(e){
    const el = e.target, pos = el.selectionStart == null ? el.value.length : el.selectionStart;
    const m = /(^|\s)@([^\s@]{1,30})$/.exec(el.value.slice(0, pos));
    if (!m){ closeMentions(); return; }
    const items = mentionCandidates(m[2]);
    if (!items.length){ closeMentions(); return; }
    menState = { input: el, start: pos - m[2].length - 1, end: pos, items, sel: 0 };
    drawMentions();
  }
  function pickMention(i){
    const s = menState; if (!s || !s.items[i]) return;
    const el = s.input, ins = '@' + s.items[i].n + ' ';
    el.value = el.value.slice(0, s.start) + ins + el.value.slice(s.end);
    const p = s.start + ins.length;
    closeMentions(); el.focus();
    try{ el.setSelectionRange(p, p); }catch(e){}
  }
  window.initMentions = function(inputId){
    const el = typeof inputId === 'string' ? document.getElementById(inputId) : inputId;
    if (!el || el.dataset.men) return;
    el.dataset.men = '1'; el.setAttribute('autocomplete', 'off');
    el.addEventListener('input', onMentionInput);
    el.addEventListener('blur', () => setTimeout(() => { if (menState && menState.input === el) closeMentions(); }, 150));
  };
  // Captura: si el desplegable está abierto, Enter/Tab elige y Escape cierra (antes que el Enter de enviar).
  document.addEventListener('keydown', e => {
    if (!menState || e.target !== menState.input) return;
    const n = menState.items.length;
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp'){ menState.sel = (menState.sel + (e.key === 'ArrowDown' ? 1 : -1) + n) % n; drawMentions(); }
    else if (e.key === 'Enter' || e.key === 'Tab') pickMention(menState.sel);
    else if (e.key === 'Escape') closeMentions();
    else return;
    e.preventDefault(); e.stopPropagation();
  }, true);
  document.addEventListener('mousedown', e => { if (menEl && menState && !menEl.contains(e.target) && e.target !== menState.input) closeMentions(); }, true);
  addEventListener('resize', closeMentions);
  const MENTION_IDS = ['ft', 'fx', 'ctop', 'rc', 'cm', 'dmi'];
  const queueMentions = () => setTimeout(() => MENTION_IDS.forEach(id => window.initMentions(id)), 0);

  /* ---------- Notificaciones de chats privados ---------- */
  const DM_SEEN_KEY = 'mt_dm_seen';
  // Estructura: { [quienLee]: { [dmKey]: timestamp } } — así admin y miembros del mismo navegador no se pisan.
  function dmSeenAll(){ try{ return JSON.parse(localStorage.getItem(DM_SEEN_KEY) || '{}') || {}; }catch(e){ return {}; } }
  const dmSeenFor = me => dmSeenAll()[me] || {};
  function markDmSeen(key){
    const me = dmSelf(); if (!me || !key) return;
    const all = dmSeenAll(); all[me] = all[me] || {}; all[me][key] = Date.now();
    try{ localStorage.setItem(DM_SEEN_KEY, JSON.stringify(all)); }catch(e){}
  }
  function unreadIn(key, me, seen){ const ts = (seen || dmSeenFor(me))[key] || 0; return ((S.dm || {})[key] || []).filter(x => x.f !== me && (x.ts || 0) > ts).length; }
  function countUnreadDMs(){
    const me = dmSelf(); if (!me || !S.dm) return 0;
    const seen = dmSeenFor(me);
    return Object.keys(S.dm).filter(k => k.split('|').includes(me)).reduce((n, k) => n + unreadIn(k, me, seen), 0);
  }
  function updateDmBadge(){
    const btn = q('#mainnav button[data-view="dm"]'); if (!btn) return;
    let b = btn.querySelector('#dm-badge');
    if (!b){ b = document.createElement('span'); b.id = 'dm-badge'; b.className = 'dm-badge'; btn.appendChild(b); }
    const n = countUnreadDMs();
    b.textContent = n > 99 ? '99+' : n; b.style.display = n > 0 ? 'inline-block' : 'none';
    btn.setAttribute('aria-label', n > 0 ? `Chats privados (${n} sin leer)` : 'Chats privados');
  }
  Object.assign(window, { countUnreadDMs, markDmSeen, updateDmBadge });
  setInterval(updateDmBadge, 3000);
  // Mensajes que llegan desde otra pestaña del mismo navegador.
  addEventListener('storage', e => {
    if (e.key !== 'mt' || !e.newValue) return;
    try{ const st = JSON.parse(e.newValue); if (st && st.dm) S.dm = st.dm; }catch(x){ return; }
    updateDmBadge();
    if (view === 'dm' && !(document.activeElement && document.activeElement.id === 'dmi' && document.activeElement.value)) render();
  });

  window.dmOpen = function(c){ dmTo = c; render(); const i = q('#dmi'); if (i) i.focus(); };
  views.dm = function(){
    const me = dmSelf();
    if (!me) return '<h1>💬 Chats privados</h1><div class="box">Iniciá sesión para escribirle al administrador o a otros miembros activos.</div>';
    const C = me === 'admin' ? S.members.map(m => m.id) : ['admin', ...S.members.filter(m => m.id !== me).map(m => m.id)];
    // Sin conversación elegida: abrir la primera con mensajes sin leer.
    const seen0 = dmSeenFor(me);
    const to = C.includes(dmTo) ? dmTo : (C.find(c => unreadIn(dmKey(me, c), me, seen0) > 0) || C[0]); dmTo = to;
    const key = to ? dmKey(me, to) : null;
    if (key && view === 'dm') markDmSeen(key);
    const seen = dmSeenFor(me), msgs = key ? (S.dm[key] || []) : [], mod = isMod();
    const photo = id => id === 'admin' ? '' : ((S.members.find(m => m.id === id) || {}).photo || '');
    const side = C.map(c => {
      const u = c === to ? 0 : unreadIn(dmKey(me, c), me, seen);
      return `<div class="ls dm-ls ${c === to ? 'on' : ''} ${u ? 'has-unread' : ''}" tabindex="0" role="button" onclick="dmOpen('${c}')" onkeydown="if(event.key==='Enter')dmOpen('${c}')">${avHtml(photo(c), dmName(c), 26)}<span class="ls-n">${esc(dmName(c))}</span>${u ? `<span class="dm-unread" aria-label="${u} sin leer">${u > 99 ? '99+' : u}</span>` : ''}</div>`;
    }).join('') || '<small>Aún no hay miembros.</small>';
    const list = msgs.map((x, i) => `<div class="post dm-msg ${x.f === me ? 'mine' : ''}"><small>${esc(x.d || '')}</small> <b>${esc(dmName(x.f))}:</b> ${x.x ? `<span class="dm-tx">${fmtText(x.x)}</span>` : ''}${x.img ? imgGrid([x.img], mod ? () => `dmDelImg('${key}',${i})` : null) : ''}${mod ? `<div class="mod-row"><button class="btn d s" onclick="dmDelMsg('${key}',${i})">🗑️ Borrar mensaje</button></div>` : ''}</div>`).join('') || '<small>Sin mensajes todavía.</small>';
    queueMentions();
    setTimeout(() => { const b = q('#dm-msgs'); if (b) b.scrollTop = b.scrollHeight; }, 0);
    return `<h1>💬 Chats privados</h1><div class="cls" style="grid-template-columns:240px minmax(0,1fr)"><div class="side">${side}</div><div class="box">${to ? `<b>${esc(dmName(to))}</b><div id="dm-msgs" class="dm-msgs">${list}</div><div class="dm-compose"><input id="dmi" placeholder="Escribí un mensaje (usá @ para mencionar)" onkeydown="if(event.key==='Enter')sendDm()">${upBtn('dm', 1)}<button class="btn" onclick="sendDm()">Enviar</button></div>${upBox('dm')}` : '<small>Sin contactos todavía.</small>'}</div></div>`;
  };
  window.sendDm = function(){
    const me = dmSelf(), to = dmTo, el = q('#dmi'), x = el ? el.value.trim() : '', img = pend.dm[0] || null;
    if (!me || !to) return;
    if (!x && !img) return setErr('dm', 'Escribí un mensaje o adjuntá una foto.');
    const k = dmKey(me, to), msg = { f: me, x, d: nowStr(), ts: Date.now() };
    if (img) msg.img = img;
    S.dm[k] = (S.dm[k] || []).concat(msg);
    if (!trySave(() => { S.dm[k] = S.dm[k].filter(m => m !== msg); }, 'dm')) return;
    pend.dm = []; upErr.dm = ''; markDmSeen(k); render();
    const i = q('#dmi'); if (i) i.focus();
  };

  /* ---------- Feed: publicaciones con fotos ---------- */
  window.feedHtml = function(){
    const me = dmSelf(), P = (S.feed || []).filter(p => feedCat === 'Todos' || p.cat === feedCat).slice().sort((a, b) => (b.ts || 0) - (a.ts || 0));
    const comp = me ? `<div class="box feed-comp"><label for="fc">Categoría</label><select id="fc">${CATS.map(c => `<option>${c}</option>`).join('')}</select><label for="ft">Título (obligatorio)</label><input id="ft" placeholder="Escribí un título claro"><label for="fx">Contenido</label><textarea id="fx" rows="3" placeholder="Contá tu duda, aporte o experiencia. Usá @ para mencionar a alguien."></textarea>
<div class="comp-tools">${upBtn('feed', 4, 'Agregar fotos')}<small>Hasta 4 fotos · máx. 2 MB cada una</small></div>${upBox('feed')}<button class="btn" onclick="postFeed()">Publicar</button></div>`
      : `<div class="box">Para publicar y comentar, <a href="#" onclick="go('join');return false">registrate o iniciá sesión</a>. Tu prueba de 7 días se activa al registrarte.</div>`;
    queueMentions();
    return `<div class="seg"><button class="${feedCat === 'Todos' ? 'on' : ''}" onclick="feedCat='Todos';render()">Todos</button>${CATS.map(c => `<button class="${feedCat === c ? 'on' : ''}" onclick="feedCat='${c}';render()">${c}</button>`).join('')}</div>${comp}${me ? csearchBar('Buscar publicaciones por miembro...') : ''}<div id="feed-list">${feedListHtml(P)}</div>`;
  };
  window.postFeed = function(){
    const me = dmSelf();
    if (!me) return window.mtNeedLogin();
    const t = ((q('#ft') || {}).value || '').trim(), x = ((q('#fx') || {}).value || '').trim(), c = (q('#fc') || {}).value || CATS[0], imgs = pend.feed.slice(0, 4);
    if (!t) return setErr('feed', 'El título es obligatorio.');
    if (!x && !imgs.length) return setErr('feed', 'Escribí el contenido o agregá al menos una foto.');
    const m = myM(), p = { id: 'p' + Date.now(), aid: me, a: me === 'admin' ? S.about.company + ' (Admin)' : myName(), av: m ? m.photo : '', t, x, cat: c, d: new Date().toLocaleDateString('es'), ts: Date.now(), likes: [], rx: {}, cm: [] };
    if (imgs.length) p.imgs = imgs;
    S.feed.unshift(p);
    if (!trySave(() => { S.feed = S.feed.filter(y => y !== p); }, 'feed')) return;
    notify('post', p.a, me, p.t, p.id); save();
    pend.feed = []; upErr.feed = ''; render();
  };
  const postDelImg = p => isMod() ? i => `modDelPostImg('${p.id}',${i})` : null;
  window.postHtml = function(p){
    const me = dmSelf(), L = p.likes || [], cm = p.cm || [], mine = me && (p.aid === me || me === 'admin'), liked = !!me && L.includes(me);
    return `<div class="post2"><div style="display:flex;gap:10px;align-items:center">${avHtml(p.av, p.a, 38)}<div><b>${esc(p.a)}</b><br><small>${hace(p.ts, p.d)} · <span class="pill">${esc(p.cat)}</span></small></div>${mine ? `<button class="mini" style="margin-left:auto" onclick="delP('${p.id}')">Borrar</button>` : ''}</div><h3 onclick="go('post','${p.id}')" style="margin:10px 0 4px;cursor:pointer">${esc(p.t)}</h3>${p.x ? `<p style="white-space:pre-wrap;margin:0 0 6px">${fmtText(p.x)}</p>` : ''}${imgGrid(p.imgs, postDelImg(p))}<div class="act"><button class="lk ${liked ? 'on' : ''}" onclick="likeP('${p.id}')">👍${L.length ? ' ' + L.length : ''}</button><button class="lk" onclick="go('post','${p.id}')">💬 ${cm.length} comentarios</button></div></div>`;
  };
  window.postView = function(){
    const p = S.feed.find(x => x.id === arg);
    if (!p) return `<div class="box">Esta publicación ya no existe. <a href="#" onclick="go('home');return false">Volver a la comunidad</a></div>`;
    const me = dmSelf(), L = p.likes || [], cm = p.cm || [], liked = !!me && L.includes(me), mine = me && (p.aid === me || me === 'admin');
    cm.forEach((c, k) => { if (!c.id) c.id = 'c' + p.id + k; });
    const roots = cm.filter(c => !c.pid).sort((a, b) => (a.ts || 0) - (b.ts || 0));
    queueMentions();
    return `<a href="#" onclick="go('home');return false" style="font-size:13px">← Comunidad</a>
  <div class="post2" style="margin-top:8px"><div style="display:flex;gap:10px;align-items:center">${avHtml(p.av, p.a, 44)}<div><b>${esc(p.a)}</b><br><small>${hace(p.ts, p.d)} · <span class="pill">${esc(p.cat)}</span></small></div>${mine ? `<button class="mini" style="margin-left:auto" onclick="delP('${p.id}')">Borrar</button>` : ''}</div>
  <h2 style="margin:12px 0 6px">${esc(p.t)}</h2>${p.x ? `<p style="white-space:pre-wrap;margin:0 0 12px">${fmtText(p.x)}</p>` : ''}${imgGrid(p.imgs, postDelImg(p))}
  <div class="act"><button class="lk ${liked ? 'on' : ''}" onclick="likeP('${p.id}')">👍 Me gusta${L.length ? ' ' + L.length : ''}</button><span class="lk" style="cursor:default">💬 ${cm.length} comentarios</span></div></div>
  ${me ? `<div class="cmtin" style="margin-top:14px"><input id="ctop" placeholder="Escribí un comentario (usá @ para mencionar)..." onkeydown="if(event.key==='Enter')addCm('${p.id}',null)">${upBtn('cm:top', 1)}<button class="mini on" onclick="addCm('${p.id}',null)">Comentar</button></div>${upBox('cm:top')}` : '<small>Iniciá sesión para comentar.</small>'}
  <div class="thread-list" style="margin-top:12px">${roots.map(r => window.threadHtml(p, r, me, cm)).join('') || '<p>Sé el primero en comentar.</p>'}</div>`;
  };
  views.post = () => window.postView();

  /* ---------- Comentarios con foto ---------- */
  window.bubble = function(p, c, isReply, mention, me){
    const L = c.likes || [], liked = !!me && L.includes(me), mineC = !!me && (c.aid === me || me === 'admin');
    const txt = (c.x || mention) ? `<div style="margin-top:4px;white-space:pre-wrap">${mention ? `<span class="men">@${esc(mention)}</span> ` : ''}${fmtText(c.x)}</div>` : '';
    return `<div class="bubw ${isReply ? 'rep' : ''}">${avHtml(c.av, c.a, isReply ? 30 : 38)}<div class="bubc"><div class="bub"><b>${esc(c.a)}</b> <small>${hace(c.ts, c.d)}</small>${txt}${c.img ? imgGrid([c.img], isMod() ? () => `modDelCmImg('${p.id}','${c.id}')` : null) : ''}</div><div class="bact"><button class="lk ${liked ? 'on' : ''}" onclick="likeC('${p.id}','${c.id}')">👍${L.length ? ' ' + L.length : ''}</button>${me ? `<button class="lk" onclick="openReply('${p.id}','${c.id}')">Responder</button>` : ''}${mineC ? `<button class="lk" onclick="delCm('${p.id}','${c.id}')">Borrar</button>` : ''}</div></div></div>`;
  };
  window.replyBox = function(p, cid){
    const t = (p.cm || []).find(c => c.id === cid), ctx = 'cm:' + cid;
    return `<div class="cmtin rb" style="margin-left:46px"><input id="rc" placeholder="Responder a ${esc(t ? t.a : '')}..." onkeydown="if(event.key==='Enter')addCm('${p.id}','${cid}')">${upBtn(ctx, 1)}<button class="mini on" onclick="addCm('${p.id}','${cid}')">Responder</button><button class="mini" onclick="replyFor=null;render()">✕</button></div><div style="margin-left:46px">${upBox(ctx)}</div>`;
  };
  const _threadHtml = window.threadHtml;
  window.threadHtml = function(){ queueMentions(); return _threadHtml.apply(this, arguments); };
  window.addCm = function(id, pid){
    const p = S.feed.find(x => x.id === id), me = dmSelf(), el = q(pid ? '#rc' : '#ctop'), v = el ? el.value.trim() : '';
    const ctx = 'cm:' + (pid || 'top'), img = pendList(ctx)[0] || null;
    if (!p || !me) return window.mtNeedLogin();
    if (!v && !img) return setErr(ctx, 'Escribí un comentario o adjuntá una foto.');
    const m = myM(), who = me === 'admin' ? S.about.company : myName();
    const c = { id: 'c' + Date.now() + Math.random().toString(36).slice(2, 5), pid: pid || null, aid: me, a: who, av: m ? m.photo : '', x: v, d: new Date().toLocaleDateString('es'), ts: Date.now(), likes: [] };
    if (img) c.img = img;
    p.cm = (p.cm || []).concat(c);
    if (!trySave(() => { p.cm = p.cm.filter(y => y !== c); }, ctx)) return;
    notify(pid ? 'reply' : 'comment', who, me, p.t, p.id); save();
    pend.cm[pid || 'top'] = []; upErr[ctx] = ''; replyFor = null; render();
  };

  /* ---------- Chat (general / preguntas / soporte) con foto ---------- */
  const _chatView = views.chat;
  views.chat = function(){
    const t = document.createElement('template');
    t.innerHTML = _chatView.apply(this, arguments);
    const cmEl = t.content.querySelector('#cm'), box = cmEl && cmEl.closest('.box');
    if (box){
      const cn = box.querySelector('#cn'); if (cn && (myM() || isMod())) cn.setAttribute('value', isMod() ? S.about.company : myName());
      cmEl.setAttribute('placeholder', 'Escribí tu publicación (usá @ para mencionar)');
      const pb = box.querySelector('button[onclick="postMsg()"]');
      const tools = document.createElement('template');
      tools.innerHTML = `<div class="comp-tools">${upBtn('chat', 1)}<small>1 foto por mensaje · máx. 2 MB</small></div>${upBox('chat')}`;
      box.insertBefore(tools.content, pb || null);
    }
    [...t.content.children].forEach(n => { if (n.classList.contains('post') || (n.tagName === 'P' && /primero en publicar/.test(n.textContent))) n.remove(); });
    const P = S.posts[chatTab] || [], mod = isMod();
    if (myM() || mod) return t.innerHTML + csearchBar('Buscar mensajes por miembro...') + `<div id="chat-list">${chatListHtml()}</div>`;
    const list = P.length ? P.map((p, i) => `<div class="post chat-msg"><b>${esc(p.n)}</b> <small>${esc(p.d || '')}</small>${mod ? ` <button class="btn d s" onclick="chatDelMsg(${i})">🗑️ Borrar mensaje</button>` : ''}${p.m ? `<div class="chat-tx">${fmtText(p.m)}</div>` : ''}${p.img ? imgGrid([p.img], mod ? () => `chatDelImg(${i})` : null) : ''}</div>`).join('') : '<p>Sé el primero en publicar aquí.</p>';
    queueMentions();
    return t.innerHTML + list;
  };
  window.postMsg = function(){
    const el = q('#cm'), m = el ? el.value.trim() : '', img = pend.chat[0] || null;
    if (!m && !img) return setErr('chat', 'Escribí un mensaje o adjuntá una foto.');
    const msg = { n: ((q('#cn') || {}).value || '').trim() || 'Anónimo', m, d: new Date().toLocaleDateString('es'), ts: Date.now() };
    if (img) msg.img = img;
    const arr = S.posts[chatTab]; arr.unshift(msg);
    if (!trySave(() => { const k = arr.indexOf(msg); if (k >= 0) arr.splice(k, 1); }, 'chat')) return;
    pend.chat = []; upErr.chat = ''; render();
  };

  /* ---------- Moderación (solo administrador) ---------- */
  const modRefresh = () => { if (view === 'crm') crmRefresh(); else render(); };
  window.modDelPostImg = function(pid, i){
    if (!isMod()) return;
    const p = S.feed.find(x => x.id === pid); if (!p || !p.imgs || !p.imgs[i]) return;
    if (!confirm(`¿Borrar la foto ${i + 1} de «${p.t}»? La publicación se mantiene.`)) return;
    p.imgs.splice(i, 1); if (!p.imgs.length) delete p.imgs;
    save(); toast('🗑️ Foto borrada', 'ok'); modRefresh();
  };
  window.modDelPost = function(pid){
    if (!isMod()) return;
    const p = S.feed.find(x => x.id === pid); if (!p) return;
    if (!confirm(`¿Borrar la publicación «${p.t}» completa?`)) return;
    S.feed = S.feed.filter(x => x.id !== pid); save(); toast('🗑️ Publicación borrada', 'ok'); modRefresh();
  };
  window.modDelCmImg = function(pid, cid){
    if (!isMod()) return;
    const p = S.feed.find(x => x.id === pid), c = p && (p.cm || []).find(x => x.id === cid); if (!c || !c.img) return;
    if (!confirm('¿Borrar la foto de este comentario? El texto se mantiene.')) return;
    c.img = null; save(); toast('🗑️ Foto borrada', 'ok'); modRefresh();
  };
  window.chatDelImg = function(i){
    if (!isMod()) return;
    const m = (S.posts[chatTab] || [])[i]; if (!m || !m.img) return;
    if (!confirm('¿Borrar la foto de este mensaje? El texto se mantiene.')) return;
    m.img = null; save(); render();
  };
  window.chatDelMsg = function(i){
    if (!isMod() || !(S.posts[chatTab] || [])[i]) return;
    if (!confirm('¿Borrar este mensaje del chat?')) return;
    S.posts[chatTab].splice(i, 1); save(); render();
  };
  window.dmDelImg = function(key, i){
    if (!isMod()) return;
    const m = (S.dm[key] || [])[i]; if (!m || !m.img) return;
    if (!confirm('¿Borrar la foto de este mensaje privado?')) return;
    m.img = null; save(); render();
  };
  window.dmDelMsg = function(key, i){
    if (!isMod() || !(S.dm[key] || [])[i]) return;
    if (!confirm('¿Borrar este mensaje privado?')) return;
    S.dm[key].splice(i, 1); save(); render();
  };
  function crmModeracion(){
    const posts = (S.feed || []).filter(p => (p.imgs || []).some(isImgData)).sort((a, b) => (b.ts || 0) - (a.ts || 0)).slice(0, 20);
    const cmN = (S.feed || []).reduce((n, p) => n + (p.cm || []).filter(c => isImgData(c.img)).length, 0);
    const chatN = Object.values(S.posts || {}).reduce((n, a) => n + (a || []).filter(m => isImgData(m.img)).length, 0);
    const dmN = Object.values(S.dm || {}).reduce((n, a) => n + (a || []).filter(m => isImgData(m.img)).length, 0);
    return `<div class="kpi-grid"><div class="kpi-card"><div class="kpi-ic">🖼️</div><div class="kpi-num">${posts.length}</div><div class="kpi-lbl">Publicaciones con fotos (últimas 20)</div></div><div class="kpi-card"><div class="kpi-ic">💬</div><div class="kpi-num">${cmN}</div><div class="kpi-lbl">Comentarios con foto</div></div><div class="kpi-card"><div class="kpi-ic">🗨️</div><div class="kpi-num">${chatN}</div><div class="kpi-lbl">Mensajes de chat con foto</div></div><div class="kpi-card"><div class="kpi-ic">🔒</div><div class="kpi-num">${dmN}</div><div class="kpi-lbl">Mensajes privados con foto</div></div></div>
<div class="box"><b>🛡️ Revisión rápida de fotos</b><p><small>Últimas publicaciones con fotos. Podés borrar una foto puntual (la publicación se mantiene) o la publicación completa. Las fotos de comentarios, chats y mensajes privados se moderan desde cada conversación.</small></p>${posts.length ? posts.map(p => `<div class="mod-card"><div class="mod-head">${avHtml(p.av, p.a, 30)}<div class="mod-meta"><b>${esc(p.a)}</b> <small>· ${hace(p.ts, p.d)} · ${esc(p.cat || '')}</small><div class="mod-title">${esc(p.t)}</div></div><div class="crm-acts"><button class="btn o s" onclick="go('post','${p.id}')">Ver</button><button class="btn d s" onclick="modDelPost('${p.id}')">🗑️ Borrar publicación</button></div></div>${imgGrid(p.imgs, i => `modDelPostImg('${p.id}',${i})`)}</div>`).join('') : '<p>No hay publicaciones con fotos para revisar.</p>'}</div>`;
  }

  /* ---------- Acceso manual otorgado por el administrador ---------- */
  let accFormFor = null, accErr = '';
  const ACC_TYPES = [['30', 'Mensual (30 días)'], ['90', 'Trimestral (90 días)'], ['180', 'Semestral (180 días)'], ['perm', 'Permanente (sin vencimiento)']];
  const p2 = n => String(n).padStart(2, '0');
  const todayStr = () => { const d = new Date(); return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`; };
  const memberActive = m => m.paidUntil ? m.paidUntil > Date.now() : m.paid === true;
  function accessCtl(m){
    if (!isMod()) return '';
    if (memberActive(m)) return `<button class="btn d s acc-rev" onclick="revokeAccess('${m.id}')">❌ Revocar acceso</button>${m.payMethod === 'manual' ? `<small class="acc-info">Acceso manual · ${m.paidUntil ? 'vence ' + new Date(m.paidUntil).toLocaleDateString('es') : 'permanente'}</small>` : ''}`;
    return `<button class="btn s acc-give ${accFormFor === m.id ? 'on' : ''}" aria-expanded="${accFormFor === m.id}" onclick="openAccessForm('${accFormFor === m.id ? '' : m.id}')">✅ Dar acceso</button>`;
  }
  function accessForm(m){
    if (!isMod() || accFormFor !== m.id || memberActive(m)) return '';
    return `<div class="acc-form" role="group" aria-label="Dar acceso a ${esc(m.n)}"><label>Tipo de acceso<select id="acc-type-${m.id}">${ACC_TYPES.map(([v, l]) => `<option value="${v}">${l}</option>`).join('')}</select></label><label>Fecha de pago<input type="date" id="acc-date-${m.id}" value="${todayStr()}" max="${todayStr()}"></label><div class="crm-acts"><button class="btn s" onclick="grantAccess('${m.id}')">Confirmar</button><button class="btn o s" onclick="openAccessForm('')">Cancelar</button></div>${accErr ? `<div class="up-err" role="alert">${esc(accErr)}</div>` : ''}</div>`;
  }
  function accRefresh(){
    if (view === 'crm'){ const box = q('#crm-mtable'); if (box){ box.innerHTML = crmMembersTable(); return; } return crmRefresh(); }
    render();
  }
  window.openAccessForm = function(id){ accFormFor = id || null; accErr = ''; accRefresh(); };
  window.grantAccess = function(id){
    if (!isMod()) return;
    const m = (S.members || []).find(x => x.id === id); if (!m) return;
    const type = (q('#acc-type-' + id) || {}).value || '30', ds = (q('#acc-date-' + id) || {}).value || '';
    const fail = msg => { accErr = msg; accRefresh(); };
    if (!/^\d{4}-\d{2}-\d{2}$/.test(ds)) return fail('Elegí una fecha de pago válida.');
    const [y, mo, d] = ds.split('-').map(Number), payTs = new Date(y, mo - 1, d).getTime();
    if (payTs > Date.now()) return fail('La fecha de pago no puede ser futura.');
    const until = type === 'perm' ? null : payTs + (+type) * DAYMS;
    if (until && until <= Date.now()) return fail('Con esa fecha de pago el acceso ya estaría vencido. Revisá la fecha o elegí un plan más largo.');
    Object.assign(m, { paid: true, paidUntil: until, payMethod: 'manual', payDate: ds, payPlan: type });
    delete m.promo;
    save(); accFormFor = null; accErr = '';
    toast(`✅ Acceso activado para ${m.n}${until ? ' hasta el ' + new Date(until).toLocaleDateString('es') : ' (permanente)'}`, 'ok');
    accRefresh();
  };
  window.revokeAccess = function(id){
    if (!isMod()) return;
    const m = (S.members || []).find(x => x.id === id); if (!m) return;
    if (!confirm(`¿Revocar el acceso de ${m.n}? Dejará de ver el contenido para miembros.`)) return;
    Object.assign(m, { paid: false, paidUntil: 0, revokedAt: Date.now() }); delete m.promo;
    save(); toast(`Acceso revocado a ${m.n}`); accRefresh();
  };
  Object.assign(window, { crmModeracion, accessCtl, accessForm, fmtText });

  /* ======================================================================
     CONTROL DE ACCESO POR MATERIA: pago adicional por miembro (m.bought),
     panel de materias, acceso manual, QR de materias y aprobación de compras
     ====================================================================== */
  const isExtra = s => !!s && s.incl === false;
  const extraSubjects = () => (S.subjects || []).filter(isExtra);
  const hasBought = (m, sid) => !!m && Array.isArray(m.bought) && m.bought.includes(sid);
  const priceTxt = s => `$${+((s.price || {}).USD) || 0} USD / Bs ${+((s.price || {}).BOB) || 0}`;
  function addBought(m, sid){ if (!m) return; if (!Array.isArray(m.bought)) m.bought = []; if (!m.bought.includes(sid)) m.bought.push(sid); }
  let subMsg = {};          // mensajes inline del panel de materias, por índice
  const subOpen = new Set(); // miembros con la sección "Materias adicionales" desplegada

  // Migración: compras registradas en S.bought ({sid, uid}) pasan a m.bought del miembro.
  (function migrateBought(){
    let ch = false;
    (S.bought || []).forEach(b => {
      if (!b || typeof b !== 'object') return;
      const m = (S.members || []).find(x => x.id === b.uid);
      if (m && !hasBought(m, b.sid)){ addBought(m, b.sid); ch = true; }
    });
    if (ch) save();
  })();

  /* ---------- 1. Acceso ---------- */
  window.subAllowed = function(s){
    if (admin) return true;
    if (!s || s.pub === false) return false;
    if (isExtra(s)) return hasBought(myM(), s.id); // pago adicional: compra propia, aunque tenga suscripción
    return !locked();
  };
  const pendingReq = (s, m) => !!m && (S.subReq || []).some(r => r.sid === s.id && r.uid === m.id && r.status === 'pendiente');
  window.subPaywall = function(s){
    const i = S.subjects.indexOf(s), m = myM();
    if (s.pub === false) return `<h1>${esc(s.n)}</h1><div class="box">📝 Esta materia todavía no está disponible.</div>`;
    if (isExtra(s)){
      const act = !m ? `<p><a href="#" onclick="openJoin('login');return false">Iniciá sesión</a> o <a href="#" onclick="openJoin('register');return false">creá tu cuenta</a> para comprarla.</p>`
        : pendingReq(s, m) ? `<p class="sub-note">⏳ Tu solicitud de compra está pendiente. El administrador la revisará pronto.</p>`
        : `<button class="btn" onclick="go('subpay',${i})">💳 Comprar acceso a esta materia</button>`;
      return `<h1>${esc(s.icon || '')} ${esc(s.n)}</h1><div class="box sub-wall extra"><span class="sb-badge sb-extra">💰 De pago adicional</span><h2>🔒 Materia de pago adicional: ${priceTxt(s)}</h2><p>${lessons(s).length} temas · ${esc(s.kind || '')}. Pago único. <b>No está incluida en la suscripción</b>: también los miembros con suscripción activa deben comprarla.</p>${act}</div>`;
    }
    return `<h1>${esc(s.icon || '')} ${esc(s.n)}</h1><div class="box sub-wall"><span class="sb-badge sb-incl">🎓 Incluida en suscripción</span><h2>🔒 Contenido para miembros</h2><p>Esta materia está incluida en la suscripción. Activá tu plan para estudiarla.</p>${m ? `<button class="btn" onclick="go('plans')">Ver planes</button>` : `<button class="btn" onclick="openJoin('register')">Crear cuenta · 7 días gratis</button> <button class="btn o" onclick="openJoin('login')">Iniciar sesión</button>`}</div>`;
  };
  window.priceBadge = function(s){
    const b = [];
    if (s.pub === false) b.push('<span class="sb-badge sb-draft">📝 Borrador</span>');
    if (isExtra(s)) b.push(`<span class="sb-badge sb-extra">${admin ? '' : (subAllowed(s) ? '✓ ' : '🔒 ')}💰 ${priceTxt(s)}</span>`);
    return b.length ? '<br>' + b.join(' ') : '';
  };

  /* ---------- 4. Vista de compra con QR de materias ---------- */
  window.subpayView = function(){
    const i = arg, s = S.subjects[i], m = myM();
    if (!s) return '<h1>Materia no encontrada</h1>';
    if (!m) return `<h1>Comprar materia</h1><div class="box">Primero <a href="#" onclick="openJoin('register');return false">creá tu cuenta</a> o <a href="#" onclick="openJoin('login');return false">iniciá sesión</a> para comprar esta materia.</div>`;
    if (hasBought(m, s.id)) return `<h1>${esc(s.n)}</h1><div class="box ok-box">✅ Ya tenés acceso a esta materia. <button class="btn s" onclick="go('subject',${i})">Ir a la materia</button></div>`;
    const pend = pendingReq(s, m), qr = S.subQr || S.qr;
    const rej = (S.subReq || []).filter(r => r.sid === s.id && r.uid === m.id).slice(-1)[0];
    const qrBox = qr ? `<div class="box sub-qr"><img src="${esc(qr)}" alt="QR de pago de materias adicionales">${S.subQr ? '' : '<p class="sub-note">ℹ️ Se muestra el QR general de pagos.</p>'}${S.subQrTxt ? `<p class="sub-qr-txt">${esc(S.subQrTxt)}</p>` : `<p>Escaneá, pagá ${priceTxt(s)} y enviá la solicitud con el número de referencia.</p>`}</div>` : '<div class="box">El administrador aún no cargó el QR de pago.</div>';
    return `<h1>Comprar: ${esc(s.n)}</h1><div class="box"><span class="sb-badge sb-extra">💰 De pago adicional</span><div class="price">${priceTxt(s)}</div><small>Acceso a esta materia y todos sus temas. Pago único, aparte de la suscripción.</small></div>
${payTabs('chatSub', chatSub)}${chatSub === 'paypal' ? paypalBox(priceTxt(s)) : qrBox}
<div class="box"><label for="sref">Número de referencia o nota</label><input id="sref" ${pend ? 'disabled' : ''}><button class="btn" ${pend ? 'disabled' : ''} onclick="reqSub(${i})">${pend ? 'Solicitud enviada, esperando aprobación' : 'Ya pagué: enviar solicitud'}</button>${rej && rej.status === 'rechazado' && !pend ? '<p class="up-err">Tu solicitud anterior fue rechazada. Revisá el pago y volvé a enviarla.</p>' : ''}<p><small>El administrador verifica el pago y activa la materia para tu cuenta.</small></p></div>`;
  };
  views.subpay = () => window.subpayView();
  window.reqSub = function(i){
    const s = S.subjects[i], m = myM(); if (!s || !m) return;
    if (pendingReq(s, m)) return toast('Ya tenés una solicitud pendiente para esta materia.');
    S.subReq.push({ id: 'r' + Date.now(), sid: s.id, uid: m.id, name: m.n, email: m.e, method: chatSub === 'paypal' ? 'paypal' : 'qr', ref: ((q('#sref') || {}).value || '').trim(), d: new Date().toLocaleDateString('es'), status: 'pendiente' });
    const rq = S.subReq[S.subReq.length - 1];
    addNotif({ type: 'materia', reqId: rq.id, memberId: m.id, memberName: m.n, memberEmail: m.e, subjectName: s.n, method: rq.method, ref: rq.ref });
    save(); toast('✅ Solicitud enviada. Cuando el administrador la apruebe, la materia se activará.', 'ok'); go('subject', i);
  };

  /* ---------- 5. Aprobación: registra la compra en el miembro ---------- */
  const _subReview = window.subReview;
  window.subReview = function(id, ok){
    const r = (S.subReq || []).find(x => x.id === id);
    if (r && ok) addBought((S.members || []).find(x => x.id === r.uid), r.sid); // antes del render del core
    const res = _subReview.apply(this, arguments);
    (S.adminNotifs || []).forEach(n => { if (n.reqId === id) n.read = true; });
    if (r){ save(); toast(ok ? `✅ Compra aprobada: ${r.name} ya tiene acceso.` : `Solicitud de ${r.name} rechazada.`, ok ? 'ok' : ''); }
    return res;
  };

  /* ---------- 2. Configuración de materias (admin) ---------- */
  const subBadges = s => `${s.pub === false ? '<span class="sb-badge sb-draft">📝 Borrador</span>' : '<span class="sb-badge sb-pub">✅ Publicada</span>'} ${isExtra(s) ? '<span class="sb-badge sb-extra">💰 De pago adicional</span>' : '<span class="sb-badge sb-incl">🎓 Incluida en suscripción</span>'}`;
  function accessPicker(i, s){
    const ex = isExtra(s), warn = ex && !(+s.price.USD > 0 || +s.price.BOB > 0);
    return `<div class="sb-pick" role="radiogroup" aria-label="Tipo de acceso">
<button type="button" role="radio" aria-checked="${!ex}" class="sb-opt incl ${!ex ? 'on' : ''}" onclick="subSetIncl(${i},true)"><b>🎓 Incluida en suscripción</b><small>Los miembros con membresía activa acceden sin pagar extra.</small></button>
<button type="button" role="radio" aria-checked="${ex}" class="sb-opt extra ${ex ? 'on' : ''}" onclick="subSetIncl(${i},false)"><b>💰 De pago adicional</b><small>Requiere un pago extra aunque tengan suscripción.</small></button></div>
${ex ? `<div class="sb-price"><div class="row"><div><label for="sbu-${i}">Precio en dólares (USD)</label><input id="sbu-${i}" type="number" min="0" step="any" value="${+s.price.USD || 0}" onchange="subPrice(${i},'USD',this.value)"></div><div><label for="sbb-${i}">Precio en bolivianos (Bs)</label><input id="sbb-${i}" type="number" min="0" step="any" value="${+s.price.BOB || 0}" onchange="subPrice(${i},'BOB',this.value)"></div></div><p class="sub-note">Los miembros con suscripción activa deberán pagar adicional para acceder.</p>${warn ? '<p class="up-err">⚠️ Definí un precio: con precio 0 nadie puede comprarla (solo vos podés dar acceso manual).</p>' : ''}</div>` : ''}`;
  }
  window.subSetIncl = function(i, incl){
    if (!isMod()) return; const s = S.subjects[i]; if (!s) return;
    s.incl = !!incl; save();
    subMsg[i] = incl ? '🎓 Ahora está incluida en la suscripción.' : '💰 Ahora es de pago adicional. Revisá el precio.';
    render();
  };
  window.subTogglePub = function(i){
    if (!isMod()) return; const s = S.subjects[i]; if (!s) return;
    s.pub = s.pub === false; save();
    subMsg[i] = s.pub ? '✅ Materia publicada: ya la ven los miembros.' : '📝 Materia pasada a borrador: solo vos la ves.';
    render();
  };
  const pubToggle = (i, s) => `<button type="button" class="sb-toggle ${s.pub === false ? '' : 'on'}" role="switch" aria-checked="${s.pub !== false}" onclick="subTogglePub(${i})"><span class="sb-knob"></span><span>${s.pub === false ? '📝 Borrador' : '✅ Publicada'}</span></button>`;
  window.subCfg = function(i, s){
    const msg = subMsg[i]; delete subMsg[i];
    return `<div class="box sb-cfg"><b>Configuración de esta materia</b> ${subBadges(s)}
<div class="sb-line"><span class="sb-lbl">Estado</span>${pubToggle(i, s)}</div>
<div class="row"><div><label for="sbk-${i}">Tipo de contenido</label><select id="sbk-${i}" onchange="subSet(${i},'kind',this.value)">${['Curso', 'Charla de actualización', 'Material nuevo'].map(k => `<option ${s.kind === k ? 'selected' : ''}>${k}</option>`).join('')}</select></div></div>
<span class="sb-lbl">Tipo de acceso</span>${accessPicker(i, s)}${msg ? `<p class="sb-msg" role="status">${msg}</p>` : ''}</div>`;
  };
  window.subAdminPanel = function(){
    const pend = (S.subReq || []).filter(r => r.status === 'pendiente');
    const done = (S.subReq || []).filter(r => r.status !== 'pendiente').slice(-10).reverse();
    const sname = sid => (S.subjects.find(x => x.id === sid) || {}).n || 'Materia eliminada';
    const cards = S.subjects.map((s, i) => {
      const msg = subMsg[i]; delete subMsg[i];
      const nb = (S.members || []).filter(m => hasBought(m, s.id)).length;
      return `<div class="sb-card ${s.pub === false ? 'draft' : isExtra(s) ? 'extra' : 'incl'}" id="sb-card-${i}"><div class="sb-head"><b>${esc(s.icon || '')} ${esc(s.n)}</b><small>${esc(s.kind || '')} · ${lessons(s).length} temas${isExtra(s) ? ` · ${nb} con acceso` : ''}</small><div class="sb-badges">${subBadges(s)}</div></div>
<div class="crm-acts sb-acts"><button class="btn ${s.pub === false ? '' : 'o'} s" onclick="subTogglePub(${i})">${s.pub === false ? '🚀 Publicar' : '📝 Pasar a borrador'}</button><button class="btn o s" onclick="subSetIncl(${i},${isExtra(s)})">${isExtra(s) ? '🎓 Pasar a incluida' : '💰 Pasar a pago adicional'}</button><button class="btn o s" onclick="go('subject',${i})">✏️ Editar contenido</button><button class="btn d s" onclick="delSubject(${i})">🗑️ Borrar</button></div>
${isExtra(s) ? accessPicker(i, s) : ''}${msg ? `<p class="sb-msg" role="status">${msg}</p>` : ''}</div>`;
    }).join('') || '<small>No hay materias.</small>';
    return `<div class="box" id="sb-panel"><b>📚 Materias: estado y tipo de acceso</b><p><small>🟢 Incluida en suscripción · 🟠 De pago adicional · ⚪ Borrador (solo vos la ves).</small></p><div class="sb-grid">${cards}</div></div>
<div class="box" id="sb-req"><b>Solicitudes de compra pendientes (${pend.length})</b>${pend.map(r => `<div class="post">${esc(r.name)} · ${esc(r.email)} · <b>${esc(sname(r.sid))}</b> · ${methodTxt(r.method)} · ref: ${esc(r.ref || '—')} · ${esc(r.d || '')} <button class="btn s" onclick="subReview('${r.id}',true)">✅ Aprobar</button> <button class="btn d s" onclick="subReview('${r.id}',false)">Rechazar</button></div>`).join('') || '<p><small>Sin solicitudes pendientes.</small></p>'}${done.length ? `<details><summary><small>Últimas revisadas (${done.length})</small></summary>${done.map(r => `<div class="post"><small>${esc(r.d || '')}</small> ${esc(r.name)} · ${esc(sname(r.sid))} · ${r.status === 'aprobado' ? '✅ Aprobada' : '❌ Rechazada'}</div>`).join('')}</details>` : ''}</div>`;
  };

  /* ---------- 3. Acceso manual a materias ---------- */
  window.grantSubjectAccess = function(memberIdx, subjectId, grant){
    if (!isMod()) return;
    const m = (S.members || [])[memberIdx], s = (S.subjects || []).find(x => x.id === subjectId);
    if (!m || !s) return;
    if (grant) addBought(m, subjectId);
    else { m.bought = (m.bought || []).filter(x => x !== subjectId); S.bought = (S.bought || []).filter(b => !(b && b.sid === subjectId && b.uid === m.id)); }
    subOpen.add(m.id); save();
    toast(grant ? `✅ ${m.n} ya tiene acceso a ${s.n}` : `Acceso a ${s.n} revocado a ${m.n}`, grant ? 'ok' : '');
    if (view === 'crm'){ const box = q('#crm-mtable'); if (box){ box.innerHTML = crmMembersTable(); return; } }
    render();
  };
  window.subToggleOpen = function(id, open){ if (open) subOpen.add(id); else subOpen.delete(id); };
  function memberSubjects(m){
    const ex = extraSubjects(); if (!isMod() || !ex.length) return '';
    const idx = S.members.indexOf(m), n = ex.filter(s => hasBought(m, s.id)).length;
    return `<details class="sb-member" ${subOpen.has(m.id) ? 'open' : ''} ontoggle="subToggleOpen('${m.id}',this.open)"><summary>💰 Materias adicionales (${n}/${ex.length})</summary><div class="sb-mlist">${ex.map(s => {
      const has = hasBought(m, s.id);
      return `<div class="sb-mrow"><span>${esc(s.icon || '')} ${esc(s.n)} <small>${priceTxt(s)}</small>${has ? ' <span class="sb-badge sb-incl">Con acceso</span>' : ''}</span>${has ? `<button class="btn d s" onclick="grantSubjectAccess(${idx},${JSON.stringify(s.id).replace(/"/g, '&quot;')},false)">❌ Revocar</button>` : `<button class="btn s" onclick="grantSubjectAccess(${idx},${JSON.stringify(s.id).replace(/"/g, '&quot;')},true)">✅ Dar acceso</button>`}</div>`;
    }).join('')}</div></details>`;
  }

  /* ---------- 4. Configuración del QR de materias ---------- */
  window.subQrUpload = async function(input){
    const f = input.files && input.files[0]; input.value = '';
    const out = q('#subqr-msg'), say = (t, k) => { if (out){ out.className = k === 'err' ? 'up-err' : 'sb-msg'; out.textContent = t; } };
    if (!f) return;
    if (!((f.type || '').startsWith('image/') || IMG_EXT.test(f.name || ''))) return say('El archivo no es una imagen.', 'err');
    if (f.size > MAX_IMG_BYTES) return say('La imagen pesa más de 2 MB.', 'err');
    let d; try{ d = await fileToImg(f); }catch(e){ return say('No pudimos leer la imagen. Probá con JPG o PNG.', 'err'); }
    const prev = S.subQr; S.subQr = d;
    if (!trySave(() => { S.subQr = prev; })) return say('No hay espacio suficiente para guardar el QR.', 'err');
    render(); const o = q('#subqr-msg'); if (o){ o.className = 'sb-msg'; o.textContent = '✅ QR de materias adicionales guardado.'; }
  };
  window.subQrRemove = function(){ if (!isMod()) return; delete S.subQr; save(); render(); };
  window.subQrSetTxt = function(v){ S.subQrTxt = String(v || '').trim(); save(); const o = q('#subqr-msg'); if (o){ o.className = 'sb-msg'; o.textContent = '✅ Instrucciones guardadas.'; } };
  const subQrSection = () => `<div class="box" id="subqr-box"><b>🧾 QR para materias adicionales</b><p><small>Se muestra al comprar una materia de pago adicional. Si no cargás uno, se usa el QR general de pagos.</small></p>
<div class="sb-qr-cfg"><div class="sb-qr-prev">${S.subQr ? `<img src="${esc(S.subQr)}" alt="QR actual de materias adicionales">` : `<div class="sb-qr-empty">${S.qr ? 'Sin QR propio<br><small>Se usará el QR general</small>' : 'Sin QR cargado'}</div>`}</div>
<div class="sb-qr-form"><label for="subqr-file">Imagen del QR</label><input id="subqr-file" type="file" accept="image/*" onchange="subQrUpload(this)">${S.subQr ? '<button class="btn d s" onclick="subQrRemove()">Quitar QR</button>' : ''}
<label for="subqr-txt">Instrucciones de pago para el miembro</label><textarea id="subqr-txt" rows="3" placeholder="Ej.: Escaneá el QR, pagá el monto exacto y enviá la solicitud con el número de comprobante." onchange="subQrSetTxt(this.value)">${esc(S.subQrTxt || '')}</textarea><div id="subqr-msg" aria-live="polite"></div></div></div></div>`;
  window.subQrSection = subQrSection;
  // QR general: confirmación inline en vez de alert().
  window.mtSaveQr = function(input){ fileTo(input, d => { S.qr = d; save(); render(); toast('✅ QR general guardado', 'ok'); }); };

  // Planes: el administrador ve ambos QR configurados.
  const _plansSub = views.plans;
  views.plans = function(){
    const h = _plansSub.apply(this, arguments);
    if (!isMod()) return h;
    const card = (t, src, note) => `<div class="sb-qr-card"><b>${t}</b>${src ? `<img src="${esc(src)}" alt="${t}">` : `<div class="sb-qr-empty">${note}</div>`}</div>`;
    return h + `<div class="box" id="plans-qrs"><b>🧾 QR configurados (solo administrador)</b><div class="sb-qr-cards">${card('QR general (suscripciones)', S.qr, 'Sin cargar')}${card('QR de materias adicionales', S.subQr, S.qr ? 'Sin cargar · se usa el general' : 'Sin cargar')}</div><button class="btn o s" onclick="go('admin')">Configurar en el panel</button></div>`;
  };

  /* ======================================================================
     PAGOS: solo QR y PayPal · notificaciones de pago al admin · buscador de comunidad
     ====================================================================== */
  const METHOD_TXT = { qr: '📱 QR', paypal: '💳 PayPal', bank: '🏦 Depósito', card: 'Tarjeta' };
  function methodTxt(m){ return METHOD_TXT[m] || '📱 QR'; }
  function payTabs(varName, cur){
    const pp = cur === 'paypal';
    return `<div class="seg pay-tabs" role="tablist"><button role="tab" aria-selected="${!pp}" class="${pp ? '' : 'on'}" onclick="${varName}='qr';render()">📱 QR de pago</button><button role="tab" aria-selected="${pp}" class="${pp ? 'on' : ''}" onclick="${varName}='paypal';render()">💳 PayPal</button></div>`;
  }
  function paypalUrl(){
    let u = String(S.paypalLink || '').trim(); if (!u) return '';
    if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
    return /^https?:\/\/[^\s"'<>]+$/i.test(u) ? u : '';
  }
  function paypalBox(amount){
    const url = paypalUrl(), mail = String(S.paypalEmail || '').trim();
    if (!url && !mail) return '<div class="box pp-box"><p>El administrador aún no configuró PayPal. Usá el QR de pago.</p></div>';
    return `<div class="box pp-box"><div class="pp-logo">💳 PayPal</div>${url ? `<a class="btn pp-btn" href="${esc(url)}" target="_blank" rel="noopener">Pagar con PayPal →</a><p><small>Se abre en una pestaña nueva. Pagá ${esc(amount)}.</small></p>` : ''}${mail ? `<p>${url ? 'O enviá' : 'Enviá'} el pago de <b>${esc(amount)}</b> a <b class="pp-mail">${esc(mail)}</b> por PayPal (opción “Enviar dinero”).</p>` : ''}<p class="sub-note">Después de pagar, completá el número de referencia abajo y enviá el comprobante.</p></div>`;
  }

  /* ---------- Notificaciones de pago (S.adminNotifs) ---------- */
  function addNotif(o){
    if (!Array.isArray(S.adminNotifs)) S.adminNotifs = [];
    S.adminNotifs.unshift(Object.assign({ id: 'n' + Date.now() + Math.random().toString(36).slice(2, 5), ts: Date.now(), read: false }, o));
  }
  const unreadNotifs = () => (S.adminNotifs || []).filter(n => !n.read);
  function updatePayBadge(){
    const btn = q('#mainnav button[data-view="admin"]'); if (!btn) return;
    let b = btn.querySelector('#pay-badge');
    if (!b){ b = document.createElement('span'); b.id = 'pay-badge'; b.className = 'dm-badge pay-badge'; btn.appendChild(b); }
    const n = isMod() ? unreadNotifs().length : 0;
    b.textContent = n > 99 ? '99+' : n; b.style.display = n > 0 ? 'inline-block' : 'none';
    btn.setAttribute('aria-label', n > 0 ? `Panel del administrador (${n} pagos pendientes)` : 'Panel del administrador');
  }
  const findNotifMember = n => (S.members || []).find(x => x.id === n.memberId) || (S.members || []).find(x => x.e === n.memberEmail);
  function payNotifsSection(){
    const un = unreadNotifs(), read = (S.adminNotifs || []).filter(n => n.read).slice(0, 8);
    const row = n => {
      const m = findNotifMember(n), dt = new Date(n.ts).toLocaleString('es', { dateStyle: 'short', timeStyle: 'short' });
      const req = n.type === 'materia' ? (S.subReq || []).find(r => r.id === n.reqId) : null;
      const acts = n.type === 'suscripcion'
        ? `${m ? `<button class="btn s" onclick="notifActivate('${n.id}',30)">✅ Activar acceso (30 días)</button>${n.plan === 'perm' ? ` <button class="btn o s" onclick="notifActivate('${n.id}',0)">♾️ Activar permanente</button>` : ''}` : '<small class="up-err">El miembro ya no existe.</small>'}`
        : (req && req.status === 'pendiente' ? `<button class="btn s" onclick="notifSub('${n.id}',true)">✅ Aprobar</button> <button class="btn d s" onclick="notifSub('${n.id}',false)">❌ Rechazar</button>` : `<small>Solicitud ${req ? esc(req.status) : 'inexistente'}.</small>`);
      return `<div class="pn-item ${n.read ? 'read' : ''}" id="pn-${n.id}"><div class="pn-head"><span class="sb-badge ${n.type === 'materia' ? 'sb-extra' : 'sb-incl'}">${n.type === 'materia' ? '📚 Materia' : '🎓 Suscripción'}</span> <b>${esc(n.memberName || '')}</b> <small>${esc(n.memberEmail || '')}</small></div>
<div class="pn-det"><small>${n.type === 'materia' ? `Materia: <b>${esc(n.subjectName || '')}</b>` : `Plan: <b>${n.plan === 'perm' ? 'Anual / permanente' : 'Mensual'}</b>`} · Método: ${methodTxt(n.method)} · Ref: <b>${esc(n.ref || '—')}</b> · ${dt}</small></div>
${n.read ? '' : `<div class="crm-acts pn-acts">${acts} <button class="btn o s" onclick="notifRead('${n.id}')">Leída</button></div>`}</div>`;
    };
    return `<div class="box" id="pay-notifs"><b>🔔 Pagos pendientes${un.length ? ` <span class="pn-count">${un.length}</span>` : ''}</b><p><small>Comprobantes enviados por los miembros. Verificá el pago en tu QR o PayPal antes de activar.</small></p>
${un.map(row).join('') || '<p><small>No hay pagos pendientes de verificación. 🎉</small></p>'}${read.length ? `<details><summary><small>Revisadas recientemente (${read.length})</small></summary>${read.map(row).join('')}</details>` : ''}<div id="pn-msg" aria-live="polite"></div></div>`;
  }
  function notifDone(n, msg){
    n.read = true; save(); render();
    const o = q('#pn-msg'); if (o){ o.className = 'sb-msg'; o.textContent = msg; }
  }
  window.notifActivate = function(id, days){
    if (!isMod()) return;
    const n = (S.adminNotifs || []).find(x => x.id === id); if (!n) return;
    const m = findNotifMember(n); if (!m) return;
    Object.assign(m, { paid: true, paidUntil: days ? Date.now() + days * DAYMS : null, payMethod: 'manual', paidAt: Date.now() });
    delete m.promo; delete m.revokedAt;
    notifDone(n, `✅ Acceso activado para ${m.n}${days ? ` por ${days} días` : ' (permanente)'}.`);
  };
  window.notifSub = function(id, ok){
    if (!isMod()) return;
    const n = (S.adminNotifs || []).find(x => x.id === id); if (!n) return;
    if (n.reqId) window.subReview(n.reqId, ok);
    notifDone(n, ok ? `✅ Compra de ${n.subjectName} aprobada para ${n.memberName}.` : `Solicitud de ${n.memberName} rechazada.`);
  };
  window.notifRead = function(id){
    if (!isMod()) return;
    const n = (S.adminNotifs || []).find(x => x.id === id); if (n) notifDone(n, 'Notificación marcada como leída.');
  };

  /* ---------- Pago de suscripción: solo QR y PayPal ---------- */
  const subPending = (m, plan) => !!m && (S.adminNotifs || []).some(n => n.type === 'suscripcion' && !n.read && n.memberId === m.id && n.plan === plan);
  views.pay = function(){
    const plan = arg === 'perm' ? 'perm' : 'sub', o = plan === 'perm' ? S.perm : S.sub, m = myM(), amount = money(o);
    if (chatPay !== 'paypal') chatPay = 'qr';
    const qrBox = `<div class="box sub-qr">${S.qr ? `<img src="${esc(S.qr)}" alt="QR de pago"><p>Escaneá, pagá ${esc(amount)} y enviá el comprobante abajo.</p>` : '<p>El administrador aún no cargó el QR.</p>'}</div>`;
    const pend = subPending(m, plan);
    const form = !m ? `<div class="box">Para enviar tu comprobante, <a href="#" onclick="openJoin('login');return false">iniciá sesión</a> o <a href="#" onclick="openJoin('register');return false">creá tu cuenta</a>.</div>`
      : `<div class="box pay-proof"><b>Enviá tu comprobante</b><label for="pref">Número de referencia o comprobante</label><input id="pref" placeholder="Ej.: 0012345 o ID de transacción PayPal" ${pend ? 'disabled' : ''}><button class="btn" id="pay-send" ${pend ? 'disabled' : ''} onclick="paySendProof('${plan}')">${pend ? 'Comprobante enviado, esperando verificación' : 'Ya pagué, enviar comprobante'}</button><div id="pay-msg" aria-live="polite">${pend ? '<p class="sb-msg">⏳ Ya enviaste tu comprobante. El administrador verificará tu pago y activará tu acceso.</p>' : ''}</div></div>`;
    return `<h1>Pagar: ${esc(amount)}</h1><p><small>${plan === 'perm' ? 'Plan anual / permanente' : 'Plan mensual'}</small></p>${payTabs('chatPay', chatPay)}${chatPay === 'paypal' ? paypalBox(amount) : qrBox}${form}`;
  };
  window.paySendProof = function(plan){
    const m = myM(), out = q('#pay-msg'), say = (t, k) => { if (out) out.innerHTML = `<p class="${k === 'err' ? 'up-err' : 'sb-msg'}">${t}</p>`; };
    if (!m) return window.mtNeedLogin();
    if (subPending(m, plan)) return say('⏳ Ya enviaste un comprobante para este plan. Esperá la verificación.');
    const ref = ((q('#pref') || {}).value || '').trim();
    if (!ref) return say('Escribí el número de referencia o comprobante.', 'err');
    addNotif({ type: 'suscripcion', memberId: m.id, memberName: m.n, memberEmail: m.e, plan, method: chatPay === 'paypal' ? 'paypal' : 'qr', ref });
    save();
    say('✅ Tu solicitud fue enviada. El administrador verificará tu pago y activará tu acceso.');
    const b = q('#pay-send'), i = q('#pref');
    if (b){ b.disabled = true; b.textContent = 'Comprobante enviado, esperando verificación'; } if (i) i.disabled = true;
  };

  /* ---------- Configuración de PayPal (admin) ---------- */
  function paypalSection(){
    return `<div class="box" id="pp-cfg"><b>💳 PayPal</b><p><small>Si ponés un link, el miembro irá directo a pagar. Si solo ponés el email, verá las instrucciones.</small></p>
<div class="row"><div><label for="pp-email">Email de PayPal</label><input id="pp-email" type="email" placeholder="pagos@tudominio.com" value="${esc(S.paypalEmail || '')}" onchange="ppSet('paypalEmail',this.value)"></div><div><label for="pp-link">Link de pago PayPal (paypal.me o link de pago)</label><input id="pp-link" placeholder="https://paypal.me/tuusuario" value="${esc(S.paypalLink || '')}" onchange="ppSet('paypalLink',this.value)"></div></div>
<div id="pp-msg" aria-live="polite"></div><span class="sb-lbl">Vista previa para el miembro</span><div class="pp-prev" id="pp-prev">${paypalBox(money(S.sub))}</div></div>`;
  }
  window.ppSet = function(k, v){
    if (!isMod()) return;
    v = String(v || '').trim();
    const o = q('#pp-msg'), say = (t, e) => { if (o){ o.className = e ? 'up-err' : 'sb-msg'; o.textContent = t; } };
    if (k === 'paypalEmail' && v && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return say('El email de PayPal no es válido.', true);
    const prev = S[k]; S[k] = v;
    if (k === 'paypalLink' && v && !paypalUrl()){ S[k] = prev; return say('El link de PayPal no es válido.', true); }
    save(); say(k === 'paypalEmail' ? '✅ Email de PayPal guardado.' : '✅ Link de PayPal guardado.');
    const p = q('#pp-prev'); if (p) p.innerHTML = paypalBox(money(S.sub));
  };

  /* ---------- Buscador de comunidad por nombre de miembro ---------- */
  window.communitySearch = window.communitySearch || '';
  const csTerm = () => String(window.communitySearch || '').trim().toLowerCase();
  function csearchBar(ph){
    const v = window.communitySearch || '';
    return `<div class="csearch" role="search"><input id="csearch" type="search" placeholder="🔍 ${ph}" aria-label="${ph}" value="${esc(v)}" oninput="setCSearch(this.value)" autocomplete="off">${v ? '<button class="csearch-x" aria-label="Limpiar búsqueda" onclick="setCSearch(\'\')">✕</button>' : ''}</div>`;
  }
  const csCount = (n, sing, plur) => csTerm() ? `<p class="cs-count">${n} ${n === 1 ? sing : plur} de «${esc(window.communitySearch.trim())}»</p>` : '';
  function feedListHtml(P){
    const t = csTerm(), L = t && dmSelf() ? P.filter(p => String(p.a || '').toLowerCase().includes(t)) : P;
    return (dmSelf() ? csCount(L.length, 'publicación', 'publicaciones') : '') + (L.map(p => window.postHtml(p)).join('') || (t && dmSelf() ? `<p>No hay publicaciones de «${esc(window.communitySearch.trim())}».</p>` : '<p>Aún no hay publicaciones en esta categoría.</p>'));
  }
  function chatListHtml(){
    const P = S.posts[chatTab] || [], mod = isMod(), t = csTerm();
    const L = P.map((p, i) => ({ p, i })).filter(({ p }) => !t || String(p.n || '').toLowerCase().includes(t));
    const list = L.map(({ p, i }) => `<div class="post chat-msg"><b>${esc(p.n)}</b> <small>${esc(p.d || '')}</small>${mod ? ` <button class="btn d s" onclick="chatDelMsg(${i})">🗑️ Borrar mensaje</button>` : ''}${p.m ? `<div class="chat-tx">${fmtText(p.m)}</div>` : ''}${p.img ? imgGrid([p.img], mod ? () => `chatDelImg(${i})` : null) : ''}</div>`).join('');
    return csCount(L.length, 'mensaje', 'mensajes') + (list || (t ? `<p>No hay mensajes de «${esc(window.communitySearch.trim())}».</p>` : '<p>Sé el primero en publicar aquí.</p>'));
  }
  // Filtra sin re-renderizar toda la vista: no se pierde el foco ni el texto del compositor.
  window.setCSearch = function(v){
    window.communitySearch = String(v || '');
    const fl = q('#feed-list'), cl = q('#chat-list');
    if (fl){
      const me = dmSelf(), P = (S.feed || []).filter(p => feedCat === 'Todos' || p.cat === feedCat).slice().sort((a, b) => (b.ts || 0) - (a.ts || 0));
      if (me) fl.innerHTML = feedListHtml(P);
    }
    if (cl) cl.innerHTML = chatListHtml();
    const bar = q('.csearch'), inp = q('#csearch');
    if (inp && inp.value !== window.communitySearch) inp.value = window.communitySearch;
    if (bar){
      let x = bar.querySelector('.csearch-x');
      if (window.communitySearch && !x){ bar.insertAdjacentHTML('beforeend', '<button class="csearch-x" aria-label="Limpiar búsqueda" onclick="setCSearch(\'\')">✕</button>'); }
      else if (!window.communitySearch && x){ x.remove(); if (inp) inp.focus(); }
    }
    queueMentions();
  };

  /* ---------- Clase guest/logged tras cada render ---------- */
  function applyBodyState(){
    document.body.classList.toggle('admin-mode', !!(window.adminLoggedIn && admin));
    const g = isGuest();
    document.body.classList.toggle('guest', g);
    document.body.classList.toggle('logged', !g);
    const jb = q('#mainnav button[data-view="join"]');
    if (jb){
      const lbl = g ? 'Iniciar sesión' : 'Mi cuenta';
      const sp = jb.querySelectorAll('span')[1]; if (sp) sp.textContent = ' ' + lbl;
      jb.setAttribute('aria-label', lbl); jb.dataset.tip = lbl;
    }
  }
  const _render = window.render;
  window.render = function(){
    if (admin && !window.adminLoggedIn) admin = false; // solo el login separado habilita el modo admin
    if (view === 'crm' && !(window.adminLoggedIn && admin)){ view = 'join'; window.joinMode = 'admin-login'; }
    touchSeen();
    closeMentions();
    // El editor de materia (core) está en un <details>: conservar abierto al re-renderizar.
    const cfgD = (q('.sb-cfg') || {}).closest ? q('.sb-cfg').closest('details') : null;
    const keepCfg = cfgD && cfgD.open ? view + ':' + arg : null;
    const r = _render.apply(this, arguments); applyBodyState();
    if (keepCfg && keepCfg === view + ':' + arg){ const d = (q('.sb-cfg') || {}).closest ? q('.sb-cfg').closest('details') : null; if (d) d.open = true; } updateDmBadge(); updatePayBadge(); queueMentions(); return r;
  };
  const _logout = window.logout;
  window.logout = function(){ window.joinMode = 'login'; const r = _logout.apply(this, arguments); go('home'); return r; };

  /* ---------- Arranque ---------- */
  // Suscripciones de prueba vencidas dejan de figurar como pagadas.
  (S.members || []).forEach(m => { if (m.promo && m.paidUntil && m.paidUntil < Date.now()) m.paid = false; });
  const hadReset = handleReset();
  const promo = hadReset ? null : readPromoParam();
  if (promo === PROMO_CODE){
    try{ history.replaceState(null, '', location.pathname + location.hash.replace(/promo=[^&]*/, '')); }catch(e){}
    if (myM()) activatePromo(myM());
    else {
      try{ sessionStorage.setItem('mt_promo', PROMO_CODE); }catch(e){}
      promoMsg = true; window.joinMode = 'register'; view = 'join';
    }
  }
  if (view === 'admin' || view === 'crm'){ view = 'join'; window.joinMode = 'admin-login'; }
  if (isGuest() && !PUBLIC_VIEWS.includes(view)) view = 'home';
  render();
})();
