
const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const def={pw:'admin123',paywall:false,mode:'both',cur:'USD',fx:6.96,season:'Temporada 2027',sub:{USD:9,BOB:62},perm:{USD:79,BOB:550},timerUrl:'',qr:'',bank:{name:'Tu banco en EE. UU.',holder:'Nombre del titular',acct:'0000000000',aba:'000000000',swift:'XXXXUS33',zelle:''},
subjects:['Anatomía','Fisiología','Farmacología','Patología','Bioquímica','Microbiología'].map((n,i)=>({id:i,n,icon:['🫀','🧠','💊','🔬','🧬','🦠'][i],cover:'',items:[]})),
tabs:[],posts:{gen:[],qa:[],sup:[]},paid:false,subReq:[],bought:[],notifs:[],nRead:0,wa:{link:'',num:'',txt:'Comunidad de estudio MEDITHINK: comparte dudas, material y avisos de nuevas clases.'},adminEmail:'',members:[],me:null,done:{},noise:[],nz:'',feed:[],notes:[],dm:{},seen:0,hero:{t1:'Estudia medicina con claridad',body:'Videos, audios y resúmenes editados por tema. Sigue tu avance y compite en el Score.'},wv:null,logo:'',about:{company:'MEDITHINK',tagline:'Plataforma de estudio de medicina',desc:'Videos, audios y resúmenes editados por tema para estudiantes de medicina.',seoTitle:'MEDITHINK | Estudia medicina online',seoDesc:'Plataforma de estudio de medicina con videos, audios, resúmenes y comunidad.',kw:'medicina, anatomía, fisiología, farmacología, estudio',email:'',phone:'',wa:'',addr:'',web:'',social:'',hours:'Lunes a viernes, 9:00 a 18:00'}};
let S;try{S=Object.assign({},def,JSON.parse(localStorage.getItem('mt')||'{}'))}catch(e){S=def}
S.subjects.forEach(sc);let admin=false,view='home',arg=null,chatTab='gen';
const save=()=>{try{localStorage.setItem('mt',JSON.stringify(S))}catch(e){alert('No se pudo guardar: archivo muy grande. Usa un enlace en vez de subir el archivo.')}};
const money=o=>S.cur==='USD'?'$'+o.USD+' USD':'Bs '+o.BOB;
function go(v,a){view=v;arg=a??null;if(v==='subject')lsn=0;render();scrollTo(0,0)}
function rail(){$('#rail').innerHTML=S.tabs.map((t,i)=>`<button class="tb ${view==='tab'&&arg===i?'on':''}" data-tip="${esc(t.n)}" onclick="go('tab',${i})">${esc(t.n[0]||'?').toUpperCase()}</button>`).join('')+(S.tabs.length<10?`<button class="tb add" data-tip="Nueva pestaña de estudio (${S.tabs.length}/10)" onclick="addTab()">＋</button>`:'')}
function addTab(){const n=prompt('Nombre del tema que estudiarás (máx. 10 pestañas):');if(n){S.tabs.push({n,notes:''});save();go('tab',S.tabs.length-1)}}
const ic=s=>s.logo?`<img src="${esc(s.logo)}" alt="" style="height:1.1em;vertical-align:-.15em;border-radius:4px">`:esc(s.icon);
function cover(s){return `<div class="cv" style="${s.cover?`background-image:url('${esc(s.cover)}')`:''}">${s.cover?'':s.logo?`<img src="${esc(s.logo)}" alt="" style="height:64px;border-radius:12px">`:esc(s.icon)}</div>`}
function sc(s){s.price=s.price||{USD:0,BOB:0};if(s.pub===undefined)s.pub=true;if(s.incl===undefined)s.incl=true;s.kind=s.kind||'Curso';return s}
function hasPrice(s){return (+s.price.USD>0)||(+s.price.BOB>0)}
function subAllowed(s){
  if(admin)return true;
  if(s.pub===false)return false;
  if(!hasPrice(s))return !locked();
  if(s.incl&&!locked())return true;
  const m=myM();return !!m&&(S.bought||[]).some(b=>b.sid===s.id&&b.uid===m.id);
}
function priceBadge(s){if(!hasPrice(s)&&s.pub!==false)return '';return `<br><span class="pill">${admin?'':(subAllowed(s)?'✓ ':'🔒 ')}$${s.price.USD} · Bs ${s.price.BOB}</span>${s.pub===false?' <span class="pill">Borrador</span>':''}`}
function subPaywall(s){
  const i=S.subjects.indexOf(s);
  if(s.pub===false)return `<h1>${esc(s.n)}</h1><div class="box">Esta materia todavía no está disponible.</div>`;
  if(!hasPrice(s))return `<h1>${esc(s.n)}</h1><div class="box">🔒 Contenido para miembros. <a href="#" onclick="go('plans');return false">Ver planes</a></div>`;
  return `<h1>${esc(s.icon||'')} ${esc(s.n)}</h1><div class="box">🔒 Materia de pago: <b>$${s.price.USD} USD</b> · Bs ${s.price.BOB}<br><small>${lessons(s).length} temas · ${esc(s.kind||'')}</small><br><br>${myM()?`<button class="btn" onclick="go('subpay',${i})">Comprar acceso a esta materia</button>`:`<a href="#" onclick="go('join');return false">Regístrate</a> y luego compra la materia.`}</div>`;
}
function subpayView(){
  const i=arg,s=S.subjects[i],m=myM();
  if(!s)return '<h1>Materia no encontrada</h1>';
  if(!m)return `<h1>Comprar materia</h1><div class="box">Primero <a href="#" onclick="go('join');return false">regístrate</a> para comprar esta materia.</div>`;
  const pend=S.subReq.some(r=>r.sid===s.id&&r.uid===m.id&&r.status==='pendiente');
  return `<h1>Comprar: ${esc(s.n)}</h1><div class="box"><div class="price">$${s.price.USD} USD · Bs ${s.price.BOB}</div><small>Acceso a esta materia y todos sus temas. Pago único.</small></div><div class="seg"><button class="${chatSub==='qr'?'on':''}" onclick="chatSub='qr';render()">QR</button><button class="${chatSub==='bank'?'on':''}" onclick="chatSub='bank';render()">Depósito bancario</button></div>${chatSub==='qr'?(S.qr?`<div class="box"><img src="${S.qr}" style="max-width:260px;width:100%" alt="QR de pago"></div>`:'<div class="box">El administrador aún no cargó el QR.</div>'):`<div class="box">${bankBox()}</div>`}<div class="box"><label>Número de referencia o nota</label><input id="sref"><button class="btn" ${pend?'disabled':''} onclick="reqSub(${i})">${pend?'Solicitud enviada, esperando aprobación':'Ya pagué: enviar solicitud'}</button><p><small>El administrador verifica el pago y activa la materia para tu cuenta.</small></p></div>`;
}
function bankBox(){const b=S.bank;return `<b>${esc(b.name)}</b><br>Titular: ${esc(b.holder)}<br>Cuenta: ${esc(b.acct)}<br>ABA/Routing: ${esc(b.aba)}<br>SWIFT: ${esc(b.swift)}${b.zelle?'<br>Zelle: '+esc(b.zelle):''}`}
function reqSub(i){const s=S.subjects[i],m=myM();if(!m)return;S.subReq.push({id:'r'+Date.now(),sid:s.id,uid:m.id,name:m.n,email:m.e,method:chatSub,ref:($('#sref')||{}).value||'',d:new Date().toLocaleDateString('es'),status:'pendiente'});save();alert('Solicitud enviada. Cuando el administrador la apruebe, la materia se activará.');go('subject',i)}
function subSet(i,k,v){S.subjects[i][k]=v;save();render()}
function subPrice(i,c,v){S.subjects[i].price[c]=+v||0;save();render()}
function subPub(i){S.subjects[i].pub=S.subjects[i].pub===false;save();render()}
function subAdminPanel(){
  const pend=S.subReq.filter(r=>r.status==='pendiente');
  return `<div class="box"><b>Materias: precios y lanzamiento</b><p><small>Configura cada materia antes de lanzarla. Las que están en borrador solo las ves tú.</small></p>${S.subjects.map((s,i)=>`<div class="post"><b>${esc(s.icon||'')} ${esc(s.n)}</b> <span class="pill">${s.pub===false?'Borrador':'Publicada'}</span> <small>${esc(s.kind)}</small><div class="row" style="margin-top:6px"><div><label>Precio USD (0 = sin cobro)</label><input type="number" min="0" step="any" value="${s.price.USD}" onchange="subPrice(${i},'USD',this.value)"></div><div><label>Precio Bs</label><input type="number" min="0" step="any" value="${s.price.BOB}" onchange="subPrice(${i},'BOB',this.value)"></div></div><label style="display:block;margin:6px 0"><input type="checkbox" ${s.incl?'checked':''} onchange="subSet(${i},'incl',this.checked)" style="width:auto"> Incluida en la membresía</label><button class="btn ${s.pub===false?'':'o'} s" onclick="subPub(${i})">${s.pub===false?'🚀 Lanzar materia':'Pasar a borrador'}</button> <button class="btn o s" onclick="go('subject',${i})">Editar temas</button></div>`).join('')||'<small>No hay materias.</small>'}</div>
<div class="box"><b>Solicitudes de compra pendientes (${pend.length})</b>${pend.map(r=>`<div class="post">${esc(r.name)} · ${esc(r.email)} · ${esc(S.subjects.find(x=>x.id===r.sid)?.n||'')} · ${r.method==='qr'?'QR':'Depósito'} · ref: ${esc(r.ref||'—')} <button class="btn s" onclick="subReview('${r.id}',true)">Aprobar</button> <button class="btn d s" onclick="subReview('${r.id}',false)">Rechazar</button></div>`).join('')||'<small>Sin solicitudes pendientes.</small>'}</div>`;
}
function subReview(id,ok){const r=S.subReq.find(x=>x.id===id);if(!r)return;r.status=ok?'aprobado':'rechazado';if(ok&&!S.bought.some(b=>b.sid===r.sid&&b.uid===r.uid))S.bought.push({sid:r.sid,uid:r.uid});save();render()}
function subCfg(i,s){return `<div class="box"><b>Configuración de esta materia</b> <span class="pill">${s.pub===false?'Borrador':'Publicada'}</span><div class="row"><div><label>Tipo</label><select onchange="subSet(${i},'kind',this.value)">${['Curso','Charla de actualización','Material nuevo'].map(k=>`<option ${s.kind===k?'selected':''}>${k}</option>`).join('')}</select></div><div><label>Precio USD (0 = sin cobro)</label><input type="number" min="0" step="any" value="${s.price.USD}" onchange="subPrice(${i},'USD',this.value)"></div><div><label>Precio Bs</label><input type="number" min="0" step="any" value="${s.price.BOB}" onchange="subPrice(${i},'BOB',this.value)"></div></div><label style="display:block;margin:8px 0"><input type="checkbox" ${s.incl?'checked':''} onchange="subSet(${i},'incl',this.checked)" style="width:auto"> Incluida en la membresía (si no, se compra aparte)</label><button class="btn ${s.pub===false?'':'o'} s" onclick="subPub(${i})">${s.pub===false?'🚀 Lanzar materia':'Pasar a borrador'}</button><p><small>Configura precio y lanzamiento antes de mostrar la materia a los alumnos.</small></p></div>`}

const pauseNoise=()=>{try{nzA.pause()}catch(e){}};
document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseNoise()});
window.addEventListener('blur',pauseNoise);
window.addEventListener('pagehide',pauseNoise);
function luhn(n){let sum=0,alt=false;for(let i=n.length-1;i>=0;i--){let d=+n[i];if(alt){d*=2;if(d>9)d-=9}sum+=d;alt=!alt}return sum%10===0}
function stripeSim(plan,o){
  return `<div class="box"><div class="guide"><b>Modo de prueba (simulación Stripe)</b><br>No se cobra dinero real. Para probar usa la tarjeta 4242 4242 4242 4242, cualquier fecha futura y cualquier CVC. La tarjeta 4000 0000 0000 0002 simula un rechazo.</div><label>Número de tarjeta</label><input id="cn2" inputmode="numeric" placeholder="4242 4242 4242 4242" maxlength="19"><div class="row"><div><label>Vence (MM/AA)</label><input id="ce" placeholder="12/30" maxlength="5"></div><div><label>CVC</label><input id="cc" inputmode="numeric" placeholder="123" maxlength="4"></div></div><label>Nombre en la tarjeta</label><input id="cnm"><button class="btn" onclick="stripePay('${plan}')">Pagar ${money(o)}</button><div id="stmsg" style="margin-top:10px"></div></div>`;
}
function stripePay(plan){
  const m=myM(),msg=$('#stmsg');
  if(!m){msg.innerHTML='Regístrate o inicia sesión antes de pagar.';return}
  const num=($('#cn2').value||'').replace(/\D/g,''),exp=($('#ce').value||'').trim(),cvc=($('#cc').value||'').trim(),nm=($('#cnm').value||'').trim();
  const bad=t=>msg.innerHTML=`<span style="color:#ff4d4d">${t}</span>`;
  if(num.length<13||!luhn(num))return bad('Número de tarjeta no válido.');
  const mm=exp.match(/^(\d{2})\/(\d{2})$/);
  if(!mm||+mm[1]<1||+mm[1]>12)return bad('Fecha de vencimiento no válida (MM/AA).');
  if(new Date(2000+ +mm[2],+mm[1],0,23,59,59).getTime()<Date.now())return bad('La tarjeta está vencida.');
  if(!/^\d{3,4}$/.test(cvc)||!nm)return bad('Completa el CVC y el nombre.');
  msg.innerHTML='Procesando pago de prueba…';
  setTimeout(()=>{
    if(num==='4000000000000002')return bad('Pago rechazado por el banco (simulación).');
    const days=plan==='sub'?30:365,price=plan==='sub'?S.sub:S.perm;
    m.paidUntil=Math.max(m.paidUntil||0,Date.now())+days*864e5;
    S.payments=(S.payments||[]).concat({id:'pay'+Date.now(),uid:m.id,name:m.n,email:m.e,plan:plan==='sub'?'Mensual':'Anual',amount:price.USD,method:'Stripe (simulación)',last4:num.slice(-4),status:'aprobado',d:new Date().toLocaleDateString('es')});
    save();
    msg.innerHTML=`<span style="color:#2ee59d;font-weight:700">Pago de prueba aprobado (simulación).</span> Tu acceso queda activo hasta ${new Date(m.paidUntil).toLocaleDateString('es',{day:'numeric',month:'long',year:'numeric'})}.`;
    setTimeout(()=>go('home'),1800);
  },1200);
}
function locked(){if(admin||!S.paywall||S.paid)return false;const m=myM();return !(m&&(m.trialEnd>Date.now()||(m.paidUntil||0)>Date.now()))}
function item(it,si,ii){if(locked())return `<div class="post">🔒 <b>${esc(it.title)}</b> <small>Contenido para miembros. <a href="#" onclick="go('plans');return false">Ver planes</a></small></div>`;
const body=it.type==='video'?`<video controls src="${esc(it.src)}"></video>`:it.type==='audio'?`<audio controls src="${esc(it.src)}"></audio>`:`<p>${esc(it.text).replace(/\n/g,'<br>')}</p>`;
return `<div class="post"><b>${esc(it.title)}</b> <span class="pill">${it.type}</span>${admin?` <button class="btn d s" onclick="delItem(${si},${ii})">Borrar</button>`:''}${body}</div>`}
function delItem(s,i){S.subjects[s].items.splice(i,1);save();render()}
function fileTo(inp,cb){const f=inp.files[0];if(!f)return;const r=new FileReader();r.onload=()=>cb(r.result);r.readAsDataURL(f)}
function search(t){t=t.trim().toLowerCase();if(!t){go('home');return}view='search';arg=t;render()}
const views={
home(){const h=S.hero||{},w=S.wv;const LOGO=`<svg width="120" height="120" viewBox="0 0 48 48" fill="none" stroke="#00b4ff" stroke-width="2.5" stroke-linecap="round"><path d="M12 6v14a8 8 0 0016 0V6M10 6h4M26 6h4"/><path d="M20 28v4a8 8 0 0016 0v-3"/><circle cx="36" cy="25" r="4" fill="#0a6cff"/></svg>`;
return `<h1>Bienvenido a MEDITHINK</h1><div class="home2"><div class="box" style="text-align:center">${S.logo?`<img src="${S.logo}" alt="Logo de MEDITHINK" style="max-width:220px;width:70%">`:LOGO}<h2 style="margin:12px 0 6px">${esc(h.t1||'')}</h2><p>${esc(h.body||'')}</p><button class="btn" onclick="go('subjects')">Ver materias</button></div><div>${w&&(w.key||w.src)?player({type:'video',key:w.key,src:w.src}):'<div class="box"><small>El administrador aún no subió el video de bienvenida.</small></div>'}</div></div><div class="plans"><div class="box"><b>MENSUAL</b><br><small>por mes</small><br><br><button class="btn" onclick="go('pay','sub')">Elegir mensual</button></div><div class="box"><b>ANUAL</b><br><small>por año</small><br><br><button class="btn" onclick="go('pay','perm')">Elegir anual</button></div></div><h2 style="margin-top:28px">COMUNIDAD MEDICINA</h2>${feedHtml()}`},
grid(){return `<div class="grid">${S.subjects.map((s,i)=>(s.pub===false&&!admin)?'':`<div class="card" tabindex="0" draggable="${admin?'true':'false'}" ondragstart="dragI=${i}" ondragover="if(admin){event.preventDefault();this.classList.add('dropz')}" ondragleave="this.classList.remove('dropz')" ondrop="if(admin)dropOn(${i},event)" onclick="go('subject',${i})">${cover(s)}<div class="cb"><b>${esc(s.n)}</b><br><small>${esc(s.kind||'')} · ${lessons(s).length} temas</small>${priceBadge(s)}${admin?arrowCtl(i):''}</div></div>`).join('')}${admin?`<div class="card" tabindex="0" title="Agregar materia" onclick="addSubject()"><div class="cv" style="font-size:42px">＋</div><div class="cb"><b>Agregar materia (${S.subjects.length}/50)</b></div></div>`:''}</div>`},
subjects(){return `<h1>Materias</h1>${views.grid()}`},
subject(){const s=S.subjects[arg],L=lessons(s);if(!subAllowed(s))return subPaywall(s);if(lsn>=L.length)lsn=0;const c=L[lsn],nd=L.filter(l=>S.done[s.id+':'+l.id]).length,pct=L.length?Math.round(nd/L.length*100):0;
const edit=admin?`<details class="box"><summary>Editar materia (nombre, ícono, portada)</summary><div class="row"><div><label>Nombre</label><input value="${esc(s.n)}" onchange="cur().n=this.value;save();render()"></div><div><label>Ícono (emoji)</label><input value="${esc(s.icon)}" maxlength="4" onchange="cur().icon=this.value;cur().logo='';save();render()"></div><div><label>o logo (imagen)</label><input type="file" accept="image/*" onchange="fileTo(this,d=>{cur().logo=d;save();render()})"></div><div><label>Portada (enlace)</label><input value="${s.cover.startsWith('data:')?'':esc(s.cover)}" onchange="cur().cover=this.value;save();render()"></div><div><label>o subir portada</label><input type="file" accept="image/*" onchange="fileTo(this,d=>{cur().cover=d;save();render()})"></div></div>${subCfg(arg,s)}<button class="btn d s" onclick="delSubject(${arg})">Eliminar materia</button></details>`:'';
const side=`<div class="side"><a href="#" onclick="go('subjects');return false" style="font-size:13px">← Materias</a><h3>${ic(s)} ${esc(s.n)}</h3><div class="bar"><i style="width:${pct}%"></i><span>${pct}%</span></div>${L.map((l,i)=>`<div class="ls ${i===lsn?'on':''}" tabindex="0" draggable="${admin?'true':'false'}" ondragstart="dragL=${i}" ondragover="if(admin){event.preventDefault();this.classList.add('dropz')}" ondragleave="this.classList.remove('dropz')" ondrop="if(admin)dropLesson(${i},event)" onclick="lsn=${i};render()">${l.media?(l.media.type==='video'?'🎬':'🎧'):'📄'} <span>${esc(l.t)}</span><span class="ck">${S.done[s.id+':'+l.id]?'✓':''}</span>${admin?lessonArrows(i,L.length):''}</div>`).join('')||'<p><small>Aún no hay temas.</small></p>'}${admin?dz(-1,'Arrastra aquí videos, audios o textos (.txt) para crear temas nuevos'):''}</div>`;
let st='';if(!c)st=`<div class="box full">${admin?'Crea tu primer tema arrastrando material a la zona de la izquierda.':'Esta materia aún no tiene temas.'}</div>`;
else if(locked())st=`<div class="box full"><h1>${esc(c.t)}</h1>🔒 Este tema es para miembros. <a href="#" onclick="go('plans');return false">Ver planes</a></div>`;
else{const m=c.media,btn=`<p><button class="btn adv ${S.done[s.id+':'+c.id]?'on':''}" onclick="toggleAdv()">✔ Tema avanzado</button> <button class="btn o" onclick="nextL()">Siguiente ▶</button></p>`,ad=admin?adminLesson(c):'';
st=m?`<div><h1>${esc(c.t)}</h1>${player(m)}${btn}${noiseBox()}${quizBox(c)}${ad}</div>${c.text?txtBox(c.text):''}`:`<div class="full"><h1>${esc(c.t)}</h1><div class="txt" style="max-height:none">${c.text?paras(c.text):'Este tema aún no tiene contenido.'}</div>${btn}${noiseBox()}${quizBox(c)}${ad}</div>`}
return `${edit}<div class="cls">${side}<div class="stage">${st}</div></div>`},
tab(){const t=S.tabs[arg];return `<h1>${esc(t.n)}</h1><div class="box"><label>Tus apuntes de este tema</label><textarea rows="12" oninput="S.tabs[${arg}].notes=this.value;save()">${esc(t.notes)}</textarea><button class="btn s" onclick="go('subjects')">Buscar material</button> <button class="btn d s" onclick="if(confirm('¿Cerrar esta pestaña?')){S.tabs.splice(${arg},1);save();go('home')}">Cerrar pestaña</button></div>`},
search(){const r=[];S.subjects.forEach(s=>{if(s.n.toLowerCase().includes(arg))r.push(`<div class="post"><b>${ic(s)} ${esc(s.n)}</b> <a href="#" onclick="go('subject',${S.subjects.indexOf(s)});return false">Abrir materia</a></div>`);lessons(s).forEach((l,i)=>{if((l.t+' '+l.text).toLowerCase().includes(arg))r.push(`<div class="post"><small>${esc(s.n)}</small><br><b>${esc(l.t)}</b> <a href="#" onclick="go('subject',${S.subjects.indexOf(s)});lsn=${i};render();return false">Ver tema</a></div>`)})});return `<h1>Resultados</h1>${r.join('')||'<p>No encontramos ese tema. Prueba con otra palabra o pregunta en el chat.</p>'}`},
score(){const L=[...S.members].sort((a,b)=>(b.sec||0)-(a.sec||0)),f=t=>{t=t||0;return (t/3600|0)+' h '+String((t/60|0)%60).padStart(2,'0')+' min'};return `<h1>🏆 Score de estudio</h1><div class="guide">Tiempo activo estudiando en la plataforma. Compara tu constancia, tu interacción y tu avance de temas con los demás.</div>${L.length?`<div class="box" style="overflow-x:auto"><table class="tbl"><tr><th>#</th><th>Usuario</th><th>Tiempo de estudio</th><th>Temas avanzados</th></tr>${L.map((m,i)=>`<tr class="${m.id===S.me?'me':''}"><td>${['🥇','🥈','🥉'][i]||i+1}</td><td>${esc(m.n)}${m.id===S.me?' (tú)':''}</td><td>${f(m.sec)}</td><td>${m.adv||0}</td></tr>`).join('')}</table></div>`:'<div class="box">Aún no hay estudiantes en la clasificación. <a href="#" onclick="go(\'join\');return false">Regístrate</a> para aparecer.</div>'}`},
about(){const a=S.about,g=(l,k,ta)=>`<div style="flex-basis:100%"><label>${l}</label>${ta?`<textarea rows="2" onchange="S.about.${k}=this.value;save();applySeo()">${esc(a[k])}</textarea>`:`<input value="${esc(a[k])}" onchange="S.about.${k}=this.value;save();applySeo()">`}</div>`;
const txt=t=>esc(t||'').replace(/\n/g,'<br>');
return `<h1>${esc(a.company)}</h1><p>${esc(a.tagline)}</p><div class="box"><p>${esc(a.desc)}</p></div>
<div class="box"><b>Contacto empresa</b><p>${a.email?`✉️ <a href="mailto:${esc(a.email)}">${esc(a.email)}</a><br>`:''}${a.phone?`📞 ${esc(a.phone)}<br>`:''}${a.wa?`💬 <a target="_blank" rel="noopener" href="https://wa.me/${esc(a.wa.replace(/\D/g,''))}">WhatsApp de soporte</a><br>`:''}${a.web?`🌐 <a target="_blank" rel="noopener" href="${esc(a.web)}">${esc(a.web)}</a><br>`:''}${a.social?`🔗 ${esc(a.social)}<br>`:''}${!a.email&&!a.phone&&!a.wa&&!a.web?'<small>Sin datos de contacto registrados.</small>':''}</p><small>Horario de atención: ${esc(a.hours)}</small></div>
<div class="box"><b>Dirección</b><p>${a.addr?`📍 ${esc(a.addr)}`:'<small>Sin dirección registrada.</small>'}</p></div>
<div class="box"><b>Políticas, derechos y restricciones</b><div class="lg">${a.pol?txt(a.pol):'<small>Próximamente.</small>'}</div></div>
<div class="box"><b>Derechos de autor (Copyright)</b><div class="lg">${a.cop?txt(a.cop):'<small>Próximamente.</small>'}</div></div>
${admin?`<div class="box"><b>Editar información (solo administrador)</b><div class="row">${g('Nombre de la empresa','company')}${g('Eslogan','tagline')}${g('Descripción','desc',1)}${g('SEO: título de la página','seoTitle')}${g('SEO: descripción','seoDesc',1)}${g('SEO: palabras clave (separadas por comas)','kw')}${g('Correo de contacto de la empresa','email')}${g('Teléfono de la empresa','phone')}${g('WhatsApp de la empresa (con código de país)','wa')}${g('Dirección','addr')}${g('Sitio web (https://...)','web')}${g('Redes sociales','social')}${g('Horario de atención','hours')}</div><label>Políticas, derechos y restricciones (pega aquí tu texto)</label><textarea rows="10" onchange="S.about.pol=this.value;save();render()">${esc(a.pol||'')}</textarea><label>Derechos de autor / Copyright (pega aquí tu texto)</label><textarea rows="10" onchange="S.about.cop=this.value;save();render()">${esc(a.cop||'')}</textarea></div>`:''}`},
dm:()=>dmView(),notes:()=>notesView(),subpay(){return subpayView()},post(){return postView()},chat(){const G={gen:['Chat general','Comparte tu experiencia, avances y tips de estudio, como en una red social. Sé respetuoso, no publiques datos personales de pacientes ni material con derechos de autor, y evita el spam.'],qa:['Preguntas y respuestas','Escribe una duda concreta con el nombre de la materia y el tema. Responde con fuentes o explicaciones claras y comparte tus recomendaciones de libros, videos o técnicas.'],sup:['Soporte','Pregunta sobre el servicio: pagos, acceso, videos que no cargan o fallas de la página. Indica qué hacías, el dispositivo y el navegador para ayudarte más rápido.']};
const P=S.posts[chatTab];return `<h1>Chat</h1><div class="seg">${Object.keys(G).map(k=>`<button class="${k===chatTab?'on':''}" onclick="chatTab='${k}';render()">${G[k][0]}</button>`).join('')}</div><div class="guide"><b>Antes de publicar:</b> ${G[chatTab][1]}</div><div class="box"><input id="cn" placeholder="Tu nombre"><textarea id="cm" rows="3" placeholder="Escribe tu publicación"></textarea><button class="btn" onclick="postMsg()">Publicar</button></div>${P.length?P.map((p,i)=>`<div class="post"><b>${esc(p.n)}</b> <small>${p.d}</small>${admin?` <button class="btn d s" onclick="S.posts['${chatTab}'].splice(${i},1);save();render()">Borrar</button>`:''}<br>${esc(p.m)}</div>`).join(''):'<p>Sé el primero en publicar aquí.</p>'}`},
plans(){const c=S.cur,m=S.mode;return `<h1>Planes de acceso</h1><div class="seg"><button class="${c==='USD'?'on':''}" onclick="S.cur='USD';save();render()">Dólares (USD)</button><button class="${c==='BOB'?'on':''}" onclick="S.cur='BOB';save();render()">Bolivianos (Bs)</button></div><div class="grid">${m!=='perm'?`<div class="box"><b>Suscripción</b><div class="price">${money(S.sub)}</div><small>por mes · ${esc(S.season)}</small><br><br><button class="btn" onclick="go('pay','sub')">Suscribirme</button></div>`:''}${m!=='sub'?`<div class="box"><b>Miembro permanente</b><div class="price">${money(S.perm)}</div><small>pago único · ${esc(S.season)}</small><br><br><button class="btn" onclick="go('pay','perm')">Ser miembro</button></div>`:''}</div>`},
pay(){const o=arg==='sub'?S.sub:S.perm,b=S.bank;return `<h1>Pagar: ${money(o)}</h1><div class="seg"><button class="${chatPay==='card'?'on':''}" onclick="chatPay='card';render()">Tarjeta (Stripe)</button><button class="${chatPay==='qr'?'on':''}" onclick="chatPay='qr';render()">QR</button><button class="${chatPay==='bank'?'on':''}" onclick="chatPay='bank';render()">Depósito bancario</button></div>${chatPay==='card'?stripeSim(arg,o):chatPay==='qr'?`<div class="box">${S.qr?`<img src="${esc(S.qr)}" alt="QR de pago" style="max-width:260px;width:100%"><p>Escanea, paga ${money(o)} y envía el comprobante por Soporte.</p>`:'<p>El administrador aún no cargó el QR.</p>'}</div>`:`<div class="box"><p><b>${esc(b.name)}</b><br>Titular: ${esc(b.holder)}<br>Cuenta: ${esc(b.acct)}<br>ABA/Routing: ${esc(b.aba)}<br>SWIFT: ${esc(b.swift)}${b.zelle?'<br>Zelle: '+esc(b.zelle):''}</p><p>Deposita ${money(o)} y envía el comprobante por Soporte.</p></div>`}<button class="btn o s" onclick="S.paid=true;save();alert('Simulación: acceso activado en este navegador.')">Probar acceso (demo)</button>`},
members(){return `<div class="box"><b>Miembros (${S.members.length})</b> <span style="color:#ff4d4d;font-weight:700">· ${S.members.filter(m=>m.trialEnd&&trialLeft(m)>0&&trialLeft(m)<=2).length} por terminar su prueba (2 días o menos)</span> <a class="btn o s" href="mailto:${esc(S.adminEmail)}?bcc=${S.members.map(m=>encodeURIComponent(m.e)).join(',')}&subject=MEDITHINK">✉️ Correo a todos</a><p><small>Solo visible en el modo administrador. Cada correo se abre en tu app de correo predeterminada.</small></p>${S.members.map((m,i)=>({m,i})).sort((a,b)=>{const x=a.m.trialEnd?trialLeft(a.m):9999,y=b.m.trialEnd?trialLeft(b.m):9999;return x-y}).map(({m,i})=>{const red=m.trialEnd&&trialLeft(m)<=2&&trialLeft(m)>=0;return `<div class="post"><b style="${red?'color:#ff4d4d':''}">${esc(m.n)}</b> ${trialTag(m)}<br><small>Ingresó: <b>${dfecha(joinTs(m))}</b> · Lleva en la comunidad: <b>${tiempoEn(joinTs(m))}</b></small><br>${esc(m.e)} · ${esc(m.w)} · ${esc(m.car||'')} ${m.yr?esc(m.yr)+' año':''} · ${esc(m.uni||'')} ${esc(m.pais||'')}<br><a class="btn s" href="mailto:${esc(m.e)}?subject=MEDITHINK&body=${encodeURIComponent('Hola '+m.n+',\n\n')}">✉️ Enviar correo</a> <a class="btn o s" target="_blank" rel="noopener" href="https://wa.me/${esc(m.w.replace(/\D/g,''))}">💬 WhatsApp</a> <button class="btn d s" onclick="S.members.splice(${i},1);save();render()">Quitar</button></div>`}).join('')||'<p>Aún no hay miembros registrados en este navegador.</p>'}</div>`},
join(){const m=myM();if(m)return `<h1>Mi información</h1><div class="box"><div style="display:flex;gap:14px;align-items:center">${avHtml(m.photo,m.n,96)}<div><h2 style="margin:0">${esc(m.n)}</h2><small>${esc(m.e)}</small></div></div><p>Fecha de ingreso: <b>${dfecha(joinTs(m))}</b><br>${trialLeft(m)>0?`Fin de la prueba y próximo pago: <b>${dfecha(m.trialEnd)}</b><br>`:'Consulta con el administrador la fecha de tu próximo pago.<br>'}WhatsApp: ${esc(m.w)}<br>Carrera: ${esc(m.car||'—')}${m.yr?' · '+esc(m.yr)+' año':''}<br>Universidad: ${esc(m.uni||'—')} · País: ${esc(m.pais||'—')}<br>Estado: ${estado(m)}</p><div class="row" style="flex:none"><label class="btn s">Cambiar foto<input type="file" accept="image/*" hidden onchange="readImg(this,d=>{myM().photo=d;save();render()})"></label> <button class="btn o" onclick="logout()">Cerrar sesión</button></div></div>`;
return `<h1>Entrar o registrarme</h1><div class="box"><p><small>Escribe tu correo. Si ya tienes cuenta en este navegador entrarás directamente. Si es tu primera vez, completa el registro y tendrás 7 días de prueba gratis.</small></p><div class="row"><div><label>Correo electrónico</label><input id="je" type="email"></div></div><div class="row"><div><label>Nombre completo</label><input id="jn"></div><div><label>WhatsApp (con código de país)</label><input id="jw" inputmode="tel" placeholder="+591 7XXXXXXX"></div></div><div class="row"><div><label>Foto de perfil</label><input type="file" accept="image/*" id="jp"></div><div><label>Carrera</label><select id="jc" onchange="$('#jo').style.display=this.value==='Otra'?'block':'none';$('#jyb').style.display=this.value?'block':'none'"><option value="">Selecciona</option><option>Medicina</option><option>Enfermería</option><option>Fisioterapia</option><option>Nutrición</option><option>Otra</option></select></div></div><div id="jo" style="display:none"><label>¿Cuál es tu carrera?</label><input id="jcx"></div><div id="jyb" style="display:none"><label>Año de estudio</label><select id="jy">${[1,2,3,4,5,6,7].map(y=>`<option>${y}</option>`).join('')}</select></div><div class="row"><div><label>Universidad (opcional)</label><input id="ju"></div><div><label>País (opcional)</label><input id="jpa"></div></div><button class="btn" onclick="joinNow()">Entrar / Registrarme</button></div>`},
wa(){const w=S.wa,u=w.link||(w.num?'https://wa.me/'+w.num.replace(/\D/g,'')+'?text='+encodeURIComponent('Hola, quiero unirme al grupo de MEDITHINK'):'');return `<h1>Grupo de WhatsApp para miembros</h1><div class="box"><p>${esc(w.txt)}</p>${u?`<a class="btn" target="_blank" rel="noopener" href="${esc(u)}">📲 Unirme al grupo</a>`:'<p>El administrador aún no configuró el grupo.</p>'}</div>`},
admin(){if(!admin)return `<h1>Administrador</h1><div class="box"><label>Contraseña</label><input type="password" id="ap"><button class="btn" onclick="if($('#ap').value===S.pw){admin=true;render()}else alert('Contraseña incorrecta')">Entrar</button><p><small>Contraseña inicial: admin123. Cámbiala al entrar.</small></p></div>`;
const b=S.bank,f=(l,p,v)=>`<div><label>${l}</label><input value="${esc(v)}" onchange="${p}=this.value;save()"></div>`,n=(l,p,v)=>`<div><label>${l}</label><input type="number" step="any" value="${v}" onchange="${p}=+this.value;save()"></div>`;
return `<h1>Panel del administrador</h1>${welcomeAdmin()}${subAdminPanel()}<div class="box"><b>Modo de acceso</b><div class="row"><div><label>Cómo entran los usuarios</label><select onchange="S.mode=this.value;save()"><option value="both" ${S.mode==='both'?'selected':''}>Suscripción y permanente</option><option value="sub" ${S.mode==='sub'?'selected':''}>Solo suscripción</option><option value="perm" ${S.mode==='perm'?'selected':''}>Solo miembro permanente</option></select></div><div><label>Contenido</label><select onchange="S.paywall=this.value==='1';save()"><option value="0" ${!S.paywall?'selected':''}>Gratis (pago opcional)</option><option value="1" ${S.paywall?'selected':''}>Bloqueado hasta pagar</option></select></div>${f('Temporada','S.season',S.season)}</div></div>
<div class="box"><b>Montos por temporada</b><div class="row">${n('Mensual USD','S.sub.USD',S.sub.USD)}${n('Mensual Bs','S.sub.BOB',S.sub.BOB)}${n('Anual USD','S.perm.USD',S.perm.USD)}${n('Anual Bs','S.perm.BOB',S.perm.BOB)}</div></div>
<div class="box"><b>Depósito bancario (EE. UU.)</b><div class="row">${f('Banco','S.bank.name',b.name)}${f('Titular','S.bank.holder',b.holder)}${f('N.º de cuenta','S.bank.acct',b.acct)}${f('ABA / Routing','S.bank.aba',b.aba)}${f('SWIFT (transferencias del exterior)','S.bank.swift',b.swift)}${f('Zelle (opcional)','S.bank.zelle',b.zelle)}</div></div>
<div class="box"><b>QR de pago</b><br><label>Sube la imagen del QR de tu banco</label><input type="file" accept="image/*" onchange="fileTo(this,d=>{S.qr=d;save();alert('QR guardado')})"></div>
<div class="box"><b>Cronómetro</b><div class="row">${f('Enlace (URL) de tu app cronómetro','S.timerUrl',S.timerUrl)}</div><small>Al hacer clic en ⏱️, tu app se abre en una ventana aparte arriba a la derecha (como ChatGPT en Google), con sus propias configuraciones. Sin enlace, se usa un cronómetro básico.</small></div>
<div class="box"><b>Seguridad</b><div class="row">${f('Nueva contraseña de administrador','S.pw',S.pw)}</div><button class="btn d s" onclick="admin=false;go('home')">Salir del modo administrador</button></div>
<div class="box"><b>Grupo de WhatsApp y correo</b><div class="row">${f('Enlace de invitación del grupo','S.wa.link',S.wa.link)}${f('Número de WhatsApp (con código de país, ej. 59170000000)','S.wa.num',S.wa.num)}${f('Tu correo (para escribir a los miembros)','S.adminEmail',S.adminEmail)}</div><label>Texto de bienvenida al grupo</label><textarea rows="2" onchange="S.wa.txt=this.value;save()">${esc(S.wa.txt)}</textarea></div>${views.members()}<p>Para editar portadas y subir contenido, entra a <a href="#" onclick="go('subjects');return false">Materias</a>.</p>`}};
let chatSub='qr',chatPay='card',lsn=0,lastCu=null,nzv=.4;const nzA=new Audio();nzA.loop=true;nzA.volume=nzv;
const parseTime=s=>{const m=s.match(/^\[(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\]\s*/);return m?{t:(+(m[1]||0))*3600+(+m[2])*60+(+m[3]),rest:s.slice(m[0].length)}:{t:null,rest:s}};
const paras=t=>String(t||'').split(/\n+/).map(x=>x.trim()).filter(Boolean).map(x=>{const q=parseTime(x);return `<p${q.t!=null?` data-t="${q.t}"`:''}>${esc(q.rest)}</p>`}).join('');
const txtBox=t=>`<div class="tw"><div class="tc"><button class="btn s" onclick="locate(true)">📍 ¿Dónde voy?</button><label><input type="checkbox" id="fol" checked style="width:auto;margin:0 4px 0 0"> Seguimiento automático</label></div><div class="txt">${paras(t)}</div></div>`;
let userAt=0,lastIdx=-1;
function activeIdx(ps,m){
  const cur=m.currentTime;
  if(ps.some(p=>p.dataset.t!==undefined)){
    let idx=0,last=null;
    ps.forEach((p,k)=>{if(p.dataset.t!==undefined)last=+p.dataset.t;if(last!==null&&last<=cur)idx=k});
    return idx;
  }
  const lens=ps.map(p=>p.textContent.length),tot=lens.reduce((a,b)=>a+b,0)||1,target=cur/m.duration*tot;
  let acc=0;for(let k=0;k<ps.length;k++){acc+=lens[k];if(acc>=target)return k}
  return ps.length-1;
}
function locate(force){
  const m=document.querySelector('.pl video,.pl audio'),box=document.querySelector('.txt');
  if(!m||!box||!m.duration||!isFinite(m.duration))return;
  const ps=[...box.querySelectorAll('p')];if(!ps.length)return;
  const idx=activeIdx(ps,m);
  ps.forEach((p,k)=>p.classList.toggle('cur',k===idx));
  const fo=document.getElementById('fol'),on=fo?fo.checked:true,recent=Date.now()-userAt<4000;
  if(force||(on&&!recent&&idx!==lastIdx)){
    box.scrollTo({top:Math.max(0,ps[idx].offsetTop-box.clientHeight*.3),behavior:'smooth'});
  }
  lastIdx=idx;
}
// Tocar un párrafo con marca de tiempo salta el audio o video a ese punto
document.addEventListener('click',e=>{
  const p=e.target.closest&&e.target.closest('.txt p[data-t]');if(!p)return;
  const m=document.querySelector('.pl video,.pl audio');if(!m)return;
  m.currentTime=+p.dataset.t;m.play().catch(()=>{});locate(true);
});
// Si el lector se desplaza a mano, el seguimiento automático espera unos segundos
['wheel','touchstart','mousedown'].forEach(ev=>document.addEventListener(ev,e=>{
  if(e.target.closest&&e.target.closest('.txt'))userAt=Date.now();
},{passive:true}));
function toggleAdv(){const s=cur(),k=s.id+':'+lessons(s)[lsn].id;if(S.done[k])delete S.done[k];else S.done[k]=1;updProg()}
function updProg(){const s=cur(),L=lessons(s),n=L.filter(l=>S.done[s.id+':'+l.id]).length,p=L.length?Math.round(n/L.length*100):0,bi=document.querySelector('.bar i');if(bi){bi.style.width=p+'%';document.querySelector('.bar span').textContent=p+'%'}document.querySelectorAll('.ls').forEach((e,i)=>{if(L[i])e.querySelector('.ck').textContent=S.done[s.id+':'+L[i].id]?'✓':''});const a=document.querySelector('.adv');if(a&&L[lsn])a.classList.toggle('on',!!S.done[s.id+':'+L[lsn].id]);const m=S.members.find(x=>x.id===S.me);if(m)m.adv=Object.keys(S.done).length;save()}
function noiseBox(){const N=S.noise||[];return `<div class="box" style="margin-top:14px"><b>🌧️ Ruido blanco para estudiar</b> <small>(opcional)</small> <div class="row"><div><label>Tema de ruido</label><select onchange="setNoise(this.value)"><option value="">Sin ruido</option>${N.map(n=>`<option value="${n.id}" ${S.nz===n.id?'selected':''}>${esc(n.n)}</option>`).join('')}</select></div><div><label>Volumen</label><input type="range" min="0" max="1" step="0.05" value="${nzv}" oninput="nzA.volume=nzv=+this.value"></div></div>${N.length?'':'<small>El administrador aún no subió temas de ruido blanco.</small>'}${admin?`<hr><label class="dz" ondragover="event.preventDefault();this.classList.add('ov')" ondragleave="this.classList.remove('ov')" ondrop="event.preventDefault();this.classList.remove('ov');addNoise(event.dataTransfer.files)"><input type="file" multiple hidden accept="audio/*" onchange="addNoise(this.files);this.value=''">Arrastra aquí audios de ruido blanco<br><small>o haz clic para elegir</small></label><input placeholder="o pega un enlace .mp3" onchange="addNoiseUrl(this.value)">${N.map(n=>`<div class="post">${esc(n.n)} <button class="btn d s" onclick="delNoise('${n.id}')">Quitar</button></div>`).join('')}`:''}</div>`}
async function setNoise(id){S.nz=id;save();if(!id){nzA.pause();return}const n=(S.noise||[]).find(x=>x.id===id);if(!n)return;let u=n.src;if(n.key){try{const b=await getB(n.key);if(b)u=URL.createObjectURL(b)}catch(e){}}if(!u){alert('Archivo no disponible en este navegador');return}nzA.src=u;nzA.play().catch(()=>{})}
async function addNoise(fl){for(const f of fl){if(!f.type.startsWith('audio/')){alert(f.name+': usa un archivo de audio');continue}if((S.noise||[]).length>=10){alert('Máximo 10 sonidos de ruido blanco.');break}const id='z'+Date.now()+Math.random().toString(36).slice(2,5);try{await putB('n'+id,f);S.noise.push({id,n:f.name.replace(/\.[^.]+$/,''),key:'n'+id})}catch(e){alert('No se pudo guardar. Usa un enlace.')}}save();render()}
function addNoiseUrl(u){u=u.trim();if(!u)return;if((S.noise||[]).length>=10){alert('Máximo 10 sonidos de ruido blanco.');return}S.noise.push({id:'z'+Date.now(),n:u.split('/').pop().replace(/\.[^.]+$/,'')||'Ruido',src:u});save();render()}
function delNoise(id){const n=S.noise.find(x=>x.id===id);if(n&&n.key)delB(n.key).catch(()=>{});S.noise=S.noise.filter(x=>x.id!==id);if(S.nz===id){nzA.pause();S.nz=''}save();render()}
function applySeo(){const a=S.about;document.title=a.seoTitle||a.company;[['description',a.seoDesc],['keywords',a.kw],['author',a.company]].forEach(([n,c])=>{let m=document.querySelector('meta[name='+n+']');if(!m){m=document.createElement('meta');m.name=n;document.head.appendChild(m)}m.content=c||''})}
let twLeft=0,twRun=false,twI,twEnd=0,twWarn=false,ac;
const p2=n=>String(n).padStart(2,'0'),tf=t=>p2(t/3600|0)+':'+p2((t/60|0)%60)+':'+p2(t%60);
function beep(n){try{ac=ac||new(window.AudioContext||window.webkitAudioContext)();for(let i=0;i<n;i++){const o=ac.createOscillator(),g=ac.createGain(),t=ac.currentTime+i*.45;o.frequency.value=880;o.connect(g);g.connect(ac.destination);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.3,t+.02);g.gain.exponentialRampToValueAtTime(.0001,t+.35);o.start(t);o.stop(t+.4)}}catch(e){}}
function twShow(t){$('#twd').textContent=tf(t);$('#twt').textContent=tf(t).slice(t>=3600?0:3)}
function twPre(){if(!twRun&&!twLeft)twShow(+$('#th').value*3600+ +$('#tmn').value*60)}
function twToggle(){$('#twp').classList.toggle('open')}
function twStart(){if(twRun){clearInterval(twI);twRun=false;$('#tgo').textContent='Continuar';return}try{ac=ac||new(window.AudioContext||window.webkitAudioContext)();ac.resume()}catch(e){}if(!twLeft){twLeft=+$('#th').value*3600+ +$('#tmn').value*60;twWarn=twLeft<=300}if(!twLeft)return;twEnd=Date.now()+twLeft*1000;twRun=true;$('#tgo').textContent='Pausar';twI=setInterval(()=>{twLeft=Math.max(0,Math.round((twEnd-Date.now())/1000));twShow(twLeft);if(!twWarn&&twLeft<=300&&twLeft>0){twWarn=true;beep(2)}if(twLeft===0){clearInterval(twI);twRun=false;$('#tgo').textContent='Iniciar';beep(4);setTimeout(twPre,50)}},500)}
function twReset(){clearInterval(twI);twRun=false;twLeft=0;$('#tgo').textContent='Iniciar';twPre()}
const lessons=s=>s.lessons||(s.lessons=(s.items||[]).map((it,i)=>({id:'o'+i,t:it.title,media:it.type==='texto'||!it.src?null:{type:it.type,src:it.src},text:it.text||''})));
const cur=()=>S.subjects[arg];
let dragL=-1;
function moveLesson(from,to){
  const L=lessons(cur());
  if(from<0||from>=L.length||to===from||to===from+1)return;
  const x=L.splice(from,1)[0];
  const pos=to>from?to-1:to;
  L.splice(pos,0,x);
  if(lsn===from)lsn=pos;
  else if(from<lsn&&pos>=lsn)lsn--;
  else if(from>lsn&&pos<=lsn)lsn++;
  dragL=-1;save();render();
}
function dropLesson(i,ev){
  ev.preventDefault();ev.currentTarget.classList.remove('dropz');
  const r=ev.currentTarget.getBoundingClientRect();
  moveLesson(dragL,i+(ev.clientX>r.left+r.width/2?1:0));
}
function lessonArrows(i,n){
  return `<span style="display:flex;gap:2px;margin-left:6px"><button class="mini" style="padding:0 6px" ${i===0?'disabled':''} onclick="event.stopPropagation();moveLesson(${i},${i-1})" title="Subir">▲</button><button class="mini" style="padding:0 6px" ${i>=n-1?'disabled':''} onclick="event.stopPropagation();moveLesson(${i},${i+2})" title="Bajar">▼</button></span>`;
}
const idb=()=>new Promise((r,j)=>{const q=indexedDB.open('mt',1);q.onupgradeneeded=()=>q.result.createObjectStore('f');q.onsuccess=()=>r(q.result);q.onerror=()=>j(q.error)});
const putB=async(k,b)=>{const d=await idb();return new Promise((r,j)=>{const t=d.transaction('f','readwrite');t.objectStore('f').put(b,k);t.oncomplete=r;t.onerror=()=>j(t.error)})};
const getB=async k=>{const d=await idb();return new Promise((r,j)=>{const q=d.transaction('f').objectStore('f').get(k);q.onsuccess=()=>r(q.result);q.onerror=()=>j(q.error)})};
const delB=async k=>{const d=await idb();d.transaction('f','readwrite').objectStore('f').delete(k)};
function dz(ti,txt){return `<label class="dz" ondragover="event.preventDefault();this.classList.add('ov')" ondragleave="this.classList.remove('ov')" ondrop="event.preventDefault();this.classList.remove('ov');addFiles(event.dataTransfer.files,${ti})"><input type="file" multiple hidden accept="video/*,audio/*,.txt,.md" onchange="addFiles(this.files,${ti});this.value=''">${txt}<br><small>o haz clic para elegir archivos</small></label>`}
async function addFiles(fl,ti){const by={};let made=0;for(const f of fl){const v=f.type.startsWith('video/'),a=f.type.startsWith('audio/'),t=/\.(txt|md)$/i.test(f.name)||f.type==='text/plain';if(!v&&!a&&!t){alert(f.name+': formato no compatible. Usa video, audio o .txt');continue}
const nm=f.name.replace(/\.[^.]+$/,'');let l=ti>=0?lessons(cur())[ti]:by[nm];if(!l){l={id:'l'+Date.now()+Math.random().toString(36).slice(2,5),t:nm,media:null,text:''};lessons(cur()).push(l);by[nm]=l;made++}
if(v||a){const k='f'+l.id;try{await putB(k,f);l.media={type:v?'video':'audio',key:k,name:f.name}}catch(e){alert('Este navegador no pudo guardar el archivo. Usa un enlace de video/audio.')}}else l.text=await f.text()}
save();if(made)lsn=lessons(cur()).length-1;render()}
function adminLesson(c){return `<div class="box" style="margin-top:14px"><b>Editar este tema</b><label>Título</label><input value="${esc(c.t)}" onchange="setL('t',this.value);render()"><label>Texto de seguimiento. Para sincronizar, escribe al inicio de cada párrafo su minuto: [01:30] Texto del párrafo. Sin minutos el avance es aproximado</label><textarea rows="6" onchange="setL('text',this.value);render()">${esc(c.text)}</textarea>${dz(lsn,'Arrastra aquí un video, audio o .txt para este tema')}<label>Cuestionario (una pregunta por línea, formato: Pregunta | Respuesta)</label><textarea rows="4" onchange="setL('quiz',this.value);render()">${esc(c.quiz||'')}</textarea><input type="file" accept=".txt,.md" onchange="readTxt(this,t=>{setL('quiz',t);render()})"><label>o pega un enlace de video/audio (.mp4, .mp3)</label><input placeholder="https://..." onchange="setLink(this.value)"><button class="btn d s" onclick="delLesson()">Eliminar tema</button></div>`}
function setL(k,v){lessons(cur())[lsn][k]=v;save()}
function setLink(u){u=u.trim();if(!u)return;lessons(cur())[lsn].media={type:/\.(mp3|wav|m4a|ogg|aac)(\?|$)/i.test(u)?'audio':'video',src:u};save();render()}
function delLesson(){if(!confirm('¿Eliminar este tema?'))return;const l=lessons(cur()).splice(lsn,1)[0];if(l.media&&l.media.key)delB(l.media.key).catch(()=>{});lsn=0;save();render()}
function nextL(){const L=lessons(cur());if(lsn<L.length-1){lsn++;render()}}
function player(m){const k=m.key?` data-k="${m.key}"`:'',sc=m.src?` src="${esc(m.src)}"`:'';const el=m.type==='video'?`<video playsinline${k}${sc}></video>`:`<audio${k}${sc}></audio><div class="au">🎧<b>${esc(m.name||'Audio')}</b></div>`;return `<div class="pl">${el}<div class="ctl"><button class="sk5" data-d="-5" aria-label="5 segundos atrás" title="5 segundos atrás">⏪ 5s</button><button class="pp" aria-label="Reproducir o pausar">▶</button><button class="sk5" data-d="5" aria-label="5 segundos adelante" title="5 segundos adelante">5s ⏩</button><input type="range" class="sk" min="0" max="1000" value="0" aria-label="Posición"><span class="tt">0:00</span><select class="sp" aria-label="Velocidad"><option value="1">1×</option><option value="0.75">0.75×</option><option value="1.25">1.25×</option><option value="1.5">1.5×</option><option value="2">2×</option></select><input type="range" class="vo" min="0" max="1" step="0.05" value="1" aria-label="Volumen">${m.type==='video'?'<button class="fs" aria-label="Pantalla completa">⛶</button>':''}</div></div>`}
function wire(){document.querySelectorAll('.pl').forEach(p=>{const m=p.querySelector('video,audio'),pp=p.querySelector('.pp'),sk=p.querySelector('.sk'),tt=p.querySelector('.tt'),f=t=>isFinite(t)?(t/60|0)+':'+String(t%60|0).padStart(2,'0'):'0:00';
if(m.dataset.k)getB(m.dataset.k).then(b=>{if(b)m.src=URL.createObjectURL(b);else tt.textContent='Archivo no disponible en este navegador'}).catch(()=>{});
pp.onclick=()=>m.paused?m.play():m.pause();p.querySelectorAll('.sk5').forEach(b=>b.onclick=()=>{const d=+b.dataset.d;m.currentTime=Math.min(m.duration||Infinity,Math.max(0,m.currentTime+d));locate(true)});if(m.tagName==='VIDEO')m.onclick=pp.onclick;
m.onplay=()=>{pp.textContent='⏸';locate(true)};m.onseeked=()=>locate(true);m.onpause=()=>pp.textContent='▶';
m.ontimeupdate=()=>{sk.value=m.duration?m.currentTime/m.duration*1000:0;tt.textContent=f(m.currentTime)+' / '+f(m.duration);locate(false)};
m.onended=()=>{const s=cur(),l=lessons(s)[lsn];S.done[s.id+':'+l.id]=1;updProg()};
sk.oninput=()=>{if(m.duration)m.currentTime=sk.value/1000*m.duration};
p.querySelector('.sp').onchange=e=>m.playbackRate=+e.target.value;p.querySelector('.vo').oninput=e=>m.volume=+e.target.value;
const fs=p.querySelector('.fs');if(fs)fs.onclick=()=>p.requestFullscreen&&p.requestFullscreen()})}
function addSubject(){if(S.subjects.length>=50){alert('Ya tienes 50 materias, que es el máximo.');return}S.subjects.push({id:S.subjects.length,n:'Nueva materia',icon:'📘',cover:'',items:[]});save();go('subject',S.subjects.length-1)}
function delSubject(i){if(confirm('¿Eliminar esta materia y todo su contenido?')){S.subjects.splice(i,1);S.subjects.forEach((x,k)=>x.id=k);save();go('subjects')}}
async function joinNow(){const e=$('#je').value.trim().toLowerCase();if(!/^\S+@\S+\.\S+$/.test(e))return alert('Escribe un correo válido.');
const old=S.members.find(x=>x.e.toLowerCase()===e);if(old){S.me=old.id;setCk(old.id);save();go('home');return}
const n=$('#jn').value.trim(),w=$('#jw').value.trim(),car=$('#jc').value,oth=$('#jcx').value.trim();if(!n||w.replace(/\D/g,'').length<8||!car)return alert('Completa nombre, WhatsApp y carrera.');if(car==='Otra'&&!oth)return alert('Escribe tu carrera.');
const f=$('#jp').files[0],photo=f?await imgData(f):'',id='m'+Date.now();
S.members.push({id,n,e,w,d:new Date().toLocaleDateString('es'),photo,car:car==='Otra'?oth:car,yr:$('#jy').value,uni:$('#ju').value.trim(),pais:$('#jpa').value.trim(),trialEnd:Date.now()+7*864e5,joinTs:Date.now(),sec:0,adv:0});S.me=id;setCk(id);save();go('home')}
function setCk(id){try{document.cookie='mt_member='+id+'; max-age=31536000; path=/; SameSite=Lax'}catch(x){}}
function imgData(f){return new Promise(res=>{const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const k=Math.min(1,160/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=im.width*k;c.height=im.height*k;c.getContext('2d').drawImage(im,0,0,c.width,c.height);res(c.toDataURL('image/jpeg',.85))};im.onerror=()=>res('');im.src=r.result};r.readAsDataURL(f)})}
async function readImg(inp,cb){if(inp.files[0])cb(await imgData(inp.files[0]))}
function readTxt(inp,cb){const f=inp.files[0];if(!f)return;const r=new FileReader();r.onload=()=>cb(r.result);r.readAsText(f)}
const myM=()=>S.members.find(m=>m.id===S.me);
const DAY=864e5;
const joinTs=m=>m.joinTs||(m.trialEnd?m.trialEnd-7*DAY:0);
const dfecha=ts=>ts?new Date(ts).toLocaleDateString('es',{day:'numeric',month:'long',year:'numeric'}):'—';
function tiempoEn(ts){
  if(!ts)return '—';
  const a=new Date(ts),b=new Date();
  let m=(b.getFullYear()-a.getFullYear())*12+(b.getMonth()-a.getMonth());
  let d=b.getDate()-a.getDate();
  if(d<0){m--;d+=new Date(b.getFullYear(),b.getMonth(),0).getDate()}
  if(m<0)m=0;if(d<0)d=0;
  return `${m} ${m===1?'mes':'meses'} y ${d} ${d===1?'día':'días'}`;
}
function trialLeft(m){return m.trialEnd?Math.ceil((m.trialEnd-Date.now())/DAY):0}
function trialTag(m){
  if(!m.trialEnd)return '';
  const L=trialLeft(m);
  if(L<=0)return '<span style="color:#ff4d4d;font-weight:700">Prueba vencida</span>';
  const red=L<=2;
  return `<span style="color:${red?'#ff4d4d':'var(--mu)'};font-weight:${red?700:400}">Prueba: ${L} ${L===1?'día':'días'}${red?' · por terminar':''}</span>`;
}
const dmSelf=()=>admin?'admin':S.me;
const myName=()=>{const m=myM();return m?m.n:'Usuario'};
function dmName(id){if(id==='admin')return S.about.company+' (Administrador)';const m=S.members.find(x=>x.id===id);return m?m.n:'Usuario'}
function avHtml(ph,nm,s){return ph?`<img src="${ph}" alt="" style="width:${s}px;height:${s}px;border-radius:50%;object-fit:cover">`:`<span style="display:inline-grid;place-items:center;width:${s}px;height:${s}px;border-radius:50%;background:linear-gradient(135deg,#0a6cff,#00b4ff);color:#fff;font-weight:800;font-size:${Math.round(s*.4)}px">${esc(String(nm||'?')[0]).toUpperCase()}</span>`}
function estado(m){if(!m)return '';if(m.paid)return 'Suscripción activa';if(m.trialEnd&&m.trialEnd>Date.now())return 'Prueba gratuita: '+Math.ceil((m.trialEnd-Date.now())/864e5)+' días restantes';return 'Sin suscripción activa'}
function renderAv(){const b=$('#avb');if(!b)return;const m=myM(),a=dmSelf();b.innerHTML=a==='admin'?'⚙️':avHtml(m&&m.photo,m&&m.n,32);const u=unreadN(),nb=$('#nb');if(nb){nb.textContent=u>0?u:'';nb.style.display=u>0?'inline-block':'none'}}
function togPf(){const p=$('#pf');if(p.style.display==='block'){p.style.display='none';return}const m=myM(),a=dmSelf();let h;if(a==='admin')h=`<div style="display:flex;gap:10px;align-items:center">${avHtml('','Admin',44)}<div><b>${esc(S.about.company)}</b><br><small>Administrador</small></div></div>`;else if(m)h=`<div style="display:flex;gap:10px;align-items:center">${avHtml(m.photo,m.n,48)}<div><b>${esc(m.n)}</b><br><small>${esc(m.e)}</small><br><small>${estado(m)}</small></div></div>`;else h='<p>No has iniciado sesión.</p>';
p.innerHTML=h+'<hr style="border:0;border-top:1px solid var(--bd);margin:10px 0">'+`<button class="ib" onclick="go('join');togPf()">👤 Mi información</button><button class="ib" onclick="go('dm');togPf()">💬 Chats privados</button><button class="ib" onclick="go('notes');togPf()">🔔 Comunicados</button>`+(a==='admin'?`<button class="ib" onclick="go('admin');togPf()">⚙️ Panel del administrador</button>`:'')+(S.me?`<button class="ib" onclick="logout();togPf()">🚪 Cerrar sesión</button>`:'');p.style.display='block'}
const CATS=['COMUNIDAD MEDICINA','PREGUNTAS','SOPORTE'],EM=['👍','❤️','👏','🧠','🔥','😂','😮'];let feedCat='Todos',dmTo=null;
function feedHtml(){const me=dmSelf(),P=(S.feed||[]).filter(p=>feedCat==='Todos'||p.cat===feedCat).slice().sort((a,b)=>(b.ts||0)-(a.ts||0));
const comp=me?`<div class="box"><label>Categoría</label><select id="fc">${CATS.map(c=>`<option>${c}</option>`).join('')}</select><label>Título (obligatorio)</label><input id="ft" placeholder="Escribe un título claro"><label>Contenido</label><textarea id="fx" rows="3"></textarea><div class="row" style="flex:none;flex-wrap:wrap;gap:6px"></div><br><button class="btn" onclick="postFeed()">Publicar</button></div>`:`<div class="box">Para publicar y comentar, <a href="#" onclick="go('join');return false">regístrate o inicia sesión</a>. Tu prueba de 7 días se activa al registrarte.</div>`;
return `<div class="seg"><button class="${feedCat==='Todos'?'on':''}" onclick="feedCat='Todos';render()">Todos</button>${CATS.map(c=>`<button class="${feedCat===c?'on':''}" onclick="feedCat='${c}';render()">${c}</button>`).join('')}</div>${comp}${P.map(postHtml).join('')||'<p>Aún no hay publicaciones en esta categoría.</p>'}`}
function hace(ts,fallback){
  if(!ts)return fallback||'';
  const s=Math.floor((Date.now()-ts)/1000);
  if(s<60)return 'hace un momento';
  const m=Math.floor(s/60);if(m<60)return `hace ${m} min`;
  const h=Math.floor(m/60);if(h<24)return `hace ${h} h`;
  const d=Math.floor(h/24);if(d<7)return `hace ${d} ${d===1?'día':'días'}`;
  return fallback||new Date(ts).toLocaleDateString('es');
}
let replyFor=null,dragI=-1;
function moveSub(from,to){
  if(from<0||from>=S.subjects.length||to===from||to===from+1)return;
  const x=S.subjects.splice(from,1)[0];
  if(to>from)to--;
  S.subjects.splice(to,0,x);dragI=-1;save();render();
}
function dropOn(i,ev){ev.preventDefault();ev.currentTarget.classList.remove('dropz');const r=ev.currentTarget.getBoundingClientRect();moveSub(dragI,i+(ev.clientX>r.left+r.width/2?1:0))}
function arrowCtl(i){const n=S.subjects.length;return `<div class="row" style="flex:none;margin-top:8px;gap:6px"><button class="mini" ${i===0?'disabled':''} onclick="event.stopPropagation();moveSub(${i},${i-1})">◀ antes</button><button class="mini" ${i>=n-1?'disabled':''} onclick="event.stopPropagation();moveSub(${i},${i+2})">después ▶</button></div><small style="color:var(--mu)">Arrastra la tarjeta o usa las flechas</small>`}
function rootOf(cm,c){let x=c;const seen=new Set();while(x.pid&&!seen.has(x.id)){seen.add(x.id);const up=cm.find(y=>y.id===x.pid);if(!up)break;x=up}return x}
function bubble(p,c,isReply,mention,me){
  const L=c.likes||[],liked=!!me&&L.includes(me),mineC=!!me&&(c.aid===me||me==='admin');
  return `<div class="bubw ${isReply?'rep':''}">${avHtml(c.av,c.a,isReply?30:38)}<div class="bubc"><div class="bub"><b>${esc(c.a)}</b> <small>${hace(c.ts,c.d)}</small><div style="margin-top:4px;white-space:pre-wrap">${mention?`<span class="men">@${esc(mention)}</span> `:''}${esc(c.x)}</div></div><div class="bact"><button class="lk ${liked?'on':''}" onclick="likeC('${p.id}','${c.id}')">👍${L.length?' '+L.length:''}</button>${me?`<button class="lk" onclick="openReply('${p.id}','${c.id}')">Responder</button>`:''}${mineC?`<button class="lk" onclick="delCm('${p.id}','${c.id}')">Borrar</button>`:''}</div></div></div>`;
}
function replyBox(p,cid){const t=(p.cm||[]).find(c=>c.id===cid);return `<div class="cmtin rb" style="margin-left:46px"><input id="rc" placeholder="Responder a ${esc(t?t.a:'')}..." onkeydown="if(event.key==='Enter')addCm('${p.id}','${cid}')"><button class="mini on" onclick="addCm('${p.id}','${cid}')">Responder</button><button class="mini" onclick="replyFor=null;render()">✕</button></div>`}
function threadHtml(p,root,me,cm){
  const reps=cm.filter(c=>c.id!==root.id&&rootOf(cm,c).id===root.id).sort((a,b)=>(a.ts||0)-(b.ts||0));
  let h=`<div class="thread">${bubble(p,root,false,null,me)}`;
  reps.forEach(c=>{const t=cm.find(y=>y.id===c.pid);const men=t&&t.id!==root.id?t.a:null;h+=bubble(p,c,true,men,me)});
  if(replyFor&&(replyFor===root.id||reps.some(r=>r.id===replyFor)))h+=replyBox(p,replyFor);
  return h+'</div>';
}
function openReply(pid,cid){replyFor=replyFor===cid?null:cid;render();const e=document.getElementById('rc');if(e)e.focus()}
function postView(){
  const p=S.feed.find(x=>x.id===arg);
  if(!p)return `<div class="box">Esta publicación ya no existe. <a href="#" onclick="go('home');return false">Volver a la comunidad</a></div>`;
  const me=dmSelf(),L=p.likes||[],cm=p.cm||[],liked=!!me&&L.includes(me),mine=me&&(p.aid===me||me==='admin');
  cm.forEach((c,k)=>{if(!c.id)c.id='c'+p.id+k});
  const roots=cm.filter(c=>!c.pid).sort((a,b)=>(a.ts||0)-(b.ts||0));
  return `<a href="#" onclick="go('home');return false" style="font-size:13px">← Comunidad</a>
  <div class="post2" style="margin-top:8px"><div style="display:flex;gap:10px;align-items:center">${avHtml(p.av,p.a,44)}<div><b>${esc(p.a)}</b><br><small>${hace(p.ts,p.d)} · <span class="pill">${esc(p.cat)}</span></small></div>${mine?`<button class="mini" style="margin-left:auto" onclick="delP('${p.id}')">Borrar</button>`:''}</div>
  <h2 style="margin:12px 0 6px">${esc(p.t)}</h2><p style="white-space:pre-wrap;margin:0 0 12px">${esc(p.x)}</p>
  <div class="act"><button class="lk ${liked?'on':''}" onclick="likeP('${p.id}')">👍 Me gusta${L.length?' '+L.length:''}</button><span class="lk" style="cursor:default">💬 ${cm.length} comentarios</span></div></div>
  ${me?`<div class="cmtin" style="margin-top:14px"><input id="ctop" placeholder="Escribe un comentario..." onkeydown="if(event.key==='Enter')addCm('${p.id}',null)"><button class="mini on" onclick="addCm('${p.id}',null)">Comentar</button></div>`:'<small>Inicia sesión para comentar.</small>'}
  <div class="thread-list" style="margin-top:12px">${roots.map(r=>threadHtml(p,r,me,cm)).join('')||'<p>Sé el primero en comentar.</p>'}</div>`;
}
function postHtml(p){
  const me=dmSelf(),L=p.likes||[],cm=p.cm||[],mine=me&&(p.aid===me||me==='admin'),liked=!!me&&L.includes(me);
  return `<div class="post2"><div style="display:flex;gap:10px;align-items:center">${avHtml(p.av,p.a,38)}<div><b>${esc(p.a)}</b><br><small>${hace(p.ts,p.d)} · <span class="pill">${esc(p.cat)}</span></small></div>${mine?`<button class="mini" style="margin-left:auto" onclick="delP('${p.id}')">Borrar</button>`:''}</div><h3 onclick="go('post','${p.id}')" style="margin:10px 0 4px;cursor:pointer">${esc(p.t)}</h3><p style="white-space:pre-wrap;margin:0 0 6px">${esc(p.x)}</p><div class="act"><button class="lk ${liked?'on':''}" onclick="likeP('${p.id}')">👍${L.length?' '+L.length:''}</button><button class="lk" onclick="go('post','${p.id}')">💬 ${cm.length} comentarios</button></div></div>`;
}
function likeC(pid,cid){const p=S.feed.find(x=>x.id===pid),me=dmSelf();if(!me||!p)return alert('Inicia sesión para dar me gusta.');const c=(p.cm||[]).find(x=>x.id===cid);if(!c)return;c.likes=c.likes||[];c.likes=c.likes.includes(me)?c.likes.filter(x=>x!==me):c.likes.concat(me);save();render()}
function delCm(pid,cid){
  const p=S.feed.find(x=>x.id===pid);if(!p||!confirm('¿Borrar este comentario y sus respuestas?'))return;
  const kill=new Set([cid]);let grow=true;
  while(grow){grow=false;(p.cm||[]).forEach(c=>{if(c.pid&&kill.has(c.pid)&&!kill.has(c.id)){kill.add(c.id);grow=true}})}
  p.cm=(p.cm||[]).filter(c=>!kill.has(c.id));save();render();
}
function postFeed(){const me=dmSelf();if(!me)return alert('Regístrate o inicia sesión para publicar.');const t=$('#ft').value.trim(),x=$('#fx').value.trim(),c=$('#fc').value;if(!t)return alert('El título es obligatorio.');if(!x)return alert('Escribe el contenido de tu publicación.');const m=myM();S.feed.unshift({id:'p'+Date.now(),aid:me,a:me==='admin'?S.about.company+' (Admin)':myName(),av:m?m.photo:'',t,x,cat:c,d:new Date().toLocaleDateString('es'),ts:Date.now(),likes:[],rx:{},cm:[]});notify('post',S.feed[0].a,me,S.feed[0].t,S.feed[0].id);save();render()}
function likeP(id){const p=S.feed.find(x=>x.id===id),me=dmSelf();if(!me||!p)return alert('Inicia sesión para interactuar.');p.likes=p.likes||[];p.likes=p.likes.includes(me)?p.likes.filter(x=>x!==me):p.likes.concat(me);save();render()}
function reactP(id,e){const p=S.feed.find(x=>x.id===id),me=dmSelf();if(!me||!p)return alert('Inicia sesión para reaccionar.');p.rx=p.rx||{};const a=p.rx[e]||[];p.rx[e]=a.includes(me)?a.filter(x=>x!==me):a.concat(me);save();render()}
function addCm(id,pid){
  const p=S.feed.find(x=>x.id===id),me=dmSelf(),el=$(pid?'#rc':'#ctop'),v=el?el.value.trim():'';
  if(!p||!me)return alert('Inicia sesión para comentar.');
  if(!v)return;
  const m=myM(),who=me==='admin'?S.about.company:myName();
  p.cm=(p.cm||[]).concat({id:'c'+Date.now()+Math.random().toString(36).slice(2,5),pid:pid||null,aid:me,a:who,av:m?m.photo:'',x:v,d:new Date().toLocaleDateString('es'),ts:Date.now(),likes:[]});
  notify(pid?'reply':'comment',who,me,p.t,p.id);
  replyFor=null;save();render();
}
function delP(id){if(confirm('¿Borrar esta publicación?')){S.feed=S.feed.filter(x=>x.id!==id);save();render()}}
function dmKey(a,b){return [a,b].sort().join('|')}
function dmView(){const me=dmSelf();if(!me)return '<h1>Chats privados</h1><div class="box">Inicia sesión para escribir al administrador o a otros miembros activos.</div>';const C=me==='admin'?S.members.map(m=>m.id):['admin',...S.members.filter(m=>m.id!==me).map(m=>m.id)];const to=C.includes(dmTo)?dmTo:C[0];dmTo=to;const msgs=to?(S.dm[dmKey(me,to)]||[]):[];
return `<h1>💬 Chats privados</h1><div class="cls" style="grid-template-columns:240px minmax(0,1fr)"><div class="side">${C.map(c=>`<div class="ls ${c===to?'on':''}" tabindex="0" onclick="dmTo='${c}';render()">👤 <span>${esc(dmName(c))}</span></div>`).join('')||'<small>Aún no hay miembros.</small>'}</div><div class="box">${to?`<b>${esc(dmName(to))}</b><div style="max-height:52vh;overflow:auto;margin:10px 0">${msgs.map(x=>`<div class="post"><small>${x.d}</small> <b>${esc(dmName(x.f))}:</b> ${esc(x.x)}</div>`).join('')||'<small>Sin mensajes todavía.</small>'}</div><div class="row"><input id="dmi" placeholder="Escribe un mensaje" onkeydown="if(event.key==='Enter')sendDm()"><button class="btn" onclick="sendDm()">Enviar</button></div>`:'<small>Sin contactos todavía.</small>'}</div></div>`}
function sendDm(){const me=dmSelf(),to=dmTo,el=$('#dmi'),x=el?el.value.trim():'';if(!me||!to||!x)return;const k=dmKey(me,to);S.dm[k]=(S.dm[k]||[]).concat({f:me,x,d:new Date().toLocaleString('es',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})});save();render()}
function notesView(){S.seen=(S.notes||[]).length;S.nRead=Date.now();save();const NT=(S.notifs||[]).slice().reverse().slice(0,50);const N=(S.notes||[]).map((n,i)=>({n,i})).reverse();return `<h1>🔔 Avisos y comunicados</h1><h2>Avisos de la comunidad</h2>${NT.map(n=>`<div class="post"><small>${hace(n.ts)}</small> <b>${esc(n.by)}</b> ${n.k==='post'?'publicó':(n.k==='reply'?'respondió':'comentó')} en <a href="#" onclick="go('post','${n.pid}');return false">${esc(n.title)}</a></div>`).join('')||'<small>Aún no hay avisos.</small>'}<h2>Comunicados del administrador</h2>${admin?`<div class="box"><label>Título</label><input id="nt2"><label>Mensaje</label><textarea id="nx2" rows="3"></textarea><button class="btn" onclick="postNote()">Publicar comunicado</button></div>`:''}${N.map(({n,i})=>`<div class="box"><b>${esc(n.t)}</b> <small>${n.d}</small>${admin?` <button class="btn d s" onclick="S.notes.splice(${i},1);save();render()">Borrar</button>`:''}<p style="white-space:pre-wrap">${esc(n.x)}</p></div>`).join('')||'<p>No hay comunicados aún.</p>'}`}
function postNote(){const t=$('#nt2').value.trim(),x=$('#nx2').value.trim();if(!t||!x)return alert('Escribe título y mensaje.');S.notes.push({t,x,d:new Date().toLocaleDateString('es')});save();render()}
function welcomeAdmin(){const h=S.hero||{};return `<div class="box"><b>Pantalla de inicio</b><label>Título de bienvenida</label><input value="${esc(h.t1||'')}" onchange="S.hero=Object.assign({},S.hero,{t1:this.value});save()"><label>Texto de bienvenida</label><textarea rows="3" onchange="S.hero=Object.assign({},S.hero,{body:this.value});save()">${esc(h.body||'')}</textarea><div class="row"><div><label>Logo (imagen, opcional)</label><input type="file" accept="image/*" onchange="readImg(this,d=>{S.logo=d;save();render()})"></div><div><label>Video de bienvenida (archivo)</label><input type="file" accept="video/*" onchange="addWelcome(this.files)"></div><div><label>o enlace de video (.mp4)</label><input placeholder="https://..." onchange="S.wv={src:this.value.trim()};save();render()"></div></div>${S.wv?'<small>Video de bienvenida cargado ✓</small>':''}</div>`}
async function addWelcome(fl){const f=fl[0];if(!f)return;try{await putB('wv',f);S.wv={key:'wv',name:f.name};save();render()}catch(e){alert('No se pudo guardar el video. Usa un enlace.')}}
function quizBox(c){const q=(c.quiz||'').split('\n').map(x=>x.trim()).filter(Boolean);if(!q.length)return '';return `<div class="box" style="margin-top:14px"><b>📝 Cuestionario de este tema</b>${q.map((x,i)=>{const k=x.split('|');return `<details style="margin:8px 0"><summary>${i+1}. ${esc(k[0].trim())}</summary><small>${esc((k[1]||'').trim())||'Respuesta no indicada'}</small></details>`}).join('')}</div>`}
function logout(){S.me=null;save();try{document.cookie='mt_member=; max-age=0; path=/'}catch(x){}render()}
function openTimer(){const u=S.timerUrl;if(!u){toggleTm();return}let w=null;try{w=window.open(u,'mt_timer','popup=yes,width=440,height=760,left='+Math.max(0,screen.width-470)+',top=60')}catch(x){}if(!w){$('#tm').style.display='block';drawTm()}}
const au=$('#aura');addEventListener('pointermove',e=>{au.style.opacity=1;au.style.transform='translate('+e.clientX+'px,'+e.clientY+'px)'});document.addEventListener('mouseleave',()=>au.style.opacity=0);
function addItem(si){const type=$('#nt').value,title=$('#ntt').value||'Sin título',fin=src=>{S.subjects[si].items.push({type,title,text:$('#nx').value,src});save();render()};
if(type==='texto')return fin('');const fl=$('#nf');if(fl.files[0])fileTo(fl,fin);else fin($('#nu').value)}
function postMsg(){const m=$('#cm').value.trim();if(!m)return;S.posts[chatTab].unshift({n:$('#cn').value||'Anónimo',m,d:new Date().toLocaleDateString('es')});save();render()}
let tmI,tmS=0,tmR=false;
function toggleTm(){const p=$('#tm');p.style.display=p.style.display==='block'?'none':'block';if(p.style.display==='block')drawTm()}
function drawTm(){$('#tmb').innerHTML=S.timerUrl?`<p>Tu cronómetro se abre en una ventana aparte, con sus propias configuraciones.</p><a class="btn" href="${esc(S.timerUrl)}" target="_blank" rel="noopener">Abrir cronómetro</a>`:`<div class="big" id="tt">${fmt()}</div><div class="row"><button class="btn" onclick="tmGo()">${tmR?'Pausar':'Iniciar'}</button><button class="btn o" onclick="tmS=0;drawTm()">Reiniciar</button></div><p><small>Cronómetro básico. El administrador puede conectar tu app propia.</small></p>`}
const fmt=()=>[tmS/3600|0,(tmS/60|0)%60,tmS%60].map(x=>String(x).padStart(2,'0')).join(':');
function tmGo(){tmR=!tmR;clearInterval(tmI);if(tmR)tmI=setInterval(()=>{tmS++;const e=$('#tt');if(e)e.textContent=fmt()},1000);drawTm()}
function render(){rail();$('#v').style.maxWidth=view==='subject'?'1400px':'';$('#v').innerHTML=views[view]();wire();renderAv()}
S.nz='';applySeo();twPre();setInterval(()=>{if(document.hidden||!S.me)return;const m=S.members.find(x=>x.id===S.me);if(!m)return;m.sec=(m.sec||0)+1;if(m.sec%20===0)save()},1000);render();
setInterval(()=>{if(view==='home'&&!document.activeElement?.matches('input,textarea,select'))render()},60000);
document.addEventListener('click',e=>{const p=document.getElementById('pf');if(!p||p.style.display!=='block')return;if(p.contains(e.target)||(e.target.closest&&e.target.closest('#avb')))return;p.style.display='none'});
