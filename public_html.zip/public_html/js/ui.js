/* ============================================================
   MEDITHINK — ui.js
   Capa de experiencia de usuario. Se carga DESPUÉS de core.js.
   Solo AÑADE comportamiento (tema, menú móvil, atajos, transiciones,
   estado activo); envuelve render()/twShow() llamando siempre al
   original. Ningún comando, ID ni función original cambia.
   ============================================================ */
(function(){
  'use strict';
  const q = s => document.querySelector(s);
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Tema claro / oscuro (persistido en 'mt_theme') ---------- */
  const THEME_KEY = 'mt_theme';
  function applyTheme(t){
    const root = document.documentElement;
    if (t === 'light' || t === 'dark') root.setAttribute('data-theme', t); else root.removeAttribute('data-theme');
    const eff = root.getAttribute('data-theme') || 'dark';
    const b = q('#thm'); if (b){ b.querySelector('.ic').textContent = eff === 'light' ? '☀️' : '🌙'; b.setAttribute('aria-pressed', eff === 'light'); }
    const m = q('meta[name=theme-color]'); if (m) m.content = eff === 'light' ? '#f4f7fb' : '#060a14';
  }
  window.toggleTheme = function(){
    const cur = document.documentElement.getAttribute('data-theme') || 'dark';
    const next = cur === 'light' ? 'dark' : 'light';
    try{ localStorage.setItem(THEME_KEY, next) }catch(e){}
    applyTheme(next);
  };
  let saved = null; try{ saved = localStorage.getItem(THEME_KEY) }catch(e){}
  applyTheme(saved);

  /* ---------- Menú de navegación en móvil ---------- */
  window.navToggle = function(force){
    const open = typeof force === 'boolean' ? force : !document.body.classList.contains('nav-open');
    document.body.classList.toggle('nav-open', open);
    const b = q('#mnb'); if (b) b.setAttribute('aria-expanded', String(open));
    if (open){ const f = q('#mainnav .ib[data-view]'); f && f.focus(); }
  };
  q('#mainnav').addEventListener('click', e => { if (e.target.closest('.ib[data-view]')) navToggle(false); });

  /* ---------- Estado activo en la navegación ---------- */
  function markNav(){
    const map = { subject: 'subjects', subpay: 'subjects', search: 'subjects', pay: 'plans', post: 'home' };
    const v = map[view] || view;
    document.querySelectorAll('#mainnav .ib[data-view]').forEach(b => {
      const on = b.dataset.view === v;
      b.classList.toggle('on', on);
      if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
    document.body.dataset.view = view;
  }

  /* ---------- Transición suave entre vistas ---------- */
  const _render = window.render; let lastKey = null;
  window.render = function(){
    const r = _render.apply(this, arguments);
    const v = q('#v'), key = view + '|' + String(arg);
    if (v && !reduce && key !== lastKey){ v.classList.remove('in'); void v.offsetWidth; v.classList.add('in'); }
    lastKey = key;
    markNav();
    const a = q('#avb'); if (a) a.setAttribute('aria-expanded', String(q('#pf').style.display === 'block'));
    return r;
  };

  /* ---------- Indicador de cronómetro en marcha ---------- */
  const _twShow = window.twShow;
  window.twShow = function(t){ const r = _twShow.apply(this, arguments); const b = q('#twb'); if (b) b.classList.toggle('run', !!twRun); return r; };
  const _twToggle = window.twToggle;
  window.twToggle = function(){ const r = _twToggle.apply(this, arguments); const b = q('#twb'); if (b) b.setAttribute('aria-expanded', String(q('#twp').classList.contains('open'))); return r; };
  const _twReset = window.twReset;
  window.twReset = function(){ const r = _twReset.apply(this, arguments); const b = q('#twb'); if (b) b.classList.remove('run'); return r; };

  /* ---------- Atajos de teclado ---------- */
  document.addEventListener('keydown', e => {
    const typing = e.target.matches('input,textarea,select,[contenteditable]');
    if (e.key === '/' && !typing){ e.preventDefault(); const s = q('#q'); s.focus(); s.select(); }
    if (e.key === 'Escape'){
      if (document.body.classList.contains('nav-open')) navToggle(false);
      const pf = q('#pf'); if (pf.style.display === 'block'){ pf.style.display = 'none'; q('#avb').focus(); }
      const tp = q('#twp'); if (tp.classList.contains('open')){ tp.classList.remove('open'); q('#twb').focus(); }
      if (typing && e.target.id === 'q'){ e.target.blur(); }
    }
  });

  /* ---------- Cerrar el cronómetro al hacer clic fuera ---------- */
  document.addEventListener('click', e => {
    const tp = q('#twp'); if (!tp.classList.contains('open')) return;
    if (e.target.closest('#tw2')) return;
    tp.classList.remove('open'); q('#twb').setAttribute('aria-expanded', 'false');
  });

  /* ---------- Estado de conexión (feedback visual) ---------- */
  function net(){ document.body.classList.toggle('offline', !navigator.onLine); }
  addEventListener('online', net); addEventListener('offline', net); net();

  /* ---------- Arranque: el núcleo ya renderizó; marcamos y retiramos el splash ---------- */
  markNav();
  const sp = q('#splash');
  if (sp){ requestAnimationFrame(() => { sp.classList.add('out'); setTimeout(() => sp.remove(), reduce ? 0 : 600); }); }
})();
