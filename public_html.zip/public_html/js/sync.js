/* MEDITHINK — sync.js: conecta la interfaz con el servidor. Se carga ANTES de core.js.
   - Al abrir: descarga el contenido compartido y lo mezcla en localStorage('mt').
   - Si el administrador edita: sube los cambios al servidor (pide la contraseña del servidor). */
(function(){
  'use strict';
  const KEYS=['subjects','about','hero','sub','perm','cur','fx','season','qr','bank','paypalEmail','paypalLink','wa','mode','paywall','timerUrl','logo'];
  const raw=Storage.prototype.setItem;
  let token=null,timer=null,loading=true;
  try{
    const x=new XMLHttpRequest();x.open('GET','/api/content',false);x.send();
    if(x.status===200){
      const c=JSON.parse(x.responseText).content||{};
      if(Object.keys(c).length){
        let s={};try{s=JSON.parse(localStorage.getItem('mt')||'{}')}catch(e){}
        KEYS.forEach(k=>{if(k in c)s[k]=c[k]});
        raw.call(localStorage,'mt',JSON.stringify(s));
      }
    }
  }catch(e){}
  loading=false;
  const H=()=>({'Content-Type':'application/json',Authorization:'Bearer '+token});
  async function login(){
    const pw=prompt('Contraseña del SERVIDOR (ADMIN_PASSWORD) para publicar los cambios a todos los visitantes:');
    if(!pw)return false;
    const r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:pw})});
    const j=await r.json();if(!r.ok){alert(j.error||'Error');return false}
    token=j.token;return true;
  }
  async function push(){
    let s;try{s=JSON.parse(localStorage.getItem('mt')||'{}')}catch(e){return}
    const out={};KEYS.forEach(k=>{if(k in s)out[k]=s[k]});
    if(!token&&!(await login()))return;
    let r=await fetch('/api/content',{method:'PUT',headers:H(),body:JSON.stringify(out)});
    if(r.status===401){token=null;if(await login())r=await fetch('/api/content',{method:'PUT',headers:H(),body:JSON.stringify(out)})}
    if(!r.ok)alert('No se pudo publicar en el servidor ('+r.status+').');
  }
  window.mtAdminToken=async()=>(token||(await login()))?token:null;
  Storage.prototype.setItem=function(k,v){
    raw.apply(this,arguments);
    if(k==='mt'&&!loading&&typeof admin!=='undefined'&&admin===true){clearTimeout(timer);timer=setTimeout(push,1500)}
  };
})();
