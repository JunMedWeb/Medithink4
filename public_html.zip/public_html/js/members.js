/* MEDITHINK — members.js (Fase 2). Se carga DESPUÉS de access.js.
   Miembros: guarda SOLO su propio registro; el servidor decide el acceso pagado.
   Admin: ve y gestiona todos los miembros, solicitudes y pagos desde el servidor. */
(function(){
  'use strict';
  const base=Storage.prototype.setItem;
  const rd=()=>{try{return JSON.parse(localStorage.getItem('mt')||'{}')}catch(e){return {}}};
  const wr=o=>base.call(localStorage,'mt',JSON.stringify(o));
  let busy=false,t=null,since=0,adminReady=false;
  const J=(u,m,b,tok)=>fetch(u,{method:m,headers:Object.assign({'Content-Type':'application/json'},tok?{Authorization:'Bearer '+tok}:{}),body:b?JSON.stringify(b):undefined});
  async function memberSync(){
    if(busy||(typeof admin!=='undefined'&&admin))return;
    const s=rd(),m=(s.members||[]).find(x=>x.id===s.me);if(!m)return;
    busy=true;
    try{
      const r=await J('/api/member/sync','POST',{member:m,subReq:(s.subReq||[]).filter(x=>x.uid===m.id),adminNotifs:(s.adminNotifs||[]).filter(x=>x.memberId===m.id)});
      const j=await r.json();
      if(r.status===403){alert('Esta cuenta ya existe con otra contraseña.');return}
      if(j.needPw&&!window.__pwWarned){window.__pwWarned=1;alert(j.error)}
      if(!r.ok)return;
      const was=JSON.stringify(m),rec=j.member,s2=rd();
      s2.members=[rec].concat((s2.members||[]).filter(x=>x.pub));s2.me=rec.id;s2.subReq=j.subReq;
      wr(s2);
      if(JSON.stringify(rec)!==was&&typeof render==='function'){S.members=s2.members;S.me=s2.me;S.subReq=s2.subReq;render()}
    }catch(e){}finally{busy=false}
  }
  async function adminPull(){
    const tok=await window.mtAdminToken();if(!tok)return;
    const r=await J('/api/admin/data','GET',null,tok);if(!r.ok)return;
    const j=await r.json(),s=rd();
    s.members=j.members;s.subReq=j.subReq;s.adminNotifs=j.adminNotifs;since=j.now;wr(s);
    S.members=s.members;S.subReq=s.subReq;S.adminNotifs=s.adminNotifs;adminReady=true;
    if(typeof render==='function')render();
  }
  async function adminPush(){
    const tok=await window.mtAdminToken();if(!tok)return;const s=rd();
    await J('/api/admin/data','PUT',{since,members:(s.members||[]).filter(x=>!x.pub),subReq:s.subReq||[],adminNotifs:s.adminNotifs||[]},tok);
  }
  Storage.prototype.setItem=function(k,v){
    base.apply(this,arguments);
    if(k!=='mt'||busy)return;
    clearTimeout(t);
    t=setTimeout(()=>{(typeof admin!=='undefined'&&admin)?(adminReady&&adminPush()):memberSync()},1800);
  };
  /* ---------- Respaldos (solo administrador) ---------- */
  function backupUI(on){
    let box=document.getElementById('mt-bk');
    if(!on){if(box)box.remove();return}
    if(box)return;
    box=document.createElement('div');box.id='mt-bk';
    box.style.cssText='position:fixed;left:12px;bottom:12px;z-index:9999;display:flex;gap:6px;font:12px system-ui';
    const b=(txt,fn)=>{const e=document.createElement('button');e.textContent=txt;e.className='btn o s';e.style.cssText='padding:6px 10px;border-radius:10px;cursor:pointer';e.onclick=fn;return e};
    box.append(b('💾 Descargar respaldo',async()=>{
      const tok=await window.mtAdminToken();if(!tok)return;
      const r=await fetch('/api/admin/backup',{headers:{Authorization:'Bearer '+tok}});if(!r.ok)return alert('No se pudo crear el respaldo.');
      const a=document.createElement('a');a.href=URL.createObjectURL(await r.blob());
      a.download='medithink-respaldo-'+new Date().toISOString().slice(0,16).replace(/[:T]/g,'-')+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),5e3)}),
    b('♻️ Restaurar',()=>{
      const i=document.createElement('input');i.type='file';i.accept='.json';
      i.onchange=async()=>{const f=i.files[0];if(!f)return;
        if(!confirm('Esto reemplaza TODOS los datos actuales por los del archivo. Antes se guarda una copia automática. ¿Continuar?'))return;
        const tok=await window.mtAdminToken();if(!tok)return;
        const r=await fetch('/api/admin/restore',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+tok},body:await f.text()});
        const j=await r.json().catch(()=>({}));
        if(r.ok){alert('Respaldo restaurado. Se recargará la página.');location.reload()}else alert(j.error||'No se pudo restaurar.')};
      i.click()}));
    document.body.appendChild(box);
  }
  let wasAdmin=false;
  setInterval(()=>{const a=typeof admin!=='undefined'&&admin;if(a&&!wasAdmin)adminPull();if(!a)adminReady=false;backupUI(a);wasAdmin=a},2000);
  setInterval(memberSync,60000);setTimeout(memberSync,1500);
})();
